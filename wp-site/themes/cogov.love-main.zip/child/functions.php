<?php
	/**
	*
	* @Packge      Ideabuz
	* @Author      ThemeLooks
	* @Author URL  https//www.themelooks.com
	* @version     1.0
	*
	*/

	/**
	 * Enqueue style of child theme
	 */
	add_action( 'wp_enqueue_scripts', 'ideabuz_child_theme_enqueue_style' );
	function ideabuz_child_theme_enqueue_style() {
	 
	    $parent_style = 'ideabuz-parent-style'; 
	 
	    wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css' );
	    wp_enqueue_style( 'ideabuz-child-style',
	        get_stylesheet_directory_uri() . '/style.css',
	        array( $parent_style ),
	        wp_get_theme()->get('Version')
	    );
	}