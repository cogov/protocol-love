<?php
    // Block direct access
    if( !defined( 'ABSPATH' ) ){
        exit( );
    }
    /**
    * @Packge     : ideabuz
    * @Version    : 1.0
    * @Author     : ThemeLooks
    * @Author URI : https://www.themelooks.com/
    *
    */

echo '<footer class="footer section-pattern footer-bg">';
        /**
        * @Ideabuz Footer 
        *
        * @Hook ideabuz_footer_widget
        *
        * @Hooked ideabuz_footer_widget_cb
        */
        do_action( 'ideabuz_footer_widget' );
        
        /**
        * @Ideabuz Footer Bottom
        *
        * @Hook ideabuz_footer_bottom
        *
        * @Hooked ideabuz_footer_bottom_cb
        */
        do_action( 'ideabuz_footer_bottom' );

echo '</footer>';
    /**
    * @Ideabuz Back To Top
    *
    * @Hook ideabuz_back_to_top
    *
    * @Hooked ideabuz_back_to_top_cb
    */
    do_action( 'ideabuz_back_to_top' );
    
    wp_footer();
?>
</body>
</html>