<?php
    // Do not allow directly accessing this file.
    if ( ! defined( 'ABSPATH' ) ) {
        exit( );
    }
    /**
    * @Packge     : Ideabuz
    * @Version    : 1.0
    * @Author     : ThemeLooks
    * @Author URI : https://www.themelooks.com/
    *
    */

    // Call Header
    get_header();
    
    /**
    * @Wrapper start With Section, Container, Row
    *
    * @Hook ideabuz_page_wrapper_start
    *
    * @Hooked ideabuz_page_wrapper_start_cb
    */
    do_action( 'ideabuz_page_wrapper_start' );
    
    /**
    * @Page Column Wrapper
    *
    * @Hook ideabuz_page_column_divider_start_wrapper
    *
    * @Hooked ideabuz_page_column_divider_start_wrapper_cb
    */
    do_action( 'ideabuz_page_column_divider_start_wrapper' );
    
    if( have_posts() ){
        while( have_posts() ){
            the_post();
            // Post Contant
            get_template_part( 'template-part/content', 'page' );
        }
        // Reset Data
        wp_reset_postdata();
    }else{
        get_template_part( 'template-part/content', 'none' );
    }
    
    /**
    * @Single Div
    *
    * @Hook ideabuz_single_div_end_wrapper
    *
    * @Hooked ideabuz_single_div_end_wrapper_cb
    */
    do_action( 'ideabuz_single_div_end_wrapper' );
    
    /**
    * @Page Column Wrapper
    *
    * @Hook ideabuz_page_sidebar_wrapper
    *
    * @Hooked ideabuz_page_sidebar_wrapper_cb
    */
    do_action( 'ideabuz_page_sidebar_wrapper' );
    
    /**
    * @Page End Wrapper
    *
    * @Hook ideabuz_page_wrapper_end
    *
    * @Hooked ideabuz_page_wrapper_end_cb
    */
    do_action( 'ideabuz_page_wrapper_end' );
    
    // Call Footer
    get_footer();