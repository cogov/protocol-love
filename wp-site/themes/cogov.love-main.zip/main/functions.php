<?php
	// Block direct access
	if( !defined( 'ABSPATH' ) ){
		exit( );
	}
	/**
	* @Packge 	   : Ideabuz
	* @Version     : 1.0
	* @Author 	   : ThemeLooks
	* @Author URI  : https://www.themelooks.com/
	*
	*/

	/**
	*
	* Define constant
	*
	*/
	// Base URI
	if( !defined( 'IDEABUZ_DIR_URI' ) ){
		define( 'IDEABUZ_DIR_URI',get_template_directory_uri().'/' );
	}

	// Css Assist URI
	if( !defined( 'IDEABUZ_CSS_DIR_URI' ) ){
		define( 'IDEABUZ_CSS_DIR_URI',IDEABUZ_DIR_URI.'assets/css/' );
	}

	// Img Assist URI
	if( !defined('IDEABUZ_IMG_DIR_URI' ) ){
		define( 'IDEABUZ_IMG_DIR_URI',IDEABUZ_DIR_URI.'assets/img/' );
	}

	// Js Assist URI
	if( !defined( 'IDEABUZ_JS_DIR_URI' ) ){
		define( 'IDEABUZ_JS_DIR_URI',IDEABUZ_DIR_URI.'assets/js/' );
	}

	// Plugin Assist URI
	if( !defined( 'IDEABUZ_PLUGINS_DIR_URI' ) ){
		define( 'IDEABUZ_PLUGINS_DIR_URI',IDEABUZ_DIR_URI.'assets/plugins/' );
	}

	// Js Assist URI
	if( !defined( 'IDEABUZ_PLUGINS_DIR_URI' ) ){
		define( 'IDEABUZ_PLUGINS_DIR_URI',IDEABUZ_DIR_URI.'assets/plugins/' );
	}

	// Base Directory
	if( !defined( 'IDEABUZ_DIR_PATH' ) ){
		define( 'IDEABUZ_DIR_PATH', get_parent_theme_file_path().'/' );
	}

	// Inc Folder Directory
	if( !defined( 'IDEABUZ_INC_DIR_PATH' ) ){
		define( 'IDEABUZ_INC_DIR_PATH',IDEABUZ_DIR_PATH.'inc/' );
	}

	// Demo Data Folder Directory Path
	if( !defined( 'IDEABUZ_DEMO_DIR_PATH' ) ){
		define( 'IDEABUZ_DEMO_DIR_PATH', IDEABUZ_INC_DIR_PATH.'demo-data/' );
	}

	// Demo Data Folder Directory URI
	if( !defined( 'IDEABUZ_DEMO_DIR_URI' ) ){
		define( 'IDEABUZ_DEMO_DIR_URI', IDEABUZ_DIR_URI.'inc/demo-data/' );
	}

	// Hooks Folder Directory
	if( !defined( 'IDEABUZ_HOOKS_DIR_PATH' ) ){
		define( 'IDEABUZ_HOOKS_DIR_PATH',IDEABUZ_INC_DIR_PATH.'hooks/' );
	}

	// Ideabuz Framework Folder Directory
	if( !defined( 'IDEABUZ_FRAMEWORK_DIR_PATH' ) ){
		define( 'IDEABUZ_FRAMEWORK_DIR_PATH',IDEABUZ_INC_DIR_PATH.'ideabuz-framework/' );
	}

	// Ideabuz Theme Support
	if( !defined( 'IDEABUZ_THEME_SUPPORT_DIR_PATH' ) ){
		define( 'IDEABUZ_THEME_SUPPORT_DIR_PATH',IDEABUZ_INC_DIR_PATH.'theme-support/' );
	}

	/**
	* Include File
	*
	*/
	require_once( IDEABUZ_INC_DIR_PATH.'ideabuz-breadcrumb.php' );
	require_once( IDEABUZ_INC_DIR_PATH.'ideabuz-commoncss.php' );
	require_once( IDEABUZ_INC_DIR_PATH.'ideabuz-functions.php' );
	require_once( IDEABUZ_INC_DIR_PATH.'wp-html-helper.php' );
	require_once( IDEABUZ_INC_DIR_PATH.'ideabuz-widget/ideabuz-widgets.php' );
	require_once( IDEABUZ_INC_DIR_PATH.'redux-custom-field/fa-icons.php' );
	require_once( IDEABUZ_INC_DIR_PATH.'redux-custom-field/exopress-option-slide-add-field.php' );

	/**
	* Style And Script Add File
	*
	*/
	require_once( IDEABUZ_THEME_SUPPORT_DIR_PATH.'ideabuz-style-script.php' );

	/**
	* Hook File
	*
	*/
	require_once( IDEABUZ_HOOKS_DIR_PATH.'hooks.php' );
	require_once( IDEABUZ_HOOKS_DIR_PATH.'hooks-functions.php' );

	/**
	* Plugin File
	*
	*/
	require_once( IDEABUZ_FRAMEWORK_DIR_PATH.'plugin-activation/active-plugins.php' );
	require_once( IDEABUZ_FRAMEWORK_DIR_PATH.'ideabuz-options/ideabuz-options.php' );
	require_once( IDEABUZ_FRAMEWORK_DIR_PATH.'ideabuz-meta/ideabuz-meta.php' );

	/**
	* WooCommerce File
	*
	*/
	require_once( IDEABUZ_INC_DIR_PATH.'ideabuz-woo-hooks.php' );
	require_once( IDEABUZ_INC_DIR_PATH.'ideabuz-woo-hooks-functions.php' );