<?php
	if ( ! defined( 'ABSPATH' ) ) {
	    exit( );
	}

	/**
	* @Packge 	   : Ideabuz
	* @Version     : 1.0
	* @Author 	   : ThemeLooks
	* @Author URI  : https://www.themelooks.com/
	*
	*/

?>
	<!-- Widget Search Begin -->
	<?php
	 	if( is_404() ):
		if( class_exists( 'ReduxFramework' ) ){
			$ideabuz_form_placeholder = ideabuz_opt( 'ideabuz_404_form_placeholder' );
		}else{
			$ideabuz_form_placeholder = "What are you looking for...";
		}
		
		if( class_exists( 'ReduxFramework' ) ){
			$ideabuz_404_button = ideabuz_opt( 'ideabuz_404_button' );
		}else{
			$ideabuz_404_button = "Search";
		}
	?>
	<div class="not-found-form">
		<form method="get" action="<?php echo esc_url( home_url('/') )?>" class="d-flex flex-wrap align-items-center justify-content-center">
			<input name="s" type="text" class="theme-input-style" placeholder="<?php echo esc_attr( $ideabuz_form_placeholder );?>">
			<button type="submit" class="ml-sm-3 btn">
				<span>
					<?php
						echo esc_html( $ideabuz_404_button );
					?>
				</span>
			</button>
		</form>
	</div>
	<?php 
		elseif( is_page_template( 'coming-soon.php' ) ):
			if( class_exists( 'ReduxFramework' ) ){
				$ideabuz_coming_soon_form_placeholder = ideabuz_opt( 'ideabuz_coming_soon_form_placeholder' );
			}else{
				$ideabuz_coming_soon_form_placeholder = "What are you looking for...";
			}
			
			if( class_exists( 'ReduxFramework' ) ){
				$ideabuz_coming_soon_button_placeholder = ideabuz_opt( 'ideabuz_coming_soon_button' );
			}else{
				$ideabuz_coming_soon_button_placeholder = "Search";
			}
	?>
	<div class="coming-soon-form">
		<form method="get" action="<?php echo esc_url( home_url('/') )?>" class="d-flex flex-wrap align-items-center justify-content-center">
			<input name="s" type="text" class="theme-input-style" placeholder="<?php echo esc_attr( $ideabuz_coming_soon_form_placeholder );?>">
			<button type="submit" class="ml-sm-3 btn">
				<span>
					<?php
						echo esc_html( $ideabuz_coming_soon_button_placeholder );
					?>
				</span>
			</button>
		</form>
	</div>
	<?php else:?>
	<div class="widget widget_search">
		<form action="<?php echo esc_url( home_url('/') );?>" method="GET">
			<div class="input-group">
				<input name='s' value="<?php echo esc_attr( get_search_query() );?>" placeholder="<?php echo esc_attr__( 'Search here....','ideabuz' );?>" class="theme-input-style" required>
				<button type="submit" class="submit-btn">
					<?php 
						echo ideabuz_img_tag(array(
							'url'	=> esc_url( IDEABUZ_IMG_DIR_URI.'icons/search.svg' ),
							'class'	=> esc_attr( 'svg' ),
						));
					?>
				</button>
			</div>
		</form>
	</div>
	<!-- Widget Search End -->
	<?php endif;