<?php
    // Do not allow directly accessing this file.
    if ( ! defined( 'ABSPATH' ) ) {
        exit( );
    }
    /**
    * @Packge    : ideabuz
    * @version   : 1.0
    * @Author    : ThemeLooks
    * @Author URI: https://www.themelooks.com/
    */
   
    get_header();
    
?>
<!-- 404 Begin -->
<section class="min-vh-100 pt-5 pb-5 pb-lg-0 pt-lg-0 vw-100 d-flex align-items-center bg-404 ovx-hidden">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <!-- 404 Content Begin -->
                <div class="not-found-content text-center">
                    <?php 
                        $ideabuz_404_image = ideabuz_opt( 'ideabuz_404_image','url' );
                        if( !empty( $ideabuz_404_image ) ){
                            echo ideabuz_img_tag(array(
                                'url'	=> esc_url( $ideabuz_404_image ),
                            ));
                        }else{
                            echo ideabuz_img_tag(array(
                                'url'	=> esc_url( IDEABUZ_IMG_DIR_URI.'404.png' ),
                            ));
                        }
                        $ideabuz_404_text_default = sprintf(
                            __( '<p>%s<a href="%s">%s</a></p>','ideabuz' ),
                            esc_html__( 'You\'ve been tricked into click on link that can\'t be found.
                            Please check the url or go to ','ideabuz' ),
                            esc_url( home_url('/') ),
                            esc_html__( 'main page.','ideabuz' )
                        );
                        $ideabuz_404_text = ideabuz_opt( "ideabuz_404_subtitle" );
                        if( !empty( $ideabuz_404_text ) ){
                            echo '<p>'.wp_kses_post( $ideabuz_404_text ).'</p>';
                        }else{
                            echo wp_kses_post( $ideabuz_404_text_default );
                        }
                        
                        get_search_form();
                    ?> 

                </div>
                <!-- 404 Content End -->
            </div>
        </div>
    </div>
</section>
<!-- 404 End -->
<?php wp_footer();?>
</body>

</html>