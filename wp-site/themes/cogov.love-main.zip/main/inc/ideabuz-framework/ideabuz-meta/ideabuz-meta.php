<?php
/**
 * Include and setup custom metaboxes and fields. (make sure you copy this file to outside the CMB2 directory)
 *
 * Be sure to replace all instances of 'yourprefix_' with your project's prefix.
 * http://nacin.com/2010/05/11/in-wordpress-prefix-everything/
 *
 * @category YourThemeOrPlugin
 * @package  Demo_CMB2
 * @license  http://www.opensource.org/licenses/gpl-license.php GPL v2.0 (or later)
 * @link     https://github.com/WebDevStudios/CMB2
 */


/**
 * Conditionally displays a metabox when used as a callback in the 'show_on_cb' cmb2_box parameter
 *
 * @param  CMB2 object $cmb CMB2 object
 *
 * @return bool             True if metabox should show
 */
function ideabuz_show_if_front_page( $cmb ) {
	// Don't show this metabox if it's not the front page template
	if ( $cmb->object_id !== get_option( 'page_on_front' ) ) {
		return false;
	}
	return true;
}

/**
 * Conditionally displays a field when used as a callback in the 'show_on_cb' field parameter
 *
 * @param  CMB2_Field object $field Field object
 *
 * @return bool                     True if metabox should show
 */
function ideabuz_hide_if_no_cats( $field ) {
	// Don't show this field if not in the cats category
	if ( ! has_tag( 'cats', $field->object_id ) ) {
		return false;
	}
	return true;
}

/**
 * Manually render a field.
 *
 * @param  array      $field_args Array of field arguments.
 * @param  CMB2_Field $field      The field object
 */
function ideabuz_render_row_cb( $field_args, $field ) {
	$classes     = $field->row_classes();
	$id          = $field->args( 'id' );
	$label       = $field->args( 'name' );
	$name        = $field->args( '_name' );
	$value       = $field->escaped_value();
	$description = $field->args( 'description' );
	?>
	<div class="custom-field-row <?php echo esc_attr( $classes ); ?>">
		<p><label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></label></p>
		<p><input id="<?php echo esc_attr( $id ); ?>" type="text" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>"/></p>
		<p class="description"><?php echo esc_html( $description ); ?></p>
	</div>
	<?php
}

/**
 * Manually render a field column display.
 *
 * @param  array      $field_args Array of field arguments.
 * @param  CMB2_Field $field      The field object
 */
function ideabuz_display_text_small_column( $field_args, $field ) {
	?>
	<div class="custom-column-display <?php echo esc_attr( $field->row_classes() ); ?>">
		<p><?php echo esc_html( $field->escaped_value() ); ?></p>
		<p class="description"><?php echo esc_attr( $field->args( 'description' ) ); ?></p>
	</div>
	<?php
}

/**
 * Conditionally displays a message if the $post_id is 2
 *
 * @param  array             $field_args Array of field parameters
 * @param  CMB2_Field object $field      Field object
 */
function ideabuz_before_row_if_2( $field_args, $field ) {
	if ( 2 == $field->object_id ) {
		echo '<p>Testing <b>"before_row"</b> parameter (on $post_id 2)</p>';
	} else {
		echo '<p>Testing <b>"before_row"</b> parameter (<b>NOT</b> on $post_id 2)</p>';
	}
}
add_action( 'cmb2_admin_init', 'ideabuz_register_metabox' );
/**
 * Hook in and add a demo metabox. Can only happen on the 'cmb2_admin_init' or 'cmb2_init' hook.
 */
function ideabuz_register_metabox() {
	$prefix 	= '_ideabuz_';
	$prefixpage = '_ideabuzpage_';

    /********************************\
        Page Layout
    \********************************/
	$ideabuz_meta = new_cmb2_box( array(
		'id'            => $prefixpage . 'page_layout_section',
		'title'         => esc_html__( 'Page Layout', 'ideabuz' ),
        'context' 		=> 'side',
        'priority' 		=> 'high',
		'object_types'  => array( 'page' ), // Post type
	) );

	$ideabuz_meta->add_field( array(
		'desc'       => esc_html__( 'Set page layout container,container fluid,fullwidth or both. It\'s work only in template builder page.', 'ideabuz' ),
		'id'         => $prefix . 'custom_page_layout',
		'type'       => 'radio',
        'options' => array(
            '1' => esc_html__( 'Container','ideabuz' ),
            '2' => esc_html__( 'Container Fluid','ideabuz' ),
            '3' => esc_html__( 'Fullwidth','ideabuz' ),
        ),
	) );
	$ideabuz_meta->add_field( array(
		'name' => esc_html__( 'Top and Bottom Padding', 'ideabuz' ),
		'id'   => $prefix . 'custom_page_padding',
		'type' => 'own_slider',
		'min'         => '0',
		'max'         => '500',
		'step'        => '1',
		'default'     => '0', // start value
		'value_label' => 'Value:',
        'desc' => esc_html__( 'Set page content wrapper top and bottom padding.', 'ideabuz' ),
	));
	// Classic CMB2 declaration
	$ideabuz_meta = new_cmb2_box( array(
		'id'           => $prefixpage .'header_option',
		'title'        => esc_html__( 'Custom Page Settings','ideabuz' ),
		'closed'	   => true,	
		'object_types' => array( 'page' ), // Post type
		'tabs'      => array(
			'ideabuz-menu-option'  => array(
				'label' => esc_html__( 'Menu Option', 'ideabuz' ),
				'icon'  => 'fa fa-window-maximize',
			),
			'ideabuz-menu-option-for-mobile'  => array(
				'label' => esc_html__( 'Responsive Menu Option', 'ideabuz' ),
				'icon'  => 'fa fa-window-maximize',
			),
			'ideabuz-header-option' => array(
				'label' => esc_html__( 'Page Header Option', 'ideabuz' ),
				'icon'  => 'fa fa-info',
			),
		),
		'tab_style'   => 'default',
	) );
	$ideabuz_meta->add_field( array(
		'desc'       	=> esc_html__( 'Choose Setting', 'ideabuz' ),
		'id'         	=> $prefix . 'global_menu_style',
		'type'          => 'select',
		'default'       => 'global',
		'options'       => array(
			'global' 	=> esc_html__( 'Global Setting', 'ideabuz' ),
			'single'    => esc_html__( 'Single Page Setting', 'ideabuz' ),
		),
		'tab'  			=> 'ideabuz-menu-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'desc'       	=> esc_html__( 'Logo', 'ideabuz' ),
		'id'         	=> $prefix . 'page_general_logo',
		'type'    	 	=> 'file',
		'tab'  			=> 'ideabuz-menu-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'desc'       	=> esc_html__( 'Text Logo', 'ideabuz' ),
		'id'         	=> $prefix . 'page_logo_title',
		'type'    	 	=> 'text',
		'tab'  			=> 'ideabuz-menu-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'desc'       	=> esc_html__( 'Text Logo Color', 'ideabuz' ),
		'id'         	=> $prefix . 'page_logo_title_color',
		'type'    	 	=> 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'desc'       	=> esc_html__( 'Text Logo Color On Hover', 'ideabuz' ),
		'id'         	=> $prefix . 'page_logo_title_color_hover',
		'type'    	 	=> 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'desc'       	=> esc_html__( 'Sticky Logo', 'ideabuz' ),
		'id'         	=> $prefix . 'page_sticky_logo',
		'type'    	 	=> 'file',
		'tab'  			=> 'ideabuz-menu-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       	=> esc_html__( 'Header Menu Color', 'ideabuz' ),
		'id'         	=> $prefix . 'header_menu_color',
		'type'    	 	=> 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       	=> esc_html__( 'Header Menu Active Color', 'ideabuz' ),
		'id'         	=> $prefix . 'header_menu_active_color',
		'type'    	 	=> 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       	=> esc_html__( 'Header Active Menu Opacity', 'ideabuz' ),
		'id'         	=> $prefix . 'header_menu_active_opacity',
		'type'    	 	=> 'text',
		'tab'  			=> 'ideabuz-menu-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       	=> esc_html__( 'Header Hover Menu Opacity', 'ideabuz' ),
		'id'         	=> $prefix . 'header_menu_hover_opacity',
		'type'    	 	=> 'text',
		'tab'  			=> 'ideabuz-menu-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       	=> esc_html__( 'Header Menu Hover Color', 'ideabuz' ),
		'id'         	=> $prefix . 'header_menu_hover_color',
		'type'    	 	=> 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       => esc_html__( 'Header Sub Menu Background Color', 'ideabuz' ),
		'id'         => $prefix . 'header_sub_menu_background_color',
		'type'    	 => 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       => esc_html__( 'Header Sub Menu Text Color', 'ideabuz' ),
		'id'         => $prefix . 'header_sub_menu_text_color',
		'type'    	 => 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       => esc_html__( 'Header Sub Menu Hover Text Color', 'ideabuz' ),
		'id'         => $prefix . 'header_sub_menu_hover_text_color',
		'type'    	 => 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       => esc_html__( 'Header Sticky Menu Background', 'ideabuz' ),
		'id'         => $prefix . 'header_sticky_background',
		'type'    	 => 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       => esc_html__( 'Header Sticky Menu Color', 'ideabuz' ),
		'id'         => $prefix . 'header_sticky_menu_color',
		'type'    	 => 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       => esc_html__( 'Header Sticky Menu Active Color', 'ideabuz' ),
		'id'         => $prefix . 'header_sticky_menu_active_color',
		'type'    	 => 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       => esc_html__( 'Header Sticky Menu Hover Color', 'ideabuz' ),
		'id'         => $prefix . 'header_sticky_menu_hover_color',
		'type'    	 => 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       => esc_html__( 'Header Sticky Sub Menu Background', 'ideabuz' ),
		'id'         => $prefix . 'header_sticky_submenu_background',
		'type'    	 => 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       => esc_html__( 'Header Sticky Sub Menu Text Color', 'ideabuz' ),
		'id'         => $prefix . 'header_sticky_submenu_textcolor',
		'type'    	 => 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       => esc_html__( 'Header Sticky Sub Menu Hover Text Color', 'ideabuz' ),
		'id'         => $prefix . 'header_sticky_submenu_hover_textcolor',
		'type'    	 => 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       	=> esc_html__( 'Offcanvas Icon Color', 'ideabuz' ),
		'id'         	=> $prefix . 'header_offcanvas_icon',
		'type'    	 	=> 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       	=> esc_html__( 'Offcanvas Sticky Icon Color', 'ideabuz' ),
		'id'         	=> $prefix . 'header_offcanvas_icon_sticky',
		'type'    	 	=> 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'desc'       	=> esc_html__( 'Responsive Setting', 'ideabuz' ),
		'id'         	=> $prefix . 'responsive_menu_style',
		'type'          => 'select',
		'default'       => 'global',
		'options'       => array(
			'global' 	=> esc_html__( 'Global Setting', 'ideabuz' ),
			'single'    => esc_html__( 'Single Page Setting', 'ideabuz' ),
		),
		'tab'  			=> 'ideabuz-menu-option-for-mobile',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       	=> esc_html__( 'Menu Button Color', 'ideabuz' ),
		'id'         	=> $prefix . 'menu_button_color',
		'type'    	 	=> 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option-for-mobile',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       	=> esc_html__( 'Cross Button Color', 'ideabuz' ),
		'id'         	=> $prefix . 'cross_button_color',
		'type'    	 	=> 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option-for-mobile',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       	=> esc_html__( 'Menu Background Color', 'ideabuz' ),
		'id'         	=> $prefix . 'menu_background_color',
		'type'    	 	=> 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option-for-mobile',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       	=> esc_html__( 'Menu Text Color', 'ideabuz' ),
		'id'         	=> $prefix . 'menu_text_color',
		'type'    	 	=> 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option-for-mobile',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       	=> esc_html__( 'Menu Text Color On Hover', 'ideabuz' ),
		'id'         	=> $prefix . 'menu_text_color_on_hover',
		'type'    	 	=> 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option-for-mobile',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       	=> esc_html__( 'Menu Icon Color', 'ideabuz' ),
		'id'         	=> $prefix . 'right_side_icon_color',
		'type'    	 	=> 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option-for-mobile',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       	=> esc_html__( 'Submenu Background Color', 'ideabuz' ),
		'id'         	=> $prefix . 'submenu_background_color',
		'type'    	 	=> 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option-for-mobile',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       	=> esc_html__( 'Submenu Text Color', 'ideabuz' ),
		'id'         	=> $prefix . 'submenu_text_color',
		'type'    	 	=> 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option-for-mobile',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       	=> esc_html__( 'Submenu Text Color On Hover', 'ideabuz' ),
		'id'         	=> $prefix . 'submenu_text_color_on_hover',
		'type'    	 	=> 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option-for-mobile',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       	=> esc_html__( 'Sticky Menu Background Color', 'ideabuz' ),
		'id'         	=> $prefix . 'sticky_menu_background_color',
		'type'    	 	=> 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option-for-mobile',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       	=> esc_html__( 'Sticky Menu Button Color', 'ideabuz' ),
		'id'         	=> $prefix . 'sticky_menu_button_color',
		'type'    	 	=> 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option-for-mobile',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       	=> esc_html__( 'Sticky Menu Cross Button Color', 'ideabuz' ),
		'id'         	=> $prefix . 'sticky_menu_cross_button_color',
		'type'    	 	=> 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option-for-mobile',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       	=> esc_html__( 'Sticky Menu Background Color', 'ideabuz' ),
		'id'         	=> $prefix . 'sticky_menu_background_color_two',
		'type'    	 	=> 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option-for-mobile',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       	=> esc_html__( 'Sticky Menu Text Color', 'ideabuz' ),
		'id'         	=> $prefix . 'sticky_menu_text_color',
		'type'    	 	=> 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option-for-mobile',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       	=> esc_html__( 'Sticky Menu Text Color On Hover', 'ideabuz' ),
		'id'         	=> $prefix . 'sticky_menu_text_color_on_hover',
		'type'    	 	=> 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option-for-mobile',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       	=> esc_html__( 'Sticky Menu Right Side Icon Color', 'ideabuz' ),
		'id'         	=> $prefix . 'sticky_right_side_icon_color',
		'type'    	 	=> 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option-for-mobile',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       	=> esc_html__( 'Sticky Submenu Background Color', 'ideabuz' ),
		'id'         	=> $prefix . 'sticky_submenu_background_color',
		'type'    	 	=> 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option-for-mobile',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       	=> esc_html__( 'Sticky Submenu Text Color', 'ideabuz' ),
		'id'         	=> $prefix . 'sticky_submenu_text_color',
		'type'    	 	=> 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option-for-mobile',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'name'       	=> esc_html__( 'Sticky Submenu Text Color On Hover', 'ideabuz' ),
		'id'         	=> $prefix . 'sticky_submenu_text_color_on_hover',
		'type'    	 	=> 'colorpicker',
		'tab'  			=> 'ideabuz-menu-option-for-mobile',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	
	$ideabuz_meta->add_field( array(
		'desc'       => esc_html__( 'Want To Show Page Header Click Yes Edit And Update', 'ideabuz' ),
		'id'         => $prefix . 'page_header',
		'type'    	 => 'switch',
		'label'      => array(
			'on'	=> 'Yes',
			'off'	=> 'No'
		),
		'tab'  			=> 'ideabuz-header-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'desc'       => esc_html__( 'Choose Setting', 'ideabuz' ),
		'id'         => $prefix . 'global_style',
		'type'             => 'select',
		'default'          => 'global',
		'options'          => array(
			'global' 	=> esc_html__( 'Global Setting', 'ideabuz' ),
			'single'    => esc_html__( 'Single Page Setting', 'ideabuz' ),
		),
		'tab'  			=> 'ideabuz-header-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'desc'       => esc_html__( 'Header Text and Breadcrumb Align', 'ideabuz' ),
		'id'         => $prefix . 'content_align',
		'type'             => 'select',
		'default'          => 'center',
		'options'          => array(
			'left' 		=> esc_html__( 'Left', 'ideabuz' ),
			'center'    => esc_html__( 'Center', 'ideabuz' ),
			'right'    	=> esc_html__( 'Right', 'ideabuz' ),
		),
		'tab'  			=> 'ideabuz-header-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'desc'       => esc_html__( 'Page Header Background', 'ideabuz' ),
		'id'         => $prefix . 'page_header_bg',
		'type'    	 => 'file',
		'tab'  			=> 'ideabuz-header-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'desc'       => esc_html__( 'Page Header Background Color', 'ideabuz' ),
		'id'         => $prefix . 'page_header_bg_color',
		'type'    	 => 'colorpicker',
		'tab'  			=> 'ideabuz-header-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'desc'       => esc_html__( 'Page Header Background Repeat', 'ideabuz' ),
		'id'         => $prefix . 'page_header_bg_repeat',
		'type'             => 'select',
		'default'          => 'default',
		'options'          => array(
			'default' 			=> esc_html__( 'Default', 'ideabuz' ),
			'norepeat' 			=> esc_html__( 'No Repeat', 'ideabuz' ),
			'repeatall'     	=> esc_html__( 'Repeat All', 'ideabuz' ),
			'repeathor'    		=> esc_html__( 'Repeat Horizontally', 'ideabuz' ),
			'repeatver'    		=> esc_html__( 'Repeat Vertically', 'ideabuz' ),
			'inherit'    		=> esc_html__( 'Inherit', 'ideabuz' ),
		),
		'tab'  			=> 'ideabuz-header-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'desc'       => esc_html__( 'Page Header Background Size', 'ideabuz' ),
		'id'         => $prefix . 'page_header_bg_size',
		'type'             => 'select',
		'default'          => 'default',
		'options'          => array(
			'default' 			=> esc_html__( 'Default', 'ideabuz' ),
			'inherit' 			=> esc_html__( 'Inherit', 'ideabuz' ),
			'cover'     		=> esc_html__( 'Cover', 'ideabuz' ),
			'contain'    		=> esc_html__( 'Contain', 'ideabuz' ),
		),
		'tab'  			=> 'ideabuz-header-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'desc'       => esc_html__( 'Page Header Background Attachment', 'ideabuz' ),
		'id'         => $prefix . 'page_header_bg_attachment',
		'type'             => 'select',
		'default'          => 'norepeat',
		'options'          => array(
			'default' 			=> esc_html__( 'Default', 'ideabuz' ),
			'fixed' 			=> esc_html__( 'Fixed', 'ideabuz' ),
			'scroll'     		=> esc_html__( 'Scroll', 'ideabuz' ),
			'inherit'    		=> esc_html__( 'Inherit', 'ideabuz' ),
		),
		'tab'  			=> 'ideabuz-header-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'desc'       => esc_html__( 'Page Header Background Position', 'ideabuz' ),
		'id'         => $prefix . 'page_header_bg_position',
		'type'             => 'select',
		'default'          => 'default',
		'options'          => array(
			'default' 			=> esc_html__( 'Default', 'ideabuz' ),
			'lefttop' 			=> esc_html__( 'Left Top', 'ideabuz' ),
			'leftcenter' 		=> esc_html__( 'Left Center', 'ideabuz' ),
			'leftbottom' 		=> esc_html__( 'Left Bottom', 'ideabuz' ),
			'centertop' 		=> esc_html__( 'Center Top', 'ideabuz' ),
			'centercenter'     	=> esc_html__( 'Center Center', 'ideabuz' ),
			'centerbottom'    	=> esc_html__( 'Center Bottom', 'ideabuz' ),
			'righttop'    		=> esc_html__( 'Right Top', 'ideabuz' ),
			'rightcenter'    	=> esc_html__( 'Right Center', 'ideabuz' ),
			'rightbottom'    	=> esc_html__( 'Right Bottom', 'ideabuz' ),
		),
		'tab'  			=> 'ideabuz-header-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'desc'       => esc_html__( 'Show Or Hide Page Header', 'ideabuz' ),
		'id'         => $prefix . 'page_header_show_hide',
		'type'    	 => 'switch',
		'label'      => array(
			'on'	=> 'Yes',
			'off'	=> 'No'
		),
		'tab'  			=> 'ideabuz-header-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'desc'       => esc_html__( 'Page Header Text Color', 'ideabuz' ),
		'id'         => $prefix . 'page_header_text_color',
		'type'    	 => 'colorpicker',
		'tab'  			=> 'ideabuz-header-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'desc'       => esc_html__( 'Enable Breadcrumb?', 'ideabuz' ),
		'id'         => $prefix . 'breadcrumb_enable',
		'type'    	 => 'switch',
		'label'      => array(
			'on'	=> 'Yes',
			'off'	=> 'No'
		),
		'tab'  			=> 'ideabuz-header-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'desc'       => esc_html__( 'Breadcrumb Link Color', 'ideabuz' ),
		'id'         => $prefix . 'breadcrumb_link_color',
		'type'    	 => 'colorpicker',
		'tab'  			=> 'ideabuz-header-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'desc'       => esc_html__( 'Breadcrumb Link Hover Color', 'ideabuz' ),
		'id'         => $prefix . 'breadcrumb_link_hover_color',
		'type'    	 => 'colorpicker',
		'tab'  			=> 'ideabuz-header-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'desc'       => esc_html__( 'Breadcrumb Active Color', 'ideabuz' ),
		'id'         => $prefix . 'breadcrumb_active_color',
		'type'    	 => 'colorpicker',
		'tab'  			=> 'ideabuz-header-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	$ideabuz_meta->add_field( array(
		'desc'       => esc_html__( 'Breadcrumb Divider Color', 'ideabuz' ),
		'id'         => $prefix . 'breadcrumb_divider_color',
		'type'    	 => 'colorpicker',
		'tab'  			=> 'ideabuz-header-option',
		'render_row_cb' => array( 'CMB2_Tabs', 'tabs_render_row_cb' ),
	) );
	/********************************\
		Service Post Type
	\********************************/
	$ideabuz_meta = new_cmb2_box( array(
		'id'            => $prefixpage . 'service_post_type',
		'title'         => esc_html__( 'More Data', 'ideabuz' ),
		'object_types'  => array( 'ideabuz_service' ), // Post type
	) );
	$ideabuz_meta->add_field( array(
		'name'    	 => esc_html__( 'Service Thumbnail Image On Hover', 'ideabuz' ),
		'desc'       => esc_html__( 'Set Service Thumbnail Image When Hover', 'ideabuz' ),
		'id'         => $prefix . 'service_image_type_two',
		'type'       => 'file',
	) );
	$ideabuz_meta->add_field( array(
		'name'    	 => esc_html__( 'Read More Button Text', 'ideabuz' ),
		'desc'       => esc_html__( 'Insert Read More Button Text.', 'ideabuz' ),
		'id'         => $prefix . 'read_more_button_text',
		'type'       => 'text',
	) );
	$ideabuz_meta->add_field( array(
		'name'    	 => esc_html__( 'Read More Button Url', 'ideabuz' ),
		'desc'       => esc_html__( 'Insert Read More Button Url.', 'ideabuz' ),
		'id'         => $prefix . 'read_more_button_url',
		'type'       => 'text',
	) );

	
	/********************************\
		Pricing Post Type
	\********************************/
	$ideabuz_meta = new_cmb2_box( array(
		'id'            => $prefixpage . 'price_tab_nav',
		'title'         => esc_html__( 'Add Price', 'ideabuz' ),
		'object_types'  => array( 'ideabuz_price' ), // Post type
	) );
	
	$ideabuz_meta->add_field( array(
		'name'    	 => esc_html__( 'Plan Price', 'ideabuz' ),
		'desc'       => esc_html__( 'Set Plan Price', 'ideabuz' ),
		'id'         => $prefix . 'plan_price',
		'type'       => 'text',
	) );
	$ideabuz_meta = new_cmb2_box( array(
		'id'            => $prefixpage . 'price_tab_data',
		'title'         => esc_html__( 'Add Price Description', 'ideabuz' ),
		'object_types'  => array( 'ideabuz_price' ), // Post type
	) );
	$ideabuz_meta->add_field( array(
		'name'    	 => esc_html__( 'Plan Price Title Left Side', 'ideabuz' ),
		'desc'       => esc_html__( 'Set Plan Price Title For Left Side', 'ideabuz' ),
		'id'         => $prefix . 'left_title',
		'type'       => 'text',
	) );
	$group_field_id = $ideabuz_meta->add_field( array(
		'id'          =>  $prefix . 'price_desc_repeat_group_left',
		'type'        => 'group',
		'description' => esc_html__( 'Add Price Table Left Side Point', 'ideabuz' ),
		'options'     => array(
			'group_title'       => esc_html__( 'Point {#}', 'ideabuz' ), // since version 1.1.4, {#} gets replaced by row number
			'add_button'        => esc_html__( 'Add Another Point', 'ideabuz' ),
			'remove_button'     => esc_html__( 'Remove Point', 'ideabuz' ),
			'sortable'          => true,
		),
	) );
	$ideabuz_meta->add_field( array(
		'name'    	 => esc_html__( 'Plan Price Title Right Side', 'ideabuz' ),
		'desc'       => esc_html__( 'Set Plan Price Title For Right Side', 'ideabuz' ),
		'id'         => $prefix . 'right_title',
		'type'       => 'text',
	) );
	$ideabuz_meta->add_field( array(
		'name'    	 => esc_html__( 'Plan Price Descripton Right Side', 'ideabuz' ),
		'desc'       => esc_html__( 'Set Plan Price Descripton For Right Side', 'ideabuz' ),
		'id'         => $prefix . 'right_side_description',
		'type'       => 'textarea',
	) );
	// Id's for group's fields only need to be unique for the group. Prefix is not needed.
	$ideabuz_meta->add_group_field( $group_field_id, array(
		'name' => 'Point Icon',
		'id'   =>  $prefix . 'left_point_icon',
		'type' => 'fontawesome_icon',
	) );
	$ideabuz_meta->add_group_field( $group_field_id, array(
		'name' => 'Point Title',
		'id'   =>  $prefix . 'left_point',
		'type' => 'text',
	) );
	
	$right_side_group = $ideabuz_meta->add_field( array(
		'id'          =>  $prefix . 'price_desc_repeat_group_right_side',
		'type'        => 'group',
		'description' => esc_html__( 'Add Price Table Right Side Point', 'ideabuz' ),
		'options'     => array(
			'group_title'       => esc_html__( 'Point {#}', 'ideabuz' ), // since version 1.1.4, {#} gets replaced by row number
			'add_button'        => esc_html__( 'Add Another Point', 'ideabuz' ),
			'remove_button'     => esc_html__( 'Remove Point', 'ideabuz' ),
			'sortable'          => true,
		),
	) );
	$ideabuz_meta->add_group_field( $right_side_group, array(
		'name' => 'Point Icon',
		'id'   =>  $prefix . 'right_point_icon',
		'type' => 'fontawesome_icon',
	) );
	// Id's for group's fields only need to be unique for the group. Prefix is not needed.
	$ideabuz_meta->add_group_field( $right_side_group, array(
		'name' 		=> 'Point Title',
		'id'   		=>  $prefix . 'right_point',
		'type' 		=> 'text',
		// 'repeatable' => true, // Repeatable fields are supported w/in repeatable groups (for most types)
	) );
	$ideabuz_meta->add_field( array(
		'name'    	 => esc_html__( 'Right Side Button Text', 'ideabuz' ),
		'desc'       => esc_html__( 'Set Right Side Button Text', 'ideabuz' ),
		'id'         => $prefix . 'button_text',
		'type'       => 'text',
	) );
	$ideabuz_meta->add_field( array(
		'name'    	 => esc_html__( 'Button Url', 'ideabuz' ),
		'desc'       => esc_html__( 'Set Button Url', 'ideabuz' ),
		'id'         => $prefix . 'button_url',
		'type'       => 'text',
		'defualt'	 => '#',
	) );
	
	/********************************\
		Project Post Type
	\********************************/
	$ideabuz_meta = new_cmb2_box( array(
		'id'            => $prefixpage . 'project_post',
		'title'         => esc_html__( 'Add Project Data', 'ideabuz' ),
		'object_types'  => array( 'ideabuz_project' ), // Post type
	) );
	$ideabuz_meta->add_field( array(
		'name'    	 => esc_html__( 'Client Name', 'ideabuz' ),
		'desc'       => esc_html__( 'Set Client Name', 'ideabuz' ),
		'id'         => $prefix . 'client_name',
		'type'       => 'text',
	) );
	$ideabuz_meta->add_field( array(
		'name'    	 => esc_html__( 'Button Text', 'ideabuz' ),
		'desc'       => esc_html__( 'Set Read More Button Text', 'ideabuz' ),
		'id'         => $prefix . 'project_read_more',
		'type'       => 'text',
	) );
	$ideabuz_meta->add_field( array(
		'name'    	 => esc_html__( 'Button Url', 'ideabuz' ),
		'desc'       => esc_html__( 'Set Read More Button Url. ( Default Is Single Post )', 'ideabuz' ),
		'id'         => $prefix . 'project_read_more_url',
		'type'       => 'text',
	) );
	$ideabuz_meta->add_field( array(
		'name'    	 => esc_html__( 'Designation', 'ideabuz' ),
		'desc'       => esc_html__( 'Client Designation', 'ideabuz' ),
		'id'         => $prefix . 'client_designation',
		'type'       => 'text',
	) );
	$ideabuz_meta->add_field( array(
		'name'    	 => esc_html__( 'Perspective', 'ideabuz' ),
		'desc'       => esc_html__( 'Project Perspective', 'ideabuz' ),
		'id'         => $prefix . 'project_perspective',
		'type'       => 'text',
		'repeatable' => true,	
	) );
}