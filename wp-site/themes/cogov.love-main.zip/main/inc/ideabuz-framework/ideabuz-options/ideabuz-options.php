<?php
    /**
     * ReduxFramework Sample Config File
     * For full documentation, please visit: http://docs.reduxframework.com/
     */

    if ( ! class_exists( 'Redux' ) ) {
        return;
    }
 
    // This is your option name where all the Redux data is stored.
    $opt_name = "ideabuz_opt"; 

    // This line is only for altering the demo. Can be easily removed.
    $opt_name = apply_filters( 'redux_demo/opt_name', $opt_name );

    /*
     *
     * --> Used within different fields. Simply examples. Search for ACTUAL DECLARATION for field examples
     *
     */

    $sampleHTML = '';
    function WP_ReFilesystem( $args = false, $context = false, $allow_relaxed_file_ownership = false ) {
        if ( file_exists( get_template_directory() . '/info-html.html' ) ) {
            Redux_Functions::initWpFilesystem();

            global $wp_filesystem;

            $sampleHTML = $wp_filesystem->get_contents( get_template_directory(). '/info-html.html' );
        }
    }

	$alowhtml = array(
		'p' => array(
			'class' => array()
		),
		'span' => array()
	);

    /**
     * ---> SET ARGUMENTS
     * All the possible arguments for Redux.
     * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
     * */

    $theme = wp_get_theme(); // For use with some settings. Not necessary.

    $args = array(
        // TYPICAL -> Change these values as you need/desire
        'opt_name'             => $opt_name,
        // This is where your data is stored in the database and also becomes your global variable name.
        'display_name'         => $theme->get( 'Name' ),
        // Name that appears at the top of your panel
        'display_version'      => $theme->get( 'Version' ),
        // Version that appears at the top of your panel
        'menu_type'            => 'menu',
        //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
        'allow_sub_menu'       => true,
        // Show the sections below the admin menu item or not
        'menu_title'           => esc_html__( 'Ideabuz Options', 'ideabuz' ),
        'page_title'           => esc_html__( 'Ideabuz Options', 'ideabuz' ),
        // You will need to generate a Google API key to use this feature.
        // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
        'google_api_key'       => '',
        // Set it you want google fonts to update weekly. A google_api_key value is required.
        'google_update_weekly' => false,
        // Must be defined to add google fonts to the typography module
        'async_typography'     => true,
        // Use a asynchronous font on the front end or font string
        //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
        'admin_bar'            => true,
        // Show the panel pages on the admin bar
        'admin_bar_icon'       => 'dashicons-portfolio',
        // Choose an icon for the admin bar menu
        'admin_bar_priority'   => 50,
        // Choose an priority for the admin bar menu
        'global_variable'      => '',
        // Set a different name for your global variable other than the opt_name
        'dev_mode'             => false,
        // Show the time the page took to load, etc
        'update_notice'        => true,
        // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
        'customizer'           => true,
        // Enable basic customizer support
        //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
        //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

        // OPTIONAL -> Give you extra features
        'page_priority'        => null,
        // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
        'page_parent'          => 'themes.php',
        // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
        'page_permissions'     => 'manage_options',
        // Permissions needed to access the options panel.
        'menu_icon'            => '',
        // Specify a custom URL to an icon
        'last_tab'             => '',
        // Force your panel to always open to a specific tab (by id)
        'page_icon'            => 'icon-themes',
        // Icon displayed in the admin panel next to your menu_title
        'page_slug'            => '',
        // Page slug used to denote the panel, will be based off page title then menu title then opt_name if not provided
        'save_defaults'        => true,
        // On load save the defaults to DB before user clicks save or not
        'default_show'         => false,
        // If true, shows the default value next to each field that is not the default value.
        'default_mark'         => '',
        // What to print by the field's title if the value shown is default. Suggested: *
        'show_import_export'   => true,
        // Shows the Import/Export panel when not used as a field.

        // CAREFUL -> These options are for advanced use only
        'transient_time'       => 60 * MINUTE_IN_SECONDS,
        'output'               => true,
        // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
        'output_tag'           => true,
        // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
        // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

        // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
        'database'             => '',
        // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
        'use_cdn'              => true,
        // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

        // HINTS
        'hints'                => array(
            'icon'          => 'el el-question-sign',
            'icon_position' => 'right',
            'icon_color'    => 'lightgray',
            'icon_size'     => 'normal',
            'tip_style'     => array(
                'color'   => 'red',
                'shadow'  => true,
                'rounded' => false,
                'style'   => '',
            ),
            'tip_position'  => array(
                'my' => 'top left',
                'at' => 'bottom right',
            ),
            'tip_effect'    => array(
                'show' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'mouseover',
                ),
                'hide' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'click mouseleave',
                ),
            ),
        )
    );

    Redux::setArgs( $opt_name, $args );

    /*
     * ---> END ARGUMENTS
     */


    /*
     * ---> START HELP TABS
     */

    $tabs = array(
        array(
            'id'      => 'redux-help-tab-1',
            'title'   => esc_html__( 'Theme Information 1', 'ideabuz' ),
            'content' => wp_kses( __( '<p>This is the tab content, HTML is allowed.</p>', 'ideabuz' ), $alowhtml )
        ),
        array(
            'id'      => 'redux-help-tab-2',
            'title'   => esc_html__( 'Theme Information 2', 'ideabuz' ),
            'content' => wp_kses( __( '<p>This is the tab content, HTML is allowed.</p>', 'ideabuz' ), $alowhtml )
        )
    );
    Redux::setHelpTab( $opt_name, $tabs );

    // Set the help sidebar
    $content = wp_kses( __('<p>This is the sidebar content, HTML is allowed.</p>', 'ideabuz' ), $alowhtml );
    Redux::setHelpSidebar( $opt_name, $content );

    // -> START General Fields

    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'General', 'ideabuz' ),
        'id'               => 'ideabuz_general',
        'customizer_width' => '450px',
        'icon'             => 'el el-cog el-spin',
        'fields'           => array(
            array(
                'id'       => 'ideabuz_display_preloader',
                'type'     => 'switch',
                'title'    => esc_html__( 'Display Preloader', 'ideabuz' ),
                'subtitle' => esc_html__( 'Switch On to Display Preloader.', 'ideabuz' ),
                'default'  => true,
            ),
            array(
                'id'       => 'ideabuz_preloader_image',
                'type'     => 'media',
                'compiler' => 'true',
                'url'      => true,
                'title'    => esc_html__( 'Preloader Image', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Preloader Image', 'ideabuz' ),
                'required' => array('ideabuz_display_preloader','equals','1'),
            ),
            array(
                'id'       => 'ideabuz_preloader_border_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Preloader Border Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Preloader Border Color.', 'ideabuz' ),
                'required' => array('ideabuz_display_preloader','equals','1'),
            ),
            array(
                'id'       => 'ideabuz_preloader_background_color',
                'type'     => 'color',
                'output'   => array( 'background-color'   =>   '.preloader' ),
                'title'    => esc_html__( 'Preloader Background Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Preloader Background Color', 'ideabuz' ),
                'required' => array( 'ideabuz_display_preloader','equals','1' ),
            ),
            array(
                'id'       => 'ideabuz_display_backtotop',
                'type'     => 'switch',
                'title'    => esc_html__( 'Display Back To Top Button', 'ideabuz' ),
                'subtitle' => esc_html__( 'Switch On to Display back to top button.', 'ideabuz' ),
                'default'  => true,
            ),
            array(
                'id'       => 'ideabuz_backtotop_text',
                'type'     => 'text',
                'title'    => esc_html__( 'Back To Top Text On Hover', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Back To Top Text On Hover', 'ideabuz' ),
                'default'  => esc_html__( 'Back To Top','ideabuz' ),
                'required' => array( 'ideabuz_display_backtotop','equals','1' ),
            ),
            array(
                'id'       => 'ideabuz_backtotop_text_color',
                'type'     => 'color',
                'output'   => array( ".back-toop-tooltip span" ),
                'title'    => esc_html__( 'Back To Top Text Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Back To Top Text Color', 'ideabuz' ),
                'required' => array( 'ideabuz_display_backtotop','equals','1' ),
            ),
            array(
                'id'       => 'ideabuz_backtotop_icon_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Back To Top Icon Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Back To Top Icon Color', 'ideabuz' ),
                'required' => array( 'ideabuz_display_backtotop','equals','1' ),
            ),
            array(
                'id'       => 'ideabuz_backtotop_icon_background_color',
                'type'     => 'color',
                'output'   => array( 'background' => '.back-to-top' ),
                'title'    => esc_html__( 'Back To Top Background Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Back To Top Background Color', 'ideabuz' ),
                'required' => array( 'ideabuz_display_backtotop','equals','1' ),
            ),
            array(
                'id'          => 'ideabuz_body_fonts',
                'type'        => 'typography',
                'title'       => esc_html__('Body Typography', 'ideabuz'),
                'google'      => true,
                'font-backup' => true,
                'output'      => array( 'body', 'p' ),
                'units'       =>'px',
                'subtitle'    => esc_html__('Typography option with each property can be called individually.', 'ideabuz'),
                'text-align'  => false,
                'line-height' => false,
                'font-backup' => false,
                'color'       => false,
                'font-size'   => false,
                'subsets'     => false,
                'line-height' => false,
            ),
            array(
                'id'          => 'ideabuz_header_fonts',
                'type'        => 'typography',
                'title'       => esc_html__('Heading Typography', 'ideabuz'),
                'google'      => true,
                'font-backup' => true,
                'output'      => array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'),
                'units'       => 'px',
                'subtitle'    => esc_html__('Typography option with each property can be called individually.', 'ideabuz'),
                'text-align'  => false,
                'line-height' => false,
                'font-backup' => false,
                'color'       => false,
                'font-size'   => false,
                'subsets'     => false,
                'line-height' => false,
            ),
            array(
                'id'       => 'ideabuz_unlimited_color',
                'type'     => 'color',
                'title'    => esc_html__('Custom Theme Color', 'ideabuz'),
                'subtitle' => esc_html__('Pick a unlimited mian color for the theme (default: #3f5efb).', 'ideabuz'),
                'validate' => 'color'
            ),
			array(
                'id'       => 'ideabuz_map_apikey',
                'type'     => 'text',
                'title'    => esc_html__( 'API Key', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set your google map api key', 'ideabuz' )
            ),

        )
    ) );

    /* End General Fields */


    // -> START Header / Menu
    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Header', 'ideabuz' ),
        'id'               => 'ideabuz_header',
        'customizer_width' => '400px',
        'icon'             => 'el el-adjust'
    ) );
    //start nav bar
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Header Nav bar', 'ideabuz'),
        'id'         => 'ideabuz_navbar_header_option',
        'icon'       => 'el el-hand-right',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'ideabuz_site_logo',
                'type'     => 'media',
                'url'      => true,
                'title'    => esc_html__( 'Logo', 'ideabuz' ),
                'compiler' => 'true',
                'subtitle' => esc_html__( 'Upload your site logo for header ( recommendation png format ).', 'ideabuz' ),
            ),
			array(
                'id'       => 'ideabuz_site_logo_dimensions',
                'type'     => 'dimensions',
                'output'   => array( '.header .logo a img.default-logo' ),
                'units'    => array('em','px','%'),
                'title'    => esc_html__('Logo Dimensions (Width/Height).', 'ideabuz'),
                'subtitle' => esc_html__('Set logo dimensions to choose width, height, and unit.', 'ideabuz'),
            ),
			array(
                'id'       => 'ideabuz_site_logomargin_dimensions',
                'type'     => 'spacing',
				'mode'     => 'margin',
                'output'   => array( '.header .logo a img.default-logo' ),
				'units_extended' => 'false',
                'units'    => array('em','px' ),
                'title'    => esc_html__('Logo Top and Bottom Margin.', 'ideabuz'),
				'left'     => false,
                'right'    => false,
                'subtitle' => esc_html__('Set logo top and bottom margin.', 'ideabuz'),
                'default'            => array(
                    'margin-top'     => '0px',
                    'margin-bottom'  => '0px',
                    'units'          => 'px'
                )
            ),
            array(
                'id'       => 'ideabuz_site_title',
                'type'     => 'text',
                'validate' => 'html',
                'title'    => esc_html__( 'Text Logo', 'ideabuz' ),
                'subtitle' => esc_html__( 'Write your logo text use as logo ( You can use span tag for text color ).', 'ideabuz' ),
                'default'  => wp_kses( esc_html__( 'ideabuz', 'ideabuz' ), $alowhtml ),
            ),
            array(
                'id'       => 'ideabuz_text_logo_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Text Logo Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Text Logo Color.  Make Sure You Using Text Logo', 'ideabuz' ),
                'output'   => array( '.header .logo h2 a.text-logo' ),
            ),
            array(
                'id'       => 'ideabuz_text_logo_color_hover',
                'type'     => 'color',
                'title'    => esc_html__( 'Text Logo Color On Hover', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Text Logo Color When hover. Make Sure You Using Text Logo', 'ideabuz' ),
                'output'   => array( '.header .logo h2 a:hover' ),
            ),
            array(
                'id'       => 'ideabuz_sticky_site_logo',
                'type'     => 'media',
                'url'      => true,
                'title'    => esc_html__( 'Sticky Logo', 'ideabuz' ),
                'compiler' => 'true',
                'subtitle' => esc_html__( 'Upload Sticky logo for header ( recommendation png format ).', 'ideabuz' ),
            ),
			array(
                'id'       => 'ideabuz_sticky_site_logo_dimensions',
                'type'     => 'dimensions',
                'output'   => array( '.header .logo a img.sticky-logo' ),
                'units'    => array('em','px','%'),
                'title'    => esc_html__('Sticky Logo Dimensions (Width/Height).', 'ideabuz'),
                'subtitle' => esc_html__('Set Sticky logo dimensions to choose width, height, and unit.', 'ideabuz'),
            ),
			array(
                'id'       => 'ideabuz_sticky_site_logomargin_dimensions',
                'type'     => 'spacing',
				'mode'     => 'margin',
                'output'   => array( '.header .logo a img.sticky-logo' ),
				'units_extended' => 'false',
                'units'    => array('em','px' ),
                'title'    => esc_html__('Sticky Logo Top and Bottom Margin.', 'ideabuz'),
				'left'     => false,
                'right'    => false,
                'subtitle' => esc_html__( 'Set Sticky logo top and bottom margin.', 'ideabuz' ),
                'default'            => array(
                    'margin-top'     => '0px',
                    'margin-bottom'  => '0px',
                    'units'          => 'px'
                )
            ),
            
        ),
    ) );
    //    end header nav
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Menu', 'ideabuz'),
        'id'         => 'ideabuz_page_header_menu_option',
        'icon'       => 'el el-credit-card',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'ideabuz_header_background_color',
                'type'     => 'color',
                'output'   => array( 'background-color'  =>   'header.header' ),
                'title'    => esc_html__( 'Header Background Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Header Background Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_menu_color',
                'type'     => 'color',
                'output'   => array('.header .header-main .main-menu .nav li a'),
                'title'    => esc_html__( 'Header Menu Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Header Menu Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_menu_active_color',
                'type'     => 'color',
                'output'   => array('.header .header-main.style--one .main-menu .nav li.current-menu-item > a, .header .header-main.style--one .main-menu .nav li.current-menu-parent > a,.header .header-main.style--one .main-menu .nav li.current-menu-ancestor > a'),
                'title'    => esc_html__( 'Header Menu Active Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Header Menu Active Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_menu_hover_color',
                'type'     => 'color',
                'output'   => array('.header .header-main .main-menu .nav li a:hover'),
                'title'    => esc_html__( 'Header Menu Hover Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Header Menu Hover  Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_sub_menu_bg',
                'type'     => 'color',
                'output'   => array( 'background-color' => '.header .header-main.style--one .main-menu .nav li ul' ),
                'title'    => esc_html__( 'Header Sub Menu Background Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Header Sub Menu Background Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_sub_menu_text_color',
                'type'     => 'color',
                'output'   => array('.header .header-main.style--one .main-menu .nav li ul li a'),
                'title'    => esc_html__( 'Header Sub Menu Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Header Sub Menu Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_sub_menu_hover_text_color',
                'type'     => 'color',
                'output'   => array('.header .header-main.style--one .main-menu .nav li ul li a:hover'),
                'title'    => esc_html__( 'Header Sub Menu Hover Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Header Sub Menu Hover Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_sticky_menu_bg',
                'type'     => 'color',
                'output'   => array( 'background-color' => '.header .header-main.sticky' ),
                'title'    => esc_html__( 'Sticky Menu Background Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Sticky Menu Background Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_sticky_menu_color',
                'type'     => 'color',
                'output'   => array( '.header .header-main.sticky .main-menu .nav > li > a' ),
                'title'    => esc_html__( 'Sticky Menu Text Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Sticky Menu Text Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_sticky_menu_active_color',
                'type'     => 'color',
                'output'   => array('.header .header-main.sticky .main-menu .nav li.current-menu-item > a, .header .header-main.sticky .main-menu .nav li.current-menu-parent > a,.header .header-main.sticky .main-menu .nav li.current-menu-ancestor > a'),
                'title'    => esc_html__( 'Sticky Menu Active Text Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Sticky Menu Active Text Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_sticky_menu_hover_color',
                'type'     => 'color',
                'output'   => array('.header .header-main.sticky .main-menu .nav li a:hover'),
                'title'    => esc_html__( 'Sticky Menu Hover Text Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Sticky Menu Hover Text Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_sticky_sub_menu_bg',
                'type'     => 'color',
                'output'   => array( 'background-color' => '.header .header-main.sticky .main-menu .nav li ul' ),
                'title'    => esc_html__( 'Sticky Sub Menu Background Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Sticky Sub Menu Background Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_sticky_sub_menu_text_color',
                'type'     => 'color',
                'output'   => array( '.header .header-main.sticky .main-menu .nav li ul li a'),
                'title'    => esc_html__( 'Sticky Sub Menu Text Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Sticky Sub Menu Text Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_sticky_sub_menu_hover_text_color',
                'type'     => 'color',
                'output'   => array('.header .header-main.sticky .main-menu .nav li ul li a:hover'),
                'title'    => esc_html__( 'Header Sub Menu Hover Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Header Sub Menu Hover Color', 'ideabuz' ),
            ),
        )
    ) );
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Responsive Menu', 'ideabuz'),
        'id'         => 'ideabuz_mobile_menu_option',
        'icon'       => 'el el-credit-card',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'        => 'menu_button_color',
                'type'      => 'color',
                'title'     => esc_html__( 'Menu Button Color', 'ideabuz' ),
                'subtitle'  => esc_html__( 'Set Menu Button Color', 'ideabuz' ),
            ),
            array(
                'id'        => 'cross_button_color',
                'type'      => 'color',
                'title'     => esc_html__( 'Menu Cross Button Color', 'ideabuz' ),
                'subtitle'  => esc_html__( 'Set Menu Cross Button Color', 'ideabuz' ),
            ),
            array(
                'id'        => 'menu_background_color',
                'type'      => 'color',
                'title'     => esc_html__( 'Menu Background Color', 'ideabuz' ),
                'subtitle'  => esc_html__( 'Set Menu Background Color', 'ideabuz' ),
            ),
            array(
                'id'        => 'menu_text_color',
                'type'      => 'color',
                'title'     => esc_html__( 'Menu Text Color', 'ideabuz' ),
                'subtitle'  => esc_html__( 'Set Menu Text Color', 'ideabuz' ),
            ),
            array(
                'id'        => 'menu_text_color_on_hover',
                'type'      => 'color',
                'title'     => esc_html__( 'Menu Text Color On Hover', 'ideabuz' ),
                'subtitle'  => esc_html__( 'Set Menu Text Color On Hover', 'ideabuz' ),
            ),
            array(
                'id'        => 'right_side_icon_color',
                'type'      => 'color',
                'title'     => esc_html__( 'Menu Icon Color', 'ideabuz' ),
                'subtitle'  => esc_html__( 'Set Menu Icon Color', 'ideabuz' ),
            ),
            array(
                'id'        => 'submenu_background_color',
                'type'      => 'color',
                'title'     => esc_html__( 'Submenu Background Color', 'ideabuz' ),
                'subtitle'  => esc_html__( 'Set Submenu Background Color', 'ideabuz' ),
            ),
            array(
                'id'        => 'submenu_text_color',
                'type'      => 'color',
                'title'     => esc_html__( 'Submenu Text Color', 'ideabuz' ),
                'subtitle'  => esc_html__( 'Set Submenu Text Color', 'ideabuz' ),
            ),
            array(
                'id'        => 'submenu_text_color_on_hover',
                'type'      => 'color',
                'title'     => esc_html__( 'Submenu Text Color On Hover', 'ideabuz' ),
                'subtitle'  => esc_html__( 'Set Submenu Text Color On Hover', 'ideabuz' ),
            ),
            array(
                'id'        => 'sticky_menu_background_color',
                'type'      => 'color',
                'title'     => esc_html__( 'Sticky Top Menu Background Color', 'ideabuz' ),
                'subtitle'  => esc_html__( 'Set Sticky Top Menu Background Color', 'ideabuz' ),
            ),
            array(
                'id'        => 'sticky_menu_button_color',
                'type'      => 'color',
                'title'     => esc_html__( 'Sticky Menu Button Color', 'ideabuz' ),
                'subtitle'  => esc_html__( 'Set Sticky Menu Button Color', 'ideabuz' ),
            ),
            array(
                'id'        => 'sticky_menu_cross_button_color',
                'type'      => 'color',
                'title'     => esc_html__( 'Sticky Menu Cross Button Color', 'ideabuz' ),
                'subtitle'  => esc_html__( 'Set Sticky Menu Cross Button Color', 'ideabuz' ),
            ),
            array(
                'id'        => 'sticky_menu_background_color_two',
                'type'      => 'color',
                'title'     => esc_html__( 'Sticky Menu Background Color', 'ideabuz' ),
                'subtitle'  => esc_html__( 'Set Sticky Menu Background Color', 'ideabuz' ),
            ),
            array(
                'id'        => 'sticky_menu_text_color',
                'type'      => 'color',
                'title'     => esc_html__( 'Sticky Menu Text Color', 'ideabuz' ),
                'subtitle'  => esc_html__( 'Set Sticky Menu Text Color', 'ideabuz' ),
            ),
            array(
                'id'        => 'sticky_menu_text_color_on_hover',
                'type'      => 'color',
                'title'     => esc_html__( 'Sticky Menu Text Color On Hover', 'ideabuz' ),
                'subtitle'  => esc_html__( 'Set Sticky Menu Text Color On Hover', 'ideabuz' ),
            ),
            array(
                'id'        => 'sticky_right_side_icon_color',
                'type'      => 'color',
                'title'     => esc_html__( 'Sticky Menu Icon Color', 'ideabuz' ),
                'subtitle'  => esc_html__( 'Set Sticky Menu Icon Color', 'ideabuz' ),
            ),
            array(
                'id'        => 'sticky_submenu_background_color',
                'type'      => 'color',
                'title'     => esc_html__( 'Sticky Submenu Background Color', 'ideabuz' ),
                'subtitle'  => esc_html__( 'Set Sticky Submenu Background Color', 'ideabuz' ),
            ),
            array(
                'id'        => 'sticky_submenu_text_color',
                'type'      => 'color',
                'title'     => esc_html__( 'Sticky Submenu Text Color', 'ideabuz' ),
                'subtitle'  => esc_html__( 'Set Sticky Submenu Text Color', 'ideabuz' ),
            ),
            array(
                'id'        => 'sticky_submenu_text_color_on_hover',
                'type'      => 'color',
                'title'     => esc_html__( 'Sticky Submenu Text Color On Hover', 'ideabuz' ),
                'subtitle'  => esc_html__( 'Set Sticky Submenu Text Color On Hover', 'ideabuz' ),
            ),
        )
    ));
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Page Header', 'ideabuz'),
        'id'         => 'ideabuz_page_header_option',
        'icon'       => 'el el-credit-card',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'        => 'ideabuz_header_content_alignment',
                'type'      => 'button_set',
                'title'     => esc_html__( 'Title And Breadcrumb Alignment', 'ideabuz' ),
                'subtitle'  => esc_html__( 'Set Title And Breadcrumb Alignment', 'ideabuz' ),
                'options'       => array(
                    'left'         => esc_html__( 'Left', 'ideabuz' ),
                    'center'       => esc_html__( 'Center', 'ideabuz' ),
                    'right'        => esc_html__( 'Right', 'ideabuz' ),
                ),
                'default'   => 'center',
            ),
            array(
                'id'        => 'ideabuz_header_bg',
                'type'      => 'background',
                'title'     => esc_html__( 'Common Header Background', 'ideabuz' ),
                'subtitle'  => esc_html__( 'Upload Common Header Background', 'ideabuz' ),
            ),
            array(
                'id'            => 'ideabuz_header_text_show_hide',
                'type'          => 'switch',
                'title'         => esc_html__( 'Show Page header?','ideabuz' ),
                'subtitle'      => esc_html__( 'Switch On To Show Page Header', 'ideabuz' ),
                'default'       => true,
            ),
            array(
                'id'            => 'ideabuz_header_text_color',
                'type'          => 'color',
                'title'         => esc_html__('Page header text color','ideabuz'),
                'subtitle'      => esc_html__('Page header text color', 'ideabuz'),
                'required'  => array( 'ideabuz_header_text_show_hide','equals','1' ),
            ),
            array(
                'id'            => 'ideabuz_enable_bread',
                'type'          => 'button_set',
                'title'         => esc_html__('Breadcrumb Hide/Show', 'ideabuz'),
                'subtitle'      => esc_html__('Hide / Show breadcrumb from all page and post ( Default settings hide ).', 'ideabuz'),
                'options'       => array(
                    '1'         => esc_html__( 'show', 'ideabuz' ),
                    '2'         => esc_html__( 'hide', 'ideabuz' )
                ),
                'default'       => '1'
            ),
            array(
                'id'            => 'ideabuz_link_color',
                'type'          => 'color',
                'output'        => array( '.ideabuz--page-title .title-bc ol.breadcrumb a' ),
                'title'         => esc_html__('Breadcrumb Link color', 'ideabuz'),
                'subtitle'      => esc_html__('Set Breadcrumb Link Color', 'ideabuz'),
                'required'      => array( 'ideabuz_enable_bread','equals','1' ),
            ),
            array(
                'id'            => 'ideabuz_link_hover_color',
                'type'          => 'color',
                'output'        => array( '.ideabuz--page-title .title-bc ol.breadcrumb a:hover' ),
                'title'         => esc_html__('Breadcrumb Link Hover color', 'ideabuz'),
                'subtitle'      => esc_html__('Set Breadcrumb Link Hover Color', 'ideabuz'),
                'required'      => array( 'ideabuz_enable_bread','equals','1' ),
            ),
            array(
                'id'            => 'ideabuz_active_color',
                'type'          => 'color',
                'output'        => array( '.ideabuz--page-title .title-bc ol.breadcrumb li.active' ),
                'title'         => esc_html__('Breadcrumb Active Color', 'ideabuz'),
                'subtitle'      => esc_html__('Active color of breadcrumb', 'ideabuz'),
            ),
            array(
                'id'            => 'ideabuz_divider_color',
                'type'          => 'color',
                'output'        => array( '.ideabuz--page-title .title-bc ol.breadcrumb li:before' ),
                'title'         => esc_html__( 'Breadcrumb divider Color', 'ideabuz' ),
                'subtitle'      => esc_html__( 'Choose Breadcrumb Divider Color', 'ideabuz' ),
            ),

        ),

    ) );

    /* End Header */
    // -> START Blog
    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Blog', 'ideabuz' ),
        'id'               => 'ideabuz_blogger',
        'customizer_width' => '400px',
        'icon'             => 'el el-blogger'
    ) );
    // Blog Option Start
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Blog', 'ideabuz' ),
        'id'         => 'ideabuz_blog',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'ideabuz_blog_style',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Blog Style', 'ideabuz' ),
                'subtitle' => esc_html__( 'Select Blog Style', 'ideabuz' ),
                'options'  => array(
                    '1'     => esc_html__( 'Style One', 'ideabuz' ),
                    '2'     => esc_html__( 'Style Two', 'ideabuz' ),
                 ),
                'default' => '1'
            ),
            array(
                'id'       => 'ideabuz_blog_layout',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Select Blog Page Layout', 'ideabuz' ),
                'subtitle' => esc_html__( 'Choose Your Blog Sidebar Layout ', 'ideabuz' ),
                'options'  => array(
                    '1'       => array(
                        'alt' => '1 Column',
                        'img' => ReduxFramework::$_url . 'assets/img/1col.png'
                    ),
                    '2'       => array(
                        'alt' => '2 Column Left',
                        'img' => ReduxFramework::$_url . 'assets/img/2cl.png'
                    ),
                    '3'       => array(
                        'alt' => '2 Column Right',
                        'img' => ReduxFramework::$_url . 'assets/img/2cr.png'
                    ),

                ),
                'default'   => '3'
            ),
            array(
                'id'       => 'ideabuz_post_column',
                'type'     => 'button_set',
                'title'    => esc_html__('Post Column', 'ideabuz'),
                'subtitle' => esc_html__('Set Post Column', 'ideabuz'),
                'options'  => array(
                    '1'     => esc_html__( 'Full Width', 'ideabuz' ),
                    '2'     => esc_html__( '2 Column', 'ideabuz' ),
                    '3'     => esc_html__( '3 Column', 'ideabuz' ),
                    '4'     => esc_html__( '4 Column', 'ideabuz' ),
                 ),
                'default' => '1'
            ),
            array(
                'id'        => 'ideabuz_blog_post_background',
                'type'      => 'color',
                'output'    => array( 'background-color'    =>    '.single-blog-item,.single-blog-style--two' ),
                'title'     => esc_html__( 'Blog Post Background Color','ideabuz' ),
                'subtitle'  => esc_html__( 'Set Blog Post Background Color','ideabuz' ),
            ),
            array(
                'id'        => 'ideabuz_blog_post_background_when_hover',
                'type'      => 'color_gradient',
                'validate'  => 'color',
                'title'     => esc_html__( 'Blog Post Background Shape Color When Hover','ideabuz' ),
                'subtitle'  => esc_html__( 'Set Blog Post Background Shape Color When Hover','ideabuz' ),
                'default'  => array(
                    'from' => '#fb4275',
                    'to'   => '#f35d46', 
                ),
                'required'  => array( 'ideabuz_blog_style','equals','1' ),
            ),
            array(
                'id'        => 'ideabuz_post_excerpt',
                'type'      => 'text',
                'title'     => esc_html__( 'Post Excerpt','ideabuz' ),
                'subtitle'  => esc_html__( 'Blog Post Excerpt','ideabuz' ),
            ),
            array(
                'id'        => 'ideabuz_post_excerpt_color',
                'type'      => 'color',
                'title'     => esc_html__( 'Post Excerpt Color','ideabuz' ),
                'subtitle'  => esc_html__( 'Set Blog Post Excerpt Color','ideabuz' ),
                'output'    => array( '.single-blog-item .blog-content .blog-excerpt','p.blog-excerpt' ),
            ),
            array(
                'id'        => 'ideabuz_button_text',
                'type'      => 'text',
                'title'     => esc_html__( 'Read More Button Text','ideabuz' ),
            ),
            array(
                'id'        => 'ideabuz_read_more_button_color',
                'type'      => 'color',
                'title'     => esc_html__( 'Read More Text Color','ideabuz' ),
                'subtitle'  => esc_html__( 'Set Read More Text Color','ideabuz' ),
                'output'    => array( '.single-blog-item .blog-button a','.single-blog-style--two .blog-content a' ),
            ),
            array(
                'id'        => 'ideabuz_read_more_button_color_on_hover',
                'type'      => 'color',
                'title'     => esc_html__( 'Read More Text Color When Hover','ideabuz' ),
                'subtitle'  => esc_html__( 'Set Read More Text Color When Hover','ideabuz' ),
                'output'    => array( '.single-blog-item .blog-button a:hover','.single-blog-style--two .blog-content a:hover' ),
            ),
            array(
                'id'        => 'ideabuz_read_more_border_color',
                'type'      => 'color',
                'title'     => esc_html__( 'Border Color After Read More Text','ideabuz' ),
                'subtitle'  => esc_html__( 'Set Border Color After Read More Text','ideabuz' ),
                'output'    => array( 'background-color'  =>  '.single-blog-item .blog-button a:after,.single-blog-style--two .blog-content a.btn-inline:after' ),
            ),
            array(
                'id'        => 'ideabuz_read_more_border_color_hover',
                'type'      => 'color',
                'title'     => esc_html__( 'Border Color After Hover Read More Text','ideabuz' ),
                'subtitle'  => esc_html__( 'Set Border Color After Hover Read More Text','ideabuz' ),
                'output'    => array( 'background-color'  => '.single-blog-item .blog-button a:hover:after,.single-blog-style--two .blog-content a.btn-inline:hover:after' ),
            ),
            array(
                'id'        => 'ideabuz_title_color',
                'type'      => 'color',
                'title'     => esc_html__( 'Post Title Color','ideabuz' ),
                'subtitle'  => esc_html__( 'Set Post Title Color','ideabuz' ),
                'output'    => array( '.single-blog-item .blog-content .blog-title','.single-blog-style--two .blog-content .blog-title' ),
            ),
            array(
                'id'        => 'ideabuz_title_color_on_hover',
                'type'      => 'color',
                'title'     => esc_html__( 'Title Color When Overlay Appear','ideabuz' ),
                'subtitle'  => esc_html__( 'Set Title Color When Overlay Appear','ideabuz' ),
                'output'    => array( '.single-blog-item .blog-hover .blog-title a' ),
                'required'  => array( 'ideabuz_blog_style','equals','1' ),
            ),
            array(
                'id'        => 'ideabuz_post_title_hover_color',
                'type'      => 'color',
                'output'    => array( '.single-blog-style--two .blog-content .blog-title a:hover' ),
                'title'     => esc_html__( 'Post Title Hover Color','ideabuz' ),
                'subtitle'  => esc_html__( 'Set Post Title Hover Color','ideabuz' ),
                'required'  => array( 'ideabuz_blog_style','equals','2' ),
            ),
            array(
                'id'        => 'ideabuz_pagination_position',
                'type'      => 'button_set',
                'title'     => esc_html__( 'Pagination Position','ideabuz' ),
                'subtitle'  => esc_html__( 'Set Pagination Position','ideabuz' ),
                'options'       => array(
                    'Left'         => esc_html__( 'Left', 'ideabuz' ),
                    'center'       => esc_html__( 'Center', 'ideabuz' ),
                ),
                'default'   => 'center',
            ),
            array(
                'id'        => 'ideabuz_post_pagination_active_color',
                'type'      => 'color',
                'output'    => array( '.pagination span.page-numbers.current' ),
                'title'     => esc_html__( 'Post Pagination Active Color','ideabuz' ),
                'subtitle'  => esc_html__( 'Set Post Pagination Active Color','ideabuz' ),
            ),
            array(
                'id'        => 'ideabuz_post_pagination_active_background',
                'type'      => 'color',
                'output'    => array( 'background-color'  =>  '.pagination span.page-numbers.current' ),
                'title'     => esc_html__( 'Post Pagination Active Background','ideabuz' ),
                'subtitle'  => esc_html__( 'Set Post Pagination Active Background','ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_post_pagination_color',
                'type'     => 'color',
                'output'   => array( '.pagination .nav-links .page-numbers' ),
                'title'    => esc_html__( 'Page Number Color','ideabuz' ),
                'subtitle' => esc_html__( 'Set Page Number Color','ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_post_pagination_bg',
                'type'     => 'color',
                'output'   => array( 'Background-color'   =>  '.pagination .nav-links a.page-numbers' ),
                'title'    => esc_html__( 'Page Number Background','ideabuz' ),
                'subtitle' => esc_html__( 'Set Page Number Background','ideabuz' ),
                'required' => array( 'ideabuz_post_pagination','equals','1' ),
            ),
            array(
                'id'       => 'ideabuz_post_pagination_hover_bg',
                'type'     => 'color',
                'output'   => array( 'Background-color' =>'.pagination .nav-links .page-numbers:hover' ),
                'title'    => esc_html__( 'Page Number Background On Hover','ideabuz' ),
                'subtitle' => esc_html__( 'Set Page Number Background On Hover','ideabuz' ),
                'required' => array( 'ideabuz_post_pagination','equals','1' ),
            ),
            array(
                'id'       => 'ideabuz_post_pagination_hover_text_color',
                'type'     => 'color',
                'output'   => array( '.ideabuz--pagination .nav-links a.page-numbers:hover' ),
                'title'    => esc_html__( 'Page Number Color On Hover','ideabuz' ),
                'subtitle' => esc_html__( 'Set Page Number Color On Hover','ideabuz' ),
                'required' => array( 'ideabuz_post_pagination','equals','1' ),
            ),
            array(
                'id'       => 'ideabuz_post_pagination_border_color',
                'type'     => 'border',
                'output'   => array( '.ideabuz--pagination .ideabuz--pagination .nav-links a.page-numbers, .ideabuz--pagination .nav-links span' ),
                'title'    => esc_html__( 'Pagination Border Color','ideabuz' ),
                'subtitle' => esc_html__( 'Set Border Color','ideabuz' ),
                'top'      => true,
                'left'     => true,
                'bottom'   => true,
                'right'    => true,
                'required' => array( 'ideabuz_post_pagination','equals','1' ),
            ),
        ),
    ) );
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Meta Data', 'ideabuz' ),
        'id'         => 'ideabuz_blog_meta_data',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'        => 'ideabuz_date_enable',
                'type'      => 'switch',
                'title'     => esc_html__( 'On/Off Date','ideabuz' ),
                'subtitle'  => esc_html__( 'Switch On To Show Date','ideabuz' ),
                'default'   => true,
            ),
            array(
                'id'        => 'ideabuz_date_color',
                'type'      => 'color',
                'title'     => esc_html__( 'Date Text Color','ideabuz' ),
                'subtitle'  => esc_html__( 'Set Date Text Color','ideabuz' ),
                'output'    => array( '.single-blog-item .blog-content .posted-on','.single-blog-style--two .posted-on' ),
                'required'  => array( 'ideabuz_date_enable','equals','1' ),
            ),
            array(
                'id'        => 'ideabuz_date_shape_bg',
                'type'      => 'color',
                'title'     => esc_html__( 'Date Shape Background Color','ideabuz' ),
                'subtitle'  => esc_html__( 'Set Date Shape Background Color','ideabuz' ),
                'output'    => array( 'fill'  =>   '.date-bg-shape svg path' ),
                'required'  => array( 'ideabuz_date_enable','equals','1' ),
            ),
            array(
                'id'        => 'ideabuz_category_enable',
                'type'      => 'switch',
                'title'     => esc_html__( 'On/Off Category','ideabuz' ),
                'subtitle'  => esc_html__( 'Switch On To Show Category','ideabuz' ),
                'default'   => true,
            ),
            array(
                'id'        => 'ideabuz_category_color',
                'type'      => 'color',
                'title'     => esc_html__( 'Category Text Color','ideabuz' ),
                'subtitle'  => esc_html__( 'Set Category Text Color','ideabuz' ),
                'output'    => array( '.single-blog-item .blog-content .category','.single-blog-style--two .blog-content .category a' ),
                'required'  => array( 'ideabuz_category_enable','equals',1 ),
            ),
            array(
                'id'        => 'ideabuz_category_hover_color',
                'type'      => 'color',
                'title'     => esc_html__( 'Category Text Color When Hover','ideabuz' ),
                'subtitle'  => esc_html__( 'Set Category Text Color On Hover','ideabuz' ),
                'output'    => array( '.single-blog-style--two .blog-content .category a:hover' ),
                'required'  => array( 'ideabuz_blog_style','equals','2' ),
            ),
            
            array(
                'id'        => 'ideabuz_author_enable',
                'type'      => 'switch',
                'title'     => esc_html__( 'On/Off Author','ideabuz' ),
                'subtitle'  => esc_html__( 'Switch On To Show Author','ideabuz' ),
                'default'   => true,
                'required'  => array( 'ideabuz_blog_style','equals','2' ),
            ),
            array(
                'id'        => 'ideabuz_author_color',
                'type'      => 'color',
                'title'     => esc_html__( 'Author Text Color','ideabuz' ),
                'subtitle'  => esc_html__( 'Set Author Text Color','ideabuz' ),
                'required'  => array( 'ideabuz_author_enable','equals','1' ),
                'output'    => array( '.single-blog-style--two .blog-content .post-meta li:first-child a' ),
            ),
            array(
                'id'        => 'ideabuz_author_color_on_hover',
                'type'      => 'color',
                'title'     => esc_html__( 'Author Text Color When Hover','ideabuz' ),
                'subtitle'  => esc_html__( 'Set Author Text Color When Hover','ideabuz' ),
                'required'  => array( 'ideabuz_author_enable','equals','1' ),
                'output'    => array( '.single-blog-style--two .blog-content .post-meta li:first-child a:hover' ),
            ),
            array(
                'id'        => 'ideabuz_comment_enable',
                'type'      => 'switch',
                'title'     => esc_html__( 'On/Off Comment','ideabuz' ),
                'subtitle'  => esc_html__( 'Switch On To Show Comment','ideabuz' ),
                'default'   => true,
                'required'  => array( 'ideabuz_blog_style','equals','2' ),
            ),
            array(
                'id'        => 'ideabuz_comment_count_text_color',
                'type'      => 'color',
                'title'     => esc_html__( 'Comment Count Color','ideabuz' ),
                'subtitle'  => esc_html__( 'Set Comment Count Color','ideabuz' ),
                'required'  => array( 'ideabuz_comment_enable','equals','1' ),
                'output'    => array( '.single-blog-style--two .blog-content .post-meta li span' ),
            ),
        ),
    ));
    // Blog Single Page
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Blog Details', 'ideabuz' ),
        'id'         => 'ideabuz_blog_single',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'ideabuz_blog_single_layout',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Select Blog Details Layout', 'ideabuz' ),
                'subtitle' => esc_html__( 'Choose Blog Details Layout', 'ideabuz' ),
                'options'  => array(
                    '1'       => array(
                        'alt' => '1 Column',
                        'img' => ReduxFramework::$_url . 'assets/img/1col.png'
                    ),
                    '2'       => array(
                        'alt' => '2 Column Left',
                        'img' => ReduxFramework::$_url . 'assets/img/2cl.png'
                    ),
                    '3'       => array(
                        'alt' => '2 Column Right',
                        'img' => ReduxFramework::$_url . 'assets/img/2cr.png'
                    ),

                ),
                'default'  => '3'
            ),
            array(
                'id'       => 'ideabuz_single_post_time_enable',
                'type'     => 'switch',
                'title'    => esc_html__( 'Date','ideabuz' ),
                'subtitle' => esc_html__( 'Switch On To Display Time','ideabuz' ),
                'default'  => true,
            ),
            array(
                'id'       => 'ideabuz_single_post_time_color',
                'type'     => 'color',
                'output'   => array( '.post-meta ul li a.date-color' ),
                'title'    => esc_html__( 'Date Color','ideabuz' ),
                'subtitle' => esc_html__( 'Set Date Color','ideabuz' ),
                'required' => array( 'ideabuz_single_post_time_enable','equals','1' ),
            ),
            array(
                'id'       => 'ideabuz_single_post_time_color_hover',
                'type'     => 'color',
                'output'   => array( '.post-meta ul li a.date-color:hover' ),
                'title'    => esc_html__( 'Date Hover Color','ideabuz' ),
                'subtitle' => esc_html__( 'Set Date Hover Color','ideabuz' ),
                'required' => array( 'ideabuz_single_post_time_enable','equals','1' ),
            ),
            array(
                'id'       => 'ideabuz_single_enable_category',
                'type'     => 'switch',
                'title'    => esc_html__( 'Category','ideabuz' ),
                'subtitle' => esc_html__( 'Switch On To Display Category','ideabuz' ),
                'default'  => true,
            ),
            array(
                'id'       => 'ideabuz_single_category_color',
                'type'     => 'color',
                'output'   => array( '.post-meta ul li:last-child a' ),
                'title'    => esc_html__( 'Category Color','ideabuz' ),
                'subtitle' => esc_html__( 'Set Category Color','ideabuz' ),
                'required' => array( 'ideabuz_single_enable_category','equals','1' ),
            ),
            array(
                'id'       => 'ideabuz_single_category_color_hover',
                'type'     => 'color',
                'output'   => array( '.post-meta ul li:last-child a:hover' ),
                'title'    => esc_html__( 'Category Color On Hover','ideabuz' ),
                'subtitle' => esc_html__( 'Set Category Color On Hover','ideabuz' ),
                'required' => array( 'ideabuz_single_enable_category','equals','1' ),
            ),
            array(
                'id'       => 'ideabuz_single_tag_enable_disable',
                'type'     => 'switch',
                'title'    => esc_html__( 'Tags','ideabuz' ),
                'subtitle' => esc_html__( 'Switch On To Display Tags','ideabuz' ),
                'default'  => true,
            ),
            array(
                'id'       => 'ideabuz_single_tag_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Tags Color','ideabuz' ),
                'subtitle' => esc_html__( 'Set Tags Color','ideabuz' ),
                'output'   => array( '.blog-details .post-tags ul li a' ),
                'required' => array( 'ideabuz_single_tag_enable_disable','equals','1' ),
            ),
            array(
                'id'       => 'ideabuz_single_tag_hover_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Tags Color On Hover','ideabuz' ),
                'subtitle' => esc_html__( 'Set Tags Color On Hover','ideabuz' ),
                'output'   => array( '.blog-details .post-tags ul li a:hover' ),
                'required' => array( 'ideabuz_single_tag_enable_disable','equals','1' ),
            ),
            array(
                'id'       => 'ideabuz_single_social',
                'type'     => 'switch',
                'title'    => esc_html__( 'Social Share Box','ideabuz' ),
                'subtitle' => esc_html__( 'Switch On To Display Social Share Box','ideabuz' ),
                'default'  => true,
            ),
            array(
                'id'       => 'ideabuz_single_social_facebook_color',
                'type'     => 'color',
                'output'   => array( '.blog-details .social_icon_list li a .fa-facebook' ),
                'title'    => esc_html__( 'Facebook Icon Color','ideabuz' ),
                'subtitle' => esc_html__( 'Set Facebook Icon Color','ideabuz' ),
                'required' => array( 'ideabuz_single_social','equals','1' ),
            ),
            array(
                'id'       => 'ideabuz_single_social_twitter_color',
                'type'     => 'color',
                'output'   => array( '.blog-details .social_icon_list li a .fa-twitter' ),
                'title'    => esc_html__( 'Twitter Icon Color','ideabuz' ),
                'subtitle' => esc_html__( 'Set Twitter Icon Color','ideabuz' ),
                'required' => array( 'ideabuz_single_social','equals','1' ),
            ),
            array(
                'id'       => 'ideabuz_single_social_linkedin_color',
                'type'     => 'color',
                'output'   => array( '.blog-details .social_icon_list li a .fa-linkedin' ),
                'title'    => esc_html__( 'Linkedin Icon Color','ideabuz' ),
                'subtitle' => esc_html__( 'Set Linkedin Icon Color','ideabuz' ),
                'required' => array( 'ideabuz_single_social','equals','1' ),
            ),
            array(
                'id'       => 'ideabuz_enable_disable_navigation',
                'type'     => 'switch',
                'title'    => esc_html__( 'Navigation','ideabuz' ),
                'subtitle' => esc_html__( 'Switch On To Enable Navigation','ideabuz' ),
                'default'  => true,
            ), 
        ),
    ));

    // Page Option Start
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Page', 'ideabuz' ),
        'id'         => 'ideabuz_page',
        'icon'       => 'el el-file',
        'fields'     => array(
         array(
                'id'       => 'ideabuz_page_layout',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Select page layout', 'ideabuz' ),
                'subtitle' => esc_html__( 'Choose your page layout ', 'ideabuz' ),
                'options'  => array(
                    '1'    => array(
                        'alt' => '1 Column',
                        'img' => ReduxFramework::$_url . 'assets/img/1col.png'
                    ),
                    '2'     => array(
                        'alt' => '2 Column Left',
                        'img' => ReduxFramework::$_url . 'assets/img/2cl.png'
                    ),
                    '3'     => array(
                        'alt' => '2 Column Right',
                        'img' => ReduxFramework::$_url . 'assets/img/2cr.png'
                    ),

                ),
                'default'  => '1'
            ),
        ),
    ) );
    // Service Details
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Service Details', 'ideabuz' ),
        'id'         => 'ideabuz_service_details',
        'icon'       => 'el el-file',
        'fields'     => array(
         array(
                'id'       => 'ideabuz_service_single_layout',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Select Service Details Layout', 'ideabuz' ),
                'subtitle' => esc_html__( 'Choose Your Service Details Layout', 'ideabuz' ),
                'options'  => array(
                    '1'    => array(
                        'alt' => '1 Column',
                        'img' => ReduxFramework::$_url . 'assets/img/1col.png'
                    ),
                    '2'     => array(
                        'alt' => '2 Column Left',
                        'img' => ReduxFramework::$_url . 'assets/img/2cl.png'
                    ),
                    '3'     => array(
                        'alt' => '2 Column Right',
                        'img' => ReduxFramework::$_url . 'assets/img/2cr.png'
                    ),

                ),
                'default'  => '2'
            ),
            array(
                'id'       => 'ideabuz_service_sidebar',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Select Service Details Sidebar', 'ideabuz' ),
                'subtitle' => esc_html__( 'Choose Service Details Sidebar', 'ideabuz' ),
                'options'  => array(
                    '1'         => esc_html__( 'Blog Sidebar','ideabuz' ),
                    '2'         => esc_html__( 'Page Sidebar','ideabuz' ),
                    '3'         => esc_html__( 'Service Sidebar','ideabuz' ),
                ),
                'default'  => '3',
            ),
            array(
                'id'       => 'ideabuz_archive_style',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Select Service Archive Style', 'ideabuz' ),
                'subtitle' => esc_html__( 'Choose Service Archive Style', 'ideabuz' ),
                'options'  => array(
                    '1'         => esc_html__( 'Style One','ideabuz' ),
                    '2'         => esc_html__( 'Style Two','ideabuz' ),
                    '3'         => esc_html__( 'Style Three','ideabuz' ),
                    '4'         => esc_html__( 'Style Four','ideabuz' ),
                ),
                'default'  => '3',
            ),
            array(
                'id'       => 'ideabuz_archive_text_align',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Select Archive Content Alignment', 'ideabuz' ),
                'subtitle' => esc_html__( 'Choose Service Archive Content Alignment', 'ideabuz' ),
                'options'  => array(
                    '1'         => esc_html__( 'Left','ideabuz' ),
                    '2'         => esc_html__( 'Center','ideabuz' ),
                    '3'         => esc_html__( 'Right','ideabuz' ),
                ),
                'default'  => '2',
            ),
            array(
                'id'       => 'ideabuz_archive_column',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Select Archive Column', 'ideabuz' ),
                'subtitle' => esc_html__( 'Choose Archive Column', 'ideabuz' ),
                'options'  => array(
                    'two'         => esc_html__( 'Two','ideabuz' ),
                    'three'       => esc_html__( 'Three','ideabuz' ),
                    'four'        => esc_html__( 'Four','ideabuz' ),
                    'six'         => esc_html__( 'Six','ideabuz' ),
                ),
                'default'  => 'three',
            ),
        ),
    ) );
    // Subscribe
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Subscribe', 'ideabuz' ),
        'id'         => 'ideabuz_subscribe',
        'icon'       => 'el el-arrow-right',
        'fields'     => array(
            array(
                'id'        => 'mailchimp_api_key',
                'type'      => 'text',
                'title'     => esc_html__( 'Mailchimp API Key', 'ideabuz' ),
                'subtitle'  => esc_html__( 'Set Mailchimp API Key', 'ideabuz' ),
            ),
            array(
                'id'        => 'mailchimp_list_id',
                'type'      => 'text',
                'title'     => esc_html__( 'Mailchimp List Id', 'ideabuz' ),
                'subtitle'  => esc_html__( 'Set Mailchimp List Id', 'ideabuz' ),
            ),
        ),
    ) );
    
    // Coming Soon
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Coming Soon', 'ideabuz' ),
        'id'         => 'ideabuz_coming_soon',
        'icon'       => 'el el-bullhorn',
        'fields'     => array(
            array(
                'id'        => 'ideabuz_background',
                'type'      => 'background',
                'output'    => array( '.bg-coming-soon' ),
                'title'     => esc_html__( 'Coming Soon Background', 'ideabuz' ),
            ),
            array(
                'id'        => 'ideabuz_coming_logo',
                'type'      => 'media',
                'url'       => true,
                'compiler'  => true,
                'title'     => esc_html__( 'Coming Soon Logo', 'ideabuz' ),
                'subtitle'  => esc_html__( 'Set Coming Soon Logo', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_coming_site_logo_dimensions',
                'type'     => 'dimensions',
                'output'   => array( '.coming-soon-content .logo a img' ),
                'units'    => array('em','px','%'),
                'title'    => esc_html__('Logo Dimensions (Width/Height).', 'ideabuz'),
                'subtitle' => esc_html__('Set logo dimensions to choose width, height, and unit.', 'ideabuz'),
            ),
			array(
                'id'       => 'ideabuz_coming_site_logomargin_dimensions',
                'type'     => 'spacing',
				'mode'     => 'margin',
                'output'   => array( '.coming-soon-content .logo a img' ),
				'units_extended' => 'false',
                'units'    => array('em','px' ),
                'title'    => esc_html__('Logo Top and Bottom Margin.', 'ideabuz'),
				'left'     => false,
                'right'    => false,
                'subtitle' => esc_html__('Set logo top and bottom margin.', 'ideabuz'),
                'default'            => array(
                    'margin-top'     => '0px',
                    'margin-bottom'  => '0px',
                    'units'          => 'px'
                )
            ),
            array(
                'id'       => 'ideabuz_coming_site_title',
                'type'     => 'text',
                'validate' => 'html',
                'title'    => esc_html__( 'Text Logo', 'ideabuz' ),
                'subtitle' => esc_html__( 'Write your logo text use as logo ( You can use span tag for text color ).', 'ideabuz' ),
                'default'  => wp_kses( esc_html__( 'ideabuz', 'ideabuz' ), $alowhtml ),
            ),
            array(
                'id'       => 'ideabuz_coming_text_logo_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Text Logo Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Text Logo Color.  Make Sure You Using Text Logo', 'ideabuz' ),
                'output'   => array( '.coming-soon-content .logo h2 a' ),
            ),
            array(
                'id'       => 'ideabuz_coming_text_logo_color_hover',
                'type'     => 'color',
                'title'    => esc_html__( 'Text Logo Color On Hover', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Text Logo Color When hover. Make Sure You Using Text Logo', 'ideabuz' ),
                'output'   => array( '.coming-soon-content .logo h2 a:hover' ),
            ),
            array(
                'id'       => 'ideabuz_coming_soon_title',
                'type'     => 'text',
                'title'    => esc_html__( 'Coming Soon Title', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Coming Soon Title', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_coming_soon_title_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Coming Soon Title Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Coming Soon Title Color', 'ideabuz' ),
                'output'   => array( '.coming-soon-content h1' ),
            ),
            array(
                'id'       => 'ideabuz_coming_time',
                'type'     => 'date',
                'title'    => esc_html__( 'Countdown Date', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Countdown Date', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_countdown_box_bg',
                'type'     => 'color',
                'output'   => array( 'background-color' => '#countdown li .single-countdown' ),
                'title'    => esc_html__( 'Countdown Box Bg', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Countdown Box Bg', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_days_text_color',
                'type'     => 'color',
                'output'   => array( '#countdown li .single-countdown h4.days_text' ),
                'title'    => esc_html__( 'Countdown Days Text Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Countdown Days Text Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_days_countdown_color',
                'type'     => 'color',
                'output'   => array( '#countdown li .single-countdown h2.days' ),
                'title'    => esc_html__( 'Days Countdown Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Days Countdown Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_hours_text_color',
                'type'     => 'color',
                'output'   => array( '#countdown li .single-countdown h4.hours_text' ),
                'title'    => esc_html__( 'Hours Text Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Hours Text Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_hours_countdown_text_color',
                'type'     => 'color',
                'output'   => array( '#countdown li .single-countdown h2.hours' ),
                'title'    => esc_html__( 'Hours Countdown Text Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Hours Countdown Text Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_minutes_text_color',
                'type'     => 'color',
                'output'   => array( '#countdown li .single-countdown h4.minutes_text' ),
                'title'    => esc_html__( 'Minutes Text Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Minutes Text Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_minutes_countdown_text_color',
                'type'     => 'color',
                'output'   => array( '#countdown li .single-countdown h2.minutes' ),
                'title'    => esc_html__( 'Minutes Countdown Text Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Minutes Countdown Text Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_seconds_text_color',
                'type'     => 'color',
                'output'   => array( '#countdown li .single-countdown h4.seconds_text' ),
                'title'    => esc_html__( 'Seconds Text Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Seconds Text Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_seconds_countdown_text_color',
                'type'     => 'color',
                'output'   => array( '#countdown li .single-countdown h2.seconds' ),
                'title'    => esc_html__( 'Seconds Countdown Text Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Seconds Countdown Text Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_time_separator',
                'type'     => 'color',
                'output'   => array( '#countdown li.seperator' ),
                'title'    => esc_html__( 'Separator Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Separator Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_coming_soon_simple_title',
                'type'     => 'text',
                'title'    => esc_html__( 'Coming Soon Simple Text', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_coming_soon_simple_title_color',
                'type'     => 'color',
                'output'   => array( '.coming-soon-content > h3' ),
                'title'    => esc_html__( 'Coming Soon Simple Text', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Coming Soon Simple Text Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_coming_soon_form_placeholder',
                'type'     => 'text',
                'title'    => esc_html__( 'Form Placeholder Text', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Form Placeholder Text', 'ideabuz' ),
                'default'  => esc_html__( 'What are you looking for...','ideabuz' )
            ),
            array(
                'id'       => 'ideabuz_coming_soon_input_btn_color',
                'type'     => 'color',
                'output'   => array( 'border-color'  =>   '.coming-soon-content .coming-soon-form form input' ),
                'title'    => esc_html__( 'Coming Soon Input Border Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Coming Soon Input Border Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_coming_soon_input_bg_color',
                'type'     => 'color',
                'output'   => array( 'background-color'  =>   '.coming-soon-content .coming-soon-form form input' ),
                'title'    => esc_html__( 'Coming Soon Input Background Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Coming Soon Input Background Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_coming_soon_button',
                'type'     => 'text',
                'title'    => esc_html__( 'Button Text', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Button Text', 'ideabuz' ),
                'default'  => esc_html__( 'Search', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_coming_soon_search_btn_color',
                'type'     => 'color',
                'output'   => array( '.coming-soon-content .coming-soon-form form button span' ),
                'title'    => esc_html__( 'Coming Soon Search Button Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Coming Soon Search Button Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_coming_soon_search_btn_bg_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Coming Soon Search Button Background Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Coming Soon Search Button Background Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_coming_soon_search_btn_border_color',
                'type'     => 'color_gradient',
                'validate'  => 'color',
                'title'    => esc_html__( 'Coming Soon Search Button Border Color On Hover', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Coming Soon Search Button Border Color On Hover', 'ideabuz' ),
                'default'  => array(
                    'from' => '#fb4275',
                    'to'   => '#f35d46', 
                ),
            ),
        ),
    ) );
    
    // Social Icon
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Social', 'ideabuz' ),
        'id'         => 'ideabuz_social_icon',
        'icon'       => 'el el-universal-access',
        'fields'     => array(
            array(
                'id'          => 'social_icon_slide',
                'type'        => 'slides',
                'title'       => esc_html__('Add Social Icon', 'ideabuz'),
                'show'        => array(
                   'image_upload'   => false,
                   'title'          => false,
                   'description'    => false,
                   'url'            => true,
                   'progress'       => false,
                   'icon'           => true,
                   'facts-number'   => false,
                ),
            ),
            array(
                'id'       => 'social_icon_one_color',
                'type'     => 'color',
                'output'   => array( '.social_icon_list li:nth-child(1) a i' ),
                'title'    => esc_html__( 'Social Icon One Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Social Icon One Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'social_icon_two_color',
                'type'     => 'color',
                'output'   => array( '.social_icon_list li:nth-child(2) a i' ),
                'title'    => esc_html__( 'Social Icon Two Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Social Icon Two Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'social_icon_three_color',
                'type'     => 'color',
                'output'   => array( '.social_icon_list li:nth-child(3) a i' ),
                'title'    => esc_html__( 'Social Icon Three Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Social Icon Three Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'social_icon_four_color',
                'type'     => 'color',
                'output'   => array( '.social_icon_list li:nth-child(4) a i' ),
                'title'    => esc_html__( 'Social Icon Three Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Social Icon Three Color', 'ideabuz' ),
            ),
        ),
    ) );
    // 404 Page Option Start
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( '404 Page', 'ideabuz' ),
        'id'         => 'ideabuz_fof',
        'icon'       => 'el el-ban-circle',
        'fields'     => array(
            array(
                'id'       => 'ideabuz_404_image_bg',
                'type'     => 'background',
                'title'    => esc_html__( '404 Background', 'ideabuz' ),
                'output'   => array( '.bg-404' ),
            ),
            array(
                'id'       => 'ideabuz_404_image',
                'type'     => 'media',
                'compiler' => true,
                'title'    => esc_html__( '404 Image', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_404_subtitle',
                'type'     => 'textarea',
                'title'    => esc_html__( '404 Subtitle Text', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set 404 Subtitle Text', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_404_subtitle_color',
                'type'     => 'color',
                'output'   => array( '.not-found-content p' ),
                'title'    => esc_html__( '404 SubTitle Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set 404 Subtitle Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_404_subtitle_ancor_color',
                'type'     => 'color',
                'output'   => array( '.not-found-content p a' ),
                'title'    => esc_html__( '404 SubTitle Ancor Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set 404 Subtitle Ancor Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_404_form_placeholder',
                'type'     => 'text',
                'title'    => esc_html__( 'Form Placeholder Text', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Form Placeholder Text', 'ideabuz' ),
                'default'  => esc_html__( 'What are you looking for...', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_404_input_btn_color',
                'type'     => 'color',
                'output'   => array( 'border-color'  =>   '.not-found-form form input' ),
                'title'    => esc_html__( '404 Input Border Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set 404 Input Border Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_404_input_bg_color',
                'type'     => 'color',
                'output'   => array( 'background-color'  =>   '.not-found-form form input' ),
                'title'    => esc_html__( '404 Input Background Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set 404 Input Background Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_404_button',
                'type'     => 'text',
                'title'    => esc_html__( 'Button Text', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Button Text', 'ideabuz' ),
                'default'  => esc_html__( 'Search','ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_404_search_btn_color',
                'type'     => 'color',
                'output'   => array( '.not-found-form form button span' ),
                'title'    => esc_html__( '404 Search Button Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set 404 Search Button Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_404_search_btn_bg_color',
                'type'     => 'color',
                'output'   => array( 'background-color'  =>   '.not-found-form form button' ),
                'title'    => esc_html__( '404 Search Button Background Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set 404 Search Button Background Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_404_search_btn_border_color',
                'type'     => 'color_gradient',
                'validate'  => 'color',
                'title'    => esc_html__( '404 Search Button Border Color On Hover', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set 404 Search Button Border Color On Hover', 'ideabuz' ),
                'default'  => array(
                    'from' => '#fb4275',
                    'to'   => '#f35d46', 
                ),
            ),
        ),
    ) );

    // -> START Woo Page Option
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Woocommerce Page', 'ideabuz' ),
        'id'         => 'ideabuz_woo_page_page',
        'icon'  => 'el el-shopping-cart',
        'fields'     => array(
            array(
                'id'       => 'ideabuz_woo_shoppage_sidebar',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Set Shop Page Sidebar.', 'ideabuz' ),
                'subtitle' => esc_html__( 'Choose shop page sidebar', 'ideabuz' ),
                //Must provide key => value(array:title|img) pairs for radio options
                'options'  => array(
                    '1' => array(
                        'alt' => esc_attr__('1 Column','ideabuz'),
                        'img' => esc_url( get_template_directory_uri(). '/assets/img/no-sideber.png')
                    ),
                    '2' => array(
                        'alt' => esc_attr__('2 Column Left','ideabuz'),
                        'img' => esc_url( get_template_directory_uri() .'/assets/img/left-sideber.png')
                    ),
                    '3' => array(
                        'alt' => esc_attr__('2 Column Right','ideabuz'),
                        'img' => esc_url(  get_template_directory_uri() .'/assets/img/right-sideber.png' )
                    ),

                ),
                'default'  => '1'
            ),
            array(
                'id'       => 'ideabuz_woo_product_col',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Product Column', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set your woocommerce product column.', 'ideabuz' ),
                //Must provide key => value(array:title|img) pairs for radio options
                'options'  => array(
                    '2' => array(
                        'alt' => esc_attr__('2 Columns','ideabuz'),
                        'img' => esc_url( get_template_directory_uri() .'/assets/img/2col.png')
                    ),
                    '3' => array(
                        'alt' => esc_attr__('3 Columns','ideabuz'),
                        'img' => esc_url(  get_template_directory_uri() .'/assets/img/3col.png' )
                    ),
                    '4' => array(
                        'alt' => esc_attr__('4 Columns','ideabuz'),
                        'img' => esc_url( get_template_directory_uri(). '/assets/img/4col.png')
                    ),
                    '6' => array(
                        'alt' => esc_attr__('6 Columns','ideabuz'),
                        'img' => esc_url(  get_template_directory_uri() .'/assets/img/6col.png' )
                    ),

                ),
                'default'  => '3'
            ),
			array(
                'id'       => 'ideabuz_woo_product_perpage',
                'type'     => 'text',
                'title'    => esc_html__( 'Product Per Page', 'ideabuz' ),
				'default' => '10'
            ),
            array(
                'id'       => 'ideabuz_woo_singlepage_sidebar',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Product Single Page sidebar', 'ideabuz' ),
                'subtitle' => esc_html__( 'Choose product single page sidebar.', 'ideabuz' ),
                //Must provide key => value(array:title|img) pairs for radio options
                'options'  => array(
                    '1' => array(
                        'alt' => esc_attr__('1 Column','ideabuz'),
                        'img' => esc_url( get_template_directory_uri(). '/assets/img/no-sideber.png')
                    ),
                    '2' => array(
                        'alt' => esc_attr__('2 Column Left','ideabuz'),
                        'img' => esc_url( get_template_directory_uri() .'/assets/img/left-sideber.png')
                    ),
                    '3' => array(
                        'alt' => esc_attr__('2 Column Right','ideabuz'),
                        'img' => esc_url(  get_template_directory_uri() .'/assets/img/right-sideber.png' )
                    ),

                ),
                'default'  => '1'
            ),
            array(
                'id'       => 'ideabuz_product_details_title_position',
                'type'     => 'button_set',
                'default'  => 'header',
                'options'  => array(
                    'header'        => esc_html__('On Header','ideabuz'),
                    'below'         => esc_html__('Below Thumbnail','ideabuz'),
                ),
                'title'    => esc_html__('Product Details Title Position', 'ideabuz'),
                'subtitle' => esc_html__('Control product details title position from here.', 'ideabuz'),
            ),
			array(
                'id'       => 'ideabuz_woo_relproduct_num',
                'type'     => 'text',
                'title'    => esc_html__( 'Related products number', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set how many related products you want to show in single product page.', 'ideabuz' ),
                'default'  => 3
            ),
            array(
                'id'       => 'ideabuz_woo_related_product_col',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Related Product Column', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set your woocommerce related product column.', 'ideabuz' ),
                //Must provide key => value(array:title|img) pairs for radio options
                'options'  => array(
                    '2' => array(
                        'alt' => esc_attr__('2 Columns','ideabuz'),
                        'img' => esc_url( get_template_directory_uri() .'/assets/img/2col.png')
                    ),
                    '3' => array(
                        'alt' => esc_attr__('3 Columns','ideabuz'),
                        'img' => esc_url(  get_template_directory_uri() .'/assets/img/3col.png' )
                    ),
                    '4' => array(
                        'alt' => esc_attr__('4 Columns','ideabuz'),
                        'img' => esc_url( get_template_directory_uri(). '/assets/img/4col.png')
                    ),
                    '6' => array(
                        'alt' => esc_attr__('6 Columns','ideabuz'),
                        'img' => esc_url(  get_template_directory_uri() .'/assets/img/6col.png' )
                    ),

                ),
                'default'  => '4'
            ),
            array(
                'id'       => 'ideabuz_woo_upsellproduct_num',
                'type'     => 'text',
                'title'    => esc_html__( 'Upsells products number', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set how many upsells products you want to show in single product page.', 'ideabuz' ),
                'default'  => 3,
            ),

            array(
                'id'       => 'ideabuz_woo_upsell_product_col',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Upsells Product Column', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set your woocommerce upsell product column.', 'ideabuz' ),
                //Must provide key => value(array:title|img) pairs for radio options
                'options'  => array(
                    '2' => array(
                        'alt' => esc_attr__('2 Columns','ideabuz'),
                        'img' => esc_url( get_template_directory_uri() .'/assets/img/2col.png')
                    ),
                    '3' => array(
                        'alt' => esc_attr__('3 Columns','ideabuz'),
                        'img' => esc_url(  get_template_directory_uri() .'/assets/img/3col.png' )
                    ),
                    '4' => array(
                        'alt' => esc_attr__('4 Columns','ideabuz'),
                        'img' => esc_url( get_template_directory_uri(). '/assets/img/4col.png')
                    ),
                    '6' => array(
                        'alt' => esc_attr__('6 Columns','ideabuz'),
                        'img' => esc_url(  get_template_directory_uri() .'/assets/img/6col.png' )
                    ),

                ),
                'default'  => '4'
            ),
            array(
                'id'       => 'ideabuz_woo_crosssellproduct_num',
                'type'     => 'text',
                'title'    => esc_html__( 'Cross sell products number', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set how many cross sell products you want to show in single product page.', 'ideabuz' ),
                'default'  => 3,
            ),

            array(
                'id'       => 'ideabuz_woo_crosssell_product_col',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Cross sell Product Column', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set your woocommerce cross sell product column.', 'ideabuz' ),
                //Must provide key => value(array:title|img) pairs for radio options
                'options'  => array(
                    '6' => array(
                        'alt' => esc_attr__('2 Columns','ideabuz'),
                        'img' => esc_url( get_template_directory_uri() .'/assets/img/2col.png')
                    ),
                    '3' => array(
                        'alt' => esc_attr__('3 Columns','ideabuz'),
                        'img' => esc_url(  get_template_directory_uri() .'/assets/img/3col.png' )
                    ),
                    '4' => array(
                        'alt' => esc_attr__('4 Columns','ideabuz'),
                        'img' => esc_url( get_template_directory_uri(). '/assets/img/4col.png')
                    ),
                    '6' => array(
                        'alt' => esc_attr__('6 Columns','ideabuz'),
                        'img' => esc_url(  get_template_directory_uri() .'/assets/img/6col.png' )
                    ),

                ),
                'default'  => '4'
            ),
        ),
    ) );
    /* End Woo Page option */
    
    // -> start footer
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Offcanvas Sidebar', 'ideabuz' ),
        'id'         => 'ideabuz_offcanvas',
        'icon'       => 'el el-briefcase',
        'fields'     => array(
            array(
                'id'        => 'ideabuz_offcanvas_cross_icon_color',
                'type'      => 'color',
                'output'    => array( 'fill'   => '.offcanvas-close svg path' ),
                'title'     => esc_html__( 'Cross Icon Color', 'ideabuz' ),
            ),
            array(
                'id'        => 'ideabuz_offcanvas_title_color',
                'type'      => 'color',
                'output'    => array( '.offcanvas-content .widget .widget-title *' ),
                'title'     => esc_html__( 'Offcanvas Title Color', 'ideabuz' ),
            ),
            array(
                'id'        => 'ideabuz_offcanvas_content_color',
                'type'      => 'color',
                'output'    => array( '.about-content p','.offcanvas-wrapper .offcanvas-content .widget.widget_contact_info .single-info span','.offcanvas-wrapper .offcanvas-content .widget.widget_contact_info .single-info p' ),
                'title'     => esc_html__( 'Offcanvas Content Color', 'ideabuz' ),
            ),
            array(
                'id'        => 'ideabuz_offcanvas_ancor_color',
                'type'      => 'color',
                'output'    => array( '.offcanvas-wrapper .offcanvas-content .widget.widget_contact_info .single-info p a','.offcanvas-btn a span' ),
                'title'     => esc_html__( 'Offcanvas Ancor Color', 'ideabuz' ),
            ),
            array(
                'id'        => 'ideabuz_offcanvas_ancor_hover_color',
                'type'      => 'color',
                'output'    => array( '.offcanvas-wrapper .offcanvas-content .widget.widget_contact_info .single-info p a:hover','.offcanvas-btn a:hover span' ),
                'title'     => esc_html__( 'Offcanvas Ancor Hover Color', 'ideabuz' ),
            ),
            array(
                'id'        => 'ideabuz_offcanvas_background_color',
                'type'      => 'color',
                'title'     => esc_html__( 'Offcanvas Background Color', 'ideabuz' ),
            ),
        ),
    ) );
    // -> start footer
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Footer', 'ideabuz' ),
        'id'         => 'ideabuz_footer',
        'icon'       => 'el el-home',
        'fields'     => array(
            array(
                'id'       => 'ideabuz_footerwidget_enable',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Footer Widget Enabled/Disabled', 'ideabuz' ),
                'options'  => array(
                    '1'         => esc_html__( 'enabled','ideabuz' ),
                    '2'         => esc_html__( 'disable','ideabuz' ),
                ),
                'default'   => '2'
            ),
            array(
                'id'       => 'ideabuz_footercol_switch',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Select Widget Column', 'ideabuz' ),
                'options'  => array(
                    '1'       => array(
                        'alt'   => '2 Column Left',
                        'img'   => ReduxFramework::$_url . 'assets/img/2-col-portfolio.png'
                    ),
                    '2'       => array(
                        'alt'   => '3 Column Right',
                        'img'   => ReduxFramework::$_url . 'assets/img/3-col-portfolio.png'
                    ),

                    '3'       => array(
                        'alt'   => '4 Column Right',
                        'img'   => ReduxFramework::$_url . 'assets/img/4-col-portfolio.png'
                    ),

                ),
                'default'   => '3',
                'required'  => array( 'ideabuz_footerwidget_enable','equals','1' ),
            ),
            array(
                'id'       => 'ideabuz_footercol_style',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Footer Column Style', 'ideabuz' ),
                'options'       => array(
                    'one'         => esc_html__( 'Style One', 'ideabuz' ),
                    'two'         => esc_html__( 'Style Two', 'ideabuz' ),
                ),
                'default'   => 'two',
                'required'  => array( 'ideabuz_footerwidget_enable','equals','1' ),
            ),
            array(
                'id'        => 'ideabuz_footer_widget_background',
                'type'      => 'background',
                'output'    => array( 'footer.footer' ),
                'title'     => esc_html__( 'Footer widget Background ', 'ideabuz' ),
                'subtitle'  => esc_html__( 'Set Footer Widget Background .', 'ideabuz' ),
                'preview'   => false,
                'required'  => array( 'ideabuz_footerwidget_enable','equals','1' ),
            ),
            array(
                'id'        => 'ideabuz_footer_widget_title_color',
                'type'      => 'color',
                'output'    => array( 'footer .widget .widget-title h4' ),
                'title'     => esc_html__( 'Footer widget title color ', 'ideabuz' ),
                'subtitle'  => esc_html__( 'Set footer widget title color .', 'ideabuz' ),
                'required'  => array( 'ideabuz_footerwidget_enable','equals','1' ),
            ),
            array(
                'id'        => 'ideabuz_footer_widget_color',
                'type'      => 'color',
                'output'    => array( 'footer .widget.widget_recent_entries .single-post .post-content .posted-on','footer .widget.widget_newsletter .newsletter-content p','footer .about-content p','.footer .widget.widget_contact_info .single-info span','footer .widget.widget_contact_info .single-info p' ),
                'title'     => esc_html__( 'Footer Content  color', 'ideabuz' ),
                'subtitle'  => esc_html__( 'Set footer Content  color .', 'ideabuz' ),
                'required'  => array( 'ideabuz_footerwidget_enable','equals','1' ),
            ),
            array(
                'id'        => 'ideabuz_footer_widget_ancor_color',
                'type'      => 'color',
                'output'    => array( 'footer .widget.widget_contact_info .single-info p a','footer .widget.widget_recent_entries  .single-post .post-content h5 a','footer .widget.widget_nav_menu ul li a' ),
                'title'     => esc_html__( 'Footer widget Ancor Color', 'ideabuz' ),
                'subtitle'  => esc_html__( 'Set Footer widget Widget Color', 'ideabuz' ),
                'required'  => array( 'ideabuz_footerwidget_enable','equals','1' ),
            ),
            array(
                'id'        => 'ideabuz_footer_widget_ancor_hover_color',
                'type'      => 'color',
                'output'    => array( 'footer .widget.widget_contact_info .single-info p a:hover','footer .widget.widget_recent_entries  .single-post .post-content h5 a:hover','footer .widget.widget_nav_menu ul li a:hover' ),
                'title'     => esc_html__( 'Footer widget Ancor Hover Color', 'ideabuz' ),
                'subtitle'  => esc_html__( 'Set Footer Widget Ancor Hover Color', 'ideabuz' ),
                'required'  => array( 'ideabuz_footerwidget_enable','equals','1' ),
            ),
            array(
                'id'        => 'ideabuz_footer_border_bottom',
                'type'      => 'switch',
                'title'     => esc_html__( 'On/Off Border Under Footer Widget', 'ideabuz' ),
                'required'  => array( 'ideabuz_footerwidget_enable','equals','1' ),
            ),
            array(
                'id'        => 'ideabuz_footer_border_bottom_color',
                'type'      => 'color',
                'title'     => esc_html__( 'Border Color', 'ideabuz' ),
                'required'  => array( 'ideabuz_footer_border_bottom','equals','1' ),
            ),
            array(
                'id'       => 'ideabuz_footer_background',
                'type'     => 'background',
                'output'   => array( 'background-color' => '.footer-bottom' ),
                'title'    => esc_html__( 'Footer Copyright Background ', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Footer Background Color', 'ideabuz' ),
            ),
            array(
                'id'       => 'ideabuz_copyright',
                'type'     => 'text',
                'title'    => esc_html__( 'Copyright Text', 'ideabuz' ),
                'subtitle' => esc_html__( 'Add Copyright Text', 'ideabuz' ),
                'default'  => '<a href="#">ideabuz</a> &copy; Copyright 2019.All rights reserved.'
            ),
            array(
                'id'       => 'ideabuz_copyright_color',
                'type'     => 'color',
                'output'   => array( '.copyright-text span' ),
                'title'    => esc_html__('Copyright Text Color', 'ideabuz'),
                'subtitle' => esc_html__('Choose Copyright Text Color', 'ideabuz'),
            ),
            array(
                'id'       => 'ideabuz_copyright_ancor_color',
                'type'     => 'color',
                'output'   => array( '.copyright-text span a' ),
                'title'    => esc_html__('Copyright Ancor Color', 'ideabuz'),
                'subtitle' => esc_html__('Set Copyright Ancor Color', 'ideabuz'),
            ),
            array(
                'id'       => 'ideabuz_copyright_ancor_hover_color',
                'type'     => 'color',
                'output'   => array( '.copyright-text span a:hover' ),
                'title'    => esc_html__( 'Copyright Ancor Hover Color', 'ideabuz' ),
                'subtitle' => esc_html__( 'Set Copyright Ancor Hover Color', 'ideabuz' ),
            ),
        ),
    ) );
    // -> START Custom Css
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Custom Css', 'ideabuz' ),
        'id'         => 'ideabuz_custom_css_section',
        'icon'       => 'el el-css',
        'fields'     => array(
            array(
                'id'       => 'ideabuz_css_editor',
                'type'     => 'ace_editor',
                'title'    => esc_html__('CSS Code', 'ideabuz'),
                'subtitle' => esc_html__('Paste your CSS code here.', 'ideabuz'),
                'mode'     => 'css',
                'theme'    => 'monokai',
            )
        ),
    ) );

    /* End custom css */

    /*
     * <--- END SECTIONS
     */


    /*
     *
     * YOU MUST PREFIX THE FUNCTIONS BELOW AND ACTION FUNCTION CALLS OR ANY OTHER CONFIG MAY OVERRIDE YOUR CODE.
     *
     */

    /*
    *
    * --> Action hook examples
    *
    */

    // If Redux is running as a plugin, this will remove the demo notice and links
    //add_action( 'redux/loaded', 'remove_demo' );

    // Function to test the compiler hook and demo CSS output.
    // Above 10 is a priority, but 2 in necessary to include the dynamically generated CSS to be sent to the function.
    //add_filter('redux/options/' . $opt_name . '/compiler', 'compiler_action', 10, 3);

    // Change the arguments after they've been declared, but before the panel is created
    //add_filter('redux/options/' . $opt_name . '/args', 'change_arguments' );

    // Change the default value of a field after it's been set, but before it's been useds
    //add_filter('redux/options/' . $opt_name . '/defaults', 'change_defaults' );

    // Dynamically add a section. Can be also used to modify sections/fields
    //add_filter('redux/options/' . $opt_name . '/sections', 'dynamic_section');

    /**
     * This is a test function that will let you see when the compiler hook occurs.
     * It only runs if a field    set with compiler=>true is changed.
     * */
    if ( ! function_exists( 'compiler_action' ) ) {
        function compiler_action( $options, $css, $changed_values ) {
            echo '<h1>'.esc_html__( 'The compiler hook has run!', 'ideabuz' ).'</h1>';
            echo "<pre>";
            print_r( $changed_values ); // Values that have changed since the last save
            echo "</pre>";
            //print_r($options); //Option values
            //print_r($css); // Compiler selector CSS values  compiler => array( CSS SELECTORS )
        }
    }

    /**
     * Custom function for the callback validation referenced above
     * */
    if ( ! function_exists( 'redux_validate_callback_function' ) ) {
        function redux_validate_callback_function( $field, $value, $existing_value ) {
            $error   = false;
            $warning = false;

            //do your validation
            if ( $value == 1 ) {
                $error = true;
                $value = $existing_value;
            } elseif ( $value == 2 ) {
                $warning = true;
                $value   = $existing_value;
            }

            $return['value'] = $value;

            if ( $error == true ) {
                $return['error'] = $field;
                $field['msg']    = esc_html__( 'your custom error message', 'ideabuz' );
            }

            if ( $warning == true ) {
                $return['warning'] = $field;
                $field['msg']      = esc_html__( 'your custom warning message', 'ideabuz' );
            }

            return $return;
        }
    }

    /**
     * Custom function for the callback referenced above
     */
    if ( ! function_exists( 'redux_my_custom_field' ) ) {
        function redux_my_custom_field( $field, $value ) {
            print_r( $field );
            echo '<br/>';
            print_r( $value );
        }
    }

    /**
     * Custom function for filtering the sections array. Good for child themes to override or add to the sections.
     * Simply include this function in the child themes functions.php file.
     * NOTE: the defined constants for URLs, and directories will NOT be available at this point in a child theme,
     * so you must use get_template_directory_uri() if you want to use any of the built in icons
     * */
    if ( ! function_exists( 'dynamic_section' ) ) {
        function dynamic_section( $sections ) {
            //$sections = array();
            $sections[] = array(
                'title'  => esc_html__( 'Section via hook', 'ideabuz' ),
                'desc'   => wp_kses( esc_html__( '<p class="description">This is a section created by adding a filter to the sections array. Can be used by child themes to add/remove sections from the options.</p>', 'ideabuz' ), $alowhtml),
                'icon'   => 'el el-paper-clip',
                // Leave this as a blank section, no options just some intro text set above.
                'fields' => array()
            );

            return $sections;
        }
    }

    /**
     * Filter hook for filtering the args. Good for child themes to override or add to the args array. Can also be used in other functions.
     * */
    if ( ! function_exists( 'change_arguments' ) ) {
        function change_arguments( $args ) {
            //$args['dev_mode'] = true;

            return $args;
        }
    }

    /**
     * Filter hook for filtering the default value of any given field. Very useful in development mode.
     * */
    if ( ! function_exists( 'change_defaults' ) ) {
        function change_defaults( $defaults ) {
            $defaults['str_replace'] = esc_html__( 'Testing filter hook!', 'ideabuz' );

            return $defaults;
        }
    }