<?php
	function ideabuz_widgets_init() {
		register_sidebar(
			array(
				'name'          => esc_html__( 'Blog Page Sidebar', 'ideabuz' ),
				'id'            => 'ideabuz_blog_sidebar',
				'description'   => esc_html__( 'Add widgets here to appear in your sidebar.', 'ideabuz' ),
				'before_widget' => '<div class="widget %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<div class="widget-title"><h4>',
				'after_title'   => '</h4></div>',
			)
		);
		register_sidebar(
			array(
				'name'          => esc_html__( 'Page Sidebar', 'ideabuz' ),
				'id'            => 'ideabuz_page_sidebar',
				'description'   => esc_html__( 'Add Widgets Here To Appear In Your Page Sidebar.', 'ideabuz' ),
				'before_widget' => '<div class="widget %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<div class="widget-title"><h4>',
				'after_title'   => '</h4></div>',
			)
		);
		register_sidebar(
			array(
				'name'          => esc_html__( 'Off Canvas Sidebar', 'ideabuz' ),
				'id'            => 'ideabuz_offcanvas_sidebar',
				'description'   => esc_html__( 'Add widgets here to appear in offcanvas sidebar.', 'ideabuz' ),
				'before_widget' => '<div class="widget %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<div class="widget-title"><h4>',
				'after_title'   => '</h4></div>',
			)
		);
		register_sidebar(
			array(
				'name'          => esc_html__( 'Service Details Sidebar', 'ideabuz' ),
				'id'            => 'ideabuz_service_sidebar',
				'description'   => esc_html__( 'Add widgets here to appear in Service Deatils sidebar.', 'ideabuz' ),
				'before_widget' => '<div class="widget %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<div class="widget-title"><h4>',
				'after_title'   => '</h4></div>',
			)
		);
		register_sidebar(
			array(
				'name'          => esc_html__( 'Footer Sidebar One', 'ideabuz' ),
				'id'            => 'footer_sidebar_one',
				'description'   => esc_html__( 'Add widgets here to appear in your footer sidebar.', 'ideabuz' ),
				'before_widget' => '<div class="widget %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<div class="widget-title"><h4>',
				'after_title'   => '</h4></div>',
			)
		);
		register_sidebar(
			array(
				'name'          => esc_html__( 'Footer Sidebar Two', 'ideabuz' ),
				'id'            => 'footer_sidebar_two',
				'description'   => esc_html__( 'Add widgets here to appear in your footer sidebar.', 'ideabuz' ),
				'before_widget' => '<div class="widget %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<div class="widget-title"><h4>',
				'after_title'   => '</h4></div>',
			)
		);
		register_sidebar(
			array(
				'name'          => esc_html__( 'Footer Sidebar Three', 'ideabuz' ),
				'id'            => 'footer_sidebar_three',
				'description'   => esc_html__( 'Add widgets here to appear in your footer sidebar.', 'ideabuz' ),
				'before_widget' => '<div class="widget %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<div class="widget-title"><h4>',
				'after_title'   => '</h4></div>',
			)
		);
		register_sidebar(
			array(
				'name'          => esc_html__( 'Footer Sidebar Four', 'ideabuz' ),
				'id'            => 'footer_sidebar_four',
				'description'   => esc_html__( 'Add widgets here to appear in your footer sidebar.', 'ideabuz' ),
				'before_widget' => '<div class="widget %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<div class="widget-title"><h4>',
				'after_title'   => '</h4></div>',
			)
		);

		if( class_exists('woocommerce') ) {
			register_sidebar(
				array(
					'name'          => esc_html__( 'WooCommerce Sidebar', 'ideabuz' ),
					'id'            => 'ideabuz_woo_sidebar',
					'description'   => esc_html__( 'Add widgets here to appear in your woocommerce page sidebar.', 'ideabuz' ),
					'before_widget' => '<div class="widget %2$s">',
					'after_widget'  => '</div>',
					'before_title'  => '<div class="widget-title"><h4>',
					'after_title'   => '</h4></div>',
				)
			);
		}
	}
	add_action( 'widgets_init', 'ideabuz_widgets_init' );