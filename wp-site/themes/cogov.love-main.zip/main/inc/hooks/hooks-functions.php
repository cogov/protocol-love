<?php
	// Block direct access
	if( !defined( 'ABSPATH' ) ){
		exit( );
	}
	/**
	* @Packge 	   : Ideabuz
	* @Version     : 1.0
	* @Author 	   : ThemeLooks
	* @Author URI  : https://www.themelooks.com/
	*
	*/ 

    // Blog Post Thumbnail Function
    if( !function_exists( 'ideabuz_blog_posts_thumb_cb' ) ){
        function ideabuz_blog_posts_thumb_cb(){
        // post image 
            if( has_post_thumbnail() ){

                if( !is_single() ){
                    $wraperStart = '<div class="blog-image">';
                }else{
                    $wraperStart = '<div class="blog-details-image">';
                } 

                if( !is_single() ){
                    $wraperEnd = '</div>';
                }else{
                    $wraperEnd = '</div>';
                }

                $html = '';
                $html .= $wraperStart;
                $html .= ideabuz_img_tag(
                    array(
                        'url' => esc_url( get_the_post_thumbnail_url() ),
                    )
                );
                $html .= $wraperEnd;

                echo wp_kses_post( $html );

            }

            //End of post image

            //Thumbnail check and video and audio thumb show
            if( !is_single() && !has_post_thumbnail() ){
                $html = '';
                if( has_post_format( array( 'video' ) ) ){

                    $html .= '<div class="blog-video">';
                    $html .= ideabuz_embedded_media( array( 'video', 'iframe' ) );
                    $html .= '</div>';

                }else{

                    if( has_post_format( array( 'audio' ) ) ){

                        $html .= '<div class="blog-audio">';
                        $html .= ideabuz_embedded_media( array( 'audio', 'iframe' ) );
                        $html .= '</div>';
                    }
                }

                echo apply_filters( 'ideabuz_post_embedded_media' ,$html );

            }
        }
    }
	
	// Bizidea Preloader
	if( !function_exists( 'ideabuz_preloader_cb' ) ){
		function ideabuz_preloader_cb(){
			if( ideabuz_opt( 'ideabuz_display_preloader' ) ){
		    	echo "<div class='preloader w-100 h-100 position-fixed'>";
				    echo '<div class="preloader_inner">';
					if( !empty( ideabuz_opt( 'ideabuz_preloader_image','url' ) ) ){
						echo ideabuz_img_tag(array(
							'url'		=> esc_url( ideabuz_opt( 'ideabuz_preloader_image','url' ) ),
							'class'		=> esc_attr( 'icon' ),
						));
					}else{
						echo ideabuz_img_tag(array(
							'url'		=> esc_url( IDEABUZ_IMG_DIR_URI.'preloader.png' ),
							'class'		=> esc_attr( 'icon' ),
						));
					}
			        echo '</div>';
			    echo '</div>';
		    }
		}
	}
	
	// Bizidea Header Function
	if( !function_exists( 'ideabuz_header_cb' ) ){
		function ideabuz_header_cb(){
			get_template_part( 'template-part/header-navbar' );
			get_sidebar( 'offcanvas' );
			
			if( !is_page_template( 'coming-soon.php' ) ){
	
	            $ideabuz_page_header_enable = ideabuz_meta( 'page_header' );
	
	            if ( is_page_template( 'template-builder.php' )   ) {
	
	                if( $ideabuz_page_header_enable == 1 ){
	                    get_template_part( 'template-part/page-banner' );
	                }
	
	            }else{
	                get_template_part( 'template-part/page-banner' );
	            }
	        }
		}
	}
	
	// Blog, Single Post, Archive Wrapper Start Function
	if( !function_exists( 'ideabuz_blog_section_wrapper_start_cb' ) ){
		function ideabuz_blog_section_wrapper_start_cb(){
			echo '<section class="pt-120 pb-120">';
			    echo '<div class="container">';
			        echo '<div class="row">';
		}
	}
	// Page Wrapper Start Function
	if( !function_exists( 'ideabuz_page_wrapper_start_cb' ) ){
		function ideabuz_page_wrapper_start_cb(){
			echo '<section class="pt-120 pb-70">';
			    echo '<div class="container">';
			        echo '<div class="row">';
		}
	}
	
	// Blog, Single Post, Archive, Page Wrapper End Function
	if( !function_exists( 'ideabuz_blog_section_wrapper_end_cb' ) ){
		function ideabuz_blog_section_wrapper_end_cb(){
				    echo '</div>';
				echo '</div>';
			echo '</section>';
		}
	}
	
	// Blog, Single Post, Archive, Page Wrapper End Function
	if( !function_exists( 'ideabuz_page_wrapper_end_cb' ) ){
		function ideabuz_page_wrapper_end_cb(){
				    echo '</div>';
				echo '</div>';
			echo '</section>';
		}
	}
	
	// Blog Column Divider Start Function
	if( !function_exists( 'ideabuz_blog_column_divider_start_wrapper_cb' ) ){
		function ideabuz_blog_column_divider_start_wrapper_cb(){
			if( class_exists( 'ReduxFramework' ) && is_active_sidebar( 'ideabuz_blog_sidebar' ) ){
				$ideabuz_blog_layout = ideabuz_opt( 'ideabuz_blog_layout' );
				if( $ideabuz_blog_layout == '1' ){
					$ideabuz_blog_column = 'col-lg-12';
				}elseif( $ideabuz_blog_layout == '2' ){
					$ideabuz_blog_column = 'col-lg-8 order-last';
				}elseif( $ideabuz_blog_layout == '3' ){
					$ideabuz_blog_column = 'col-lg-8';
				}else{
					$ideabuz_blog_column = 'col-lg-8';
				}
			}elseif( is_active_sidebar( 'ideabuz_blog_sidebar' ) ){
				$ideabuz_blog_column = 'col-lg-8';
			}else{
				$ideabuz_blog_column = 'col-lg-12';
			}
			echo '<div class="'.esc_attr( $ideabuz_blog_column ).'">';
			if( is_search() ){
				$search_div = "";
			}else{
				$search_div = "blog-masonary";
			}
		        echo '<div class="row '.esc_attr( $search_div ).'">';
		}
	}
	
	
	// Blog Column Divider Start Function
	if( !function_exists( 'ideabuz_blog_details_column_divider_start_wrapper_cb' ) ){
		function ideabuz_blog_details_column_divider_start_wrapper_cb(){
			if( class_exists( 'ReduxFramework' ) && is_active_sidebar( 'ideabuz_blog_sidebar' ) ){
				$ideabuz_blog_layout = ideabuz_opt( 'ideabuz_blog_single_layout' );
				if( $ideabuz_blog_layout == '1' ){
					$ideabuz_blog_column = 'col-lg-12';
				}elseif( $ideabuz_blog_layout == '2' ){
					$ideabuz_blog_column = 'col-lg-8 order-last';
				}elseif( $ideabuz_blog_layout == '3' ){
					$ideabuz_blog_column = 'col-lg-8';
				}else{
					$ideabuz_blog_column = 'col-lg-8';
				}
			}elseif( is_active_sidebar( 'ideabuz_blog_sidebar' ) ){
				$ideabuz_blog_column = 'col-lg-8';
			}else{
				$ideabuz_blog_column = 'col-lg-12';
			}
			echo '<div class="'.esc_attr( $ideabuz_blog_column ).'">';
		}
	}
	
	// Page Column Divider Start Function
	if( !function_exists( 'ideabuz_page_column_divider_start_wrapper_cb' ) ){
		function ideabuz_page_column_divider_start_wrapper_cb(){
			if( class_exists( 'ReduxFramework' ) && is_active_sidebar( 'ideabuz_page_sidebar' ) ){
				$ideabuz_page_layout = ideabuz_opt( 'ideabuz_page_layout' );
				if( $ideabuz_page_layout == '1' ){
					$ideabuz_page_column = 'col-lg-12';
				}elseif( $ideabuz_page_layout == '2' ){
					$ideabuz_page_column = 'col-lg-8 order-last';
				}elseif( $ideabuz_page_layout == '3' ){
					$ideabuz_page_column = 'col-lg-8';
				}else{
					$ideabuz_page_column = 'col-lg-8';
				}
			}elseif( is_active_sidebar( 'ideabuz_page_sidebar' ) ){
				$ideabuz_page_column = 'col-lg-8';
			}else{
				$ideabuz_page_column = 'col-lg-12';
			}
			echo '<div class="'.esc_attr( $ideabuz_page_column ).'">';
		}
	}
	
	// Service Column Divider Start Function
	if( !function_exists( 'ideabuz_service_details_column_divider_start_wrapper_cb' ) ){
		function ideabuz_service_details_column_divider_start_wrapper_cb(){
			if( class_exists( 'ReduxFramework' ) && is_active_sidebar( 'ideabuz_service_sidebar' ) || is_active_sidebar( 'ideabuz_blog_sidebar' ) || is_active_sidebar( 'ideabuz_page_sidebar' ) ){
				$ideabuz_service_layout = ideabuz_opt( 'ideabuz_service_single_layout' );
				if( $ideabuz_service_layout == '1' ){
					$ideabuz_service_column = 'col-lg-12';
				}elseif( $ideabuz_service_layout == '2' ){
					$ideabuz_service_column = 'col-lg-8';
				}elseif( $ideabuz_service_layout == '3' ){
					$ideabuz_service_column = 'col-lg-8';
				}else{
					$ideabuz_service_column = 'col-lg-8';
				}
			}else{
				$ideabuz_service_column = 'col-lg-12';
			}
			echo '<div class="'.esc_attr( $ideabuz_service_column ).'">';
		}
	}
	
	// Blog Sidebar Wrapper
	if( !function_exists( 'ideabuz_blog_sidebar_wrapper_cb' ) ){
		function ideabuz_blog_sidebar_wrapper_cb(){
			$ideabuz_blog_layout = ideabuz_opt( 'ideabuz_blog_layout' );
			if( $ideabuz_blog_layout != '1' ){
				get_sidebar();
			}
		}
	}
	
	// Blog Single Page Sidebar Wrapper
	if( !function_exists( 'ideabuz_blog_single_sidebar_wrapper_cb' ) ){
		function ideabuz_blog_single_sidebar_wrapper_cb(){
			$ideabuz_blog_single_layout = ideabuz_opt( 'ideabuz_blog_single_layout' );
			if( $ideabuz_blog_single_layout != '1' ){
				get_sidebar();
			}
		}
	}
	
	// Blog Single Page Sidebar Wrapper
	if( !function_exists( 'ideabuz_page_sidebar_wrapper_cb' ) ){
		function ideabuz_page_sidebar_wrapper_cb(){
			$ideabuz_page_sidebar_layout = ideabuz_opt( 'ideabuz_page_layout' );
			if( $ideabuz_page_sidebar_layout != '1' ){
				get_sidebar( 'page' );
			}
		}
	}
	
	// Service Details Sidebar Wrapper
	if( !function_exists( 'ideabuz_service_details_sidebar_wrapper_cb' ) ){
		function ideabuz_service_details_sidebar_wrapper_cb(){
			$ideabuz_service_layout  = ideabuz_opt( 'ideabuz_service_single_layout' );
			$ideabuz_sideabar_option = ideabuz_opt( 'ideabuz_service_sidebar' );
			if( class_exists( 'ReduxFramework' ) && $ideabuz_service_layout != '1' ){
				if( $ideabuz_sideabar_option == '1' ){
					get_sidebar();
				}elseif( $ideabuz_sideabar_option == '2' ){
					get_sidebar( 'page' );
				}else{
					get_sidebar( 'service' );
				}
			}
		}
	}
	// Blog Post Column
	if( !function_exists( 'ideabuz_blog_post_column_cb' ) ){
		function ideabuz_blog_post_column_cb(){
		$ideabuz_post_column = ideabuz_opt( 'ideabuz_post_column' );
		if( class_exists( 'ReduxFramework' ) ){
			if( $ideabuz_post_column == '1' ){
				$ideabuz_blog_post_column = 'col-md-12';
			}elseif(  $ideabuz_post_column == '2' ){
				$ideabuz_blog_post_column = 'col-md-6';
			}elseif(  $ideabuz_post_column == '3' ){
				$ideabuz_blog_post_column = 'col-md-4';
			}elseif(  $ideabuz_post_column == '4' ){
				$ideabuz_blog_post_column = 'col-md-3';
			}else{
				$ideabuz_blog_post_column = 'col-md-6';
			}
		}else{
			$ideabuz_blog_post_column = 'col-md-12';
		}
		
		echo '<div class="'.esc_attr( $ideabuz_blog_post_column . ' grid-item' ).'">';
		}
	}
	
	// Global Double Div End 
	if( !function_exists( 'ideabuz_double_div_end_wrapper_cb' ) ){
		function ideabuz_double_div_end_wrapper_cb(){
				echo '</div>';
			echo '</div>';
		}
	}
	// Global Single Div End
	if( !function_exists( 'ideabuz_single_div_end_wrapper_cb' ) ){
		function ideabuz_single_div_end_wrapper_cb(){
			echo '</div>';
		}
	}
	
	// Blog Style Two Author Enable Disable
	if( !function_exists( 'ideabuz_blog_author_enable_disable_cb' ) ){
		function ideabuz_blog_author_enable_disable_cb(){
			if( class_exists( 'ReduxFramework' ) ){
				$ideabuz_author_enable = ideabuz_opt( 'ideabuz_author_enable' );
				if( $ideabuz_author_enable ){
					$ideabuz_author_enable = true;
				}else{
					$ideabuz_author_enable = false;
				}
			}else{
				$ideabuz_author_enable = true;
			}
			if( !is_single() ){
				$author_name = 'Posted by:';
			}else{
				$author_name = 'By:';
			}
			if( $ideabuz_author_enable ){
				echo '<li>'.esc_html( $author_name ).' <a href="'.esc_url( get_author_posts_url( get_the_author_meta('ID') ) ).'">'.esc_html( ucwords( get_the_author() ) ).'</a></li>';
			}
		}
	}
	
	
	// Blog Style Two Comment Enable Disable
	if( !function_exists( 'ideabuz_blog_comment_enable_disable_cb' ) ){
		function ideabuz_blog_comment_enable_disable_cb(){
			if( class_exists( 'ReduxFramework' ) ){
				$ideabuz_comment_enable = ideabuz_opt( 'ideabuz_comment_enable' );
				if( $ideabuz_comment_enable ){
					$ideabuz_comment_enable = true;
				}else{
					$ideabuz_comment_enable = false;
				}
			}else{
				$ideabuz_comment_enable = true;
			}
			
			if( $ideabuz_comment_enable ){
				echo '<li>';
				esc_html( comments_number( 'Comment: ','Comment: ','Comments: ' ) );
				echo '<span>'.esc_html( get_comments_number() ).'</span></li>';
			}
		}
	}
	
	// Blog Post Excerpt
	if( !function_exists( 'ideabuz_blog_post_excerpt_cb' ) ){
		function ideabuz_blog_post_excerpt_cb(){
			// Bizdidea Excerpt
			echo ideabuz_paragraph_tag( array(
				'text'  => esc_html( get_the_excerpt() ),
				'class'	=> esc_attr( 'blog-excerpt' )
			) );
		}
	}
	
	// Blog Read More Button Text
	if( !function_exists( 'ideabuz_blog_read_more_button_cb' ) ){
		function ideabuz_blog_read_more_button_cb(){
			// Read More Button Text
			if( class_exists( 'ReduxFramework' ) ){
				$ideabuz_read_more_button_text = ideabuz_opt( 'ideabuz_button_text' );
				if( $ideabuz_read_more_button_text ){
					$ideabuz_read_more_button_text = $ideabuz_read_more_button_text;
				}else{
					$ideabuz_read_more_button_text = 'Read More';
				}
			}else{
				$ideabuz_read_more_button_text = 'Read More';
			}
			if( $ideabuz_read_more_button_text ){
				echo '<a href="'.esc_url( get_the_permalink() ).'" class="btn-inline">'.esc_html( $ideabuz_read_more_button_text ).'</a>';
			}
		}
	}
	
	// Post Pagination
	if( !function_exists( 'ideabuz_blog_post_pagination_cb' ) ){
		function ideabuz_blog_post_pagination_cb(){
			if( class_exists( 'ReduxFramework' ) ){
				$ideabuz_pagination_position = ideabuz_opt( 'ideabuz_pagination_position' );
				if( $ideabuz_pagination_position == 'center' ){
					$pagination_position = 'justify-content-center';
				}else{
					$pagination_position = '';
				}
			}else{
				$pagination_position = 'justify-content-center';
			}
			if( get_previous_posts_link() || get_next_posts_link() ):
				echo '<div class="row">';
					echo '<div class="col-12">'; 
		                echo '<div class="pagination '.esc_attr( $pagination_position ).'">';
							echo '<ul class="nav align-items-center">';
								if( get_previous_posts_link( ) ) {
									echo '<li class="nav-btn prev">';
										$prev_post_pagination_image = ideabuz_img_tag( array(
											'url'	=> esc_url( IDEABUZ_IMG_DIR_URI.'icons/pagination-left.svg' ),
											'class'	=> esc_attr( "svg" )
										) );
										$prev_post_pagination_image_two = ideabuz_img_tag( array(
											'url'	=> esc_url( IDEABUZ_IMG_DIR_URI.'icons/angle-left-red.svg' ),
											'class'	=> esc_attr( "svg" )
										) );
										previous_posts_link( $prev_post_pagination_image.$prev_post_pagination_image_two );
				                    echo '</li>';	
								}
								$blog_paginate_links = paginate_links( array(
									'prev_next'          => false,
									'type'               => 'array',
								) );
								if( !empty( $blog_paginate_links ) ) {
									foreach(  $blog_paginate_links as $singlelink ){
										echo '<li>'.wp_kses_post( $singlelink ).'<li>';
									}
								}
								if( get_next_posts_link( ) ) {
									echo '<li class="nav-btn next">';
										$post_pagination_image = ideabuz_img_tag( array(
											'url'	=> esc_url( IDEABUZ_IMG_DIR_URI.'icons/pagination-right.svg' ),
											'class'	=> esc_attr( "svg" )
										) );
										$post_pagination_image_two = ideabuz_img_tag( array(
											'url'	=> esc_url( IDEABUZ_IMG_DIR_URI.'icons/angle-right-red.svg' ),
											'class'	=> esc_attr( "svg" )
										) );
										next_posts_link( $post_pagination_image.$post_pagination_image_two );
				                    echo '</li>';
								}
			                echo '</ul>';
		                echo '</div>';
		            echo '</div>';
	            echo '</div>';
			endif;
		}
	}
	
	// Single Post Navigation
	if( !function_exists( 'ideabuz_single_post_navigation_cb' ) ){
		function ideabuz_single_post_navigation_cb(){
			if( class_exists( 'ReduxFramework' ) ){
				$navigation_on_off = ideabuz_opt( 'ideabuz_enable_disable_navigation' );
			}else{
				$navigation_on_off = true;
			}
			if( $navigation_on_off ):
				$ideabuz_prev_post = get_previous_post();
				$ideabuz_next_post = get_next_post();
				if( $ideabuz_prev_post || $ideabuz_next_post ):
		?>
	<!-- Post Pagination Begin -->
	<div class="post-pagination d-flex align-items-center justify-content-between flex-column flex-md-row">
		<!-- Single Post Pagination Begin -->
		<?php
			if( $ideabuz_prev_post ) :
		?>
		<div class="single-post-pagination prev media align-items-center mb-50 mb-md-0">
			<?php if( get_the_post_thumbnail( $ideabuz_prev_post->ID ) ):?>
			<div class="pagination-image">
				<a href="<?php echo esc_url( get_permalink( $ideabuz_prev_post->ID ) ); ?>">
					<?php echo wp_kses_post( get_the_post_thumbnail( $ideabuz_prev_post->ID,array( 88, 88) ) ); ?>
				</a>
			</div>
			<?php endif;?>
			<div class="media-body">
				<a href="<?php echo esc_url( get_permalink( $ideabuz_prev_post->ID ) ); ?>" class="d-inline-flex align-items-center">
					<?php
						echo ideabuz_img_tag(array(
							'url'	=> esc_url( IDEABUZ_IMG_DIR_URI.'icons/angle-left.svg' ),
							'class'	=> esc_attr( "svg" )
						));
						esc_html_e( 'previous','ideabuz' );
					?>
				</a>
				<h6><?php echo wp_kses_post( $ideabuz_prev_post->post_title );?></h6>
			</div>
		</div>
		<?php
			endif;
			if( $ideabuz_next_post ):
		?>
		<div class="single-post-pagination next media flex-row-reverse align-items-center">
			<?php if( get_the_post_thumbnail( $ideabuz_next_post->ID ) ):?>
			<div class="pagination-image">
				<a href="<?php echo esc_url( get_permalink( $ideabuz_next_post->ID ) ); ?>">
					<?php echo wp_kses_post( get_the_post_thumbnail( $ideabuz_next_post->ID,array( 88, 88 ) ) ) ; ?>
				</a>
			</div>
			<?php endif;?>
			<div class="media-body text-right">
				<a href="<?php echo esc_url( get_permalink( $ideabuz_next_post->ID ) ); ?>" class="d-inline-flex flex-row-reverse align-items-center">
					<?php
						echo ideabuz_img_tag(array(
							'url'	=> esc_url( IDEABUZ_IMG_DIR_URI.'icons/angle-right.svg' ),
							'class'	=> esc_attr( "svg" )
						));
						esc_html_e( 'next','ideabuz' );
					?>
				</a>
				<h6><?php echo wp_kses_post( $ideabuz_next_post->post_title );?></h6>
			</div>
		</div>
		<?php endif;?>
		<!-- Single Post Pagination End -->
	</div>
	<!-- Post Pagination End -->
	<?php
		endif;
		endif;
		}
	}
	
	// Blog Post Comments Show Function
	if( !function_exists( 'ideabuz_single_post_comments_show_wrap_cb' ) ){
		function ideabuz_single_post_comments_show_wrap_cb(){
			// Comment Template
			if ( comments_open() || get_comments_number() ) {
				comments_template();
			}
		}
	}
	
	// Back To Top
	
	if( !function_exists( 'ideabuz_back_to_top_cb' ) ){
		function ideabuz_back_to_top_cb(){
			
			    if( ideabuz_opt( "ideabuz_display_backtotop" ) ):
			?>
			<!-- Back to Top Begin -->
			<a href="#" class="back-to-top position-fixed">
			    <div class="back-toop-tooltip">
			        <?php
			            $ideabuz_back_top_text = ideabuz_opt( "ideabuz_backtotop_text" );
						if( class_exists( 'ReduxFramework' ) ){
				            echo ideabuz_span_tag(array(
				                "text"  => wp_kses_post( $ideabuz_back_top_text )
				            ));
						}else{
							echo ideabuz_span_tag(array(
				                "text"  => esc_html__( 'Back To Top','ideabuz' ),
				            ));
						}
			        ?>
			    </div>
			    <div class="top-arrow"></div>
			    <div class="top-line"></div>
			</a>
			<?php
		endif;
		}
	}
	
	// footer Bottom
	
	if( !function_exists( 'ideabuz_footer_bottom_cb' ) ){
		function ideabuz_footer_bottom_cb(){
		        if( class_exists( 'ReduxFramework' ) ){
		            $ideabuz_bg_class = '';
		        }else{
		            $ideabuz_bg_class = 'bg-light';
		        }
		    ?>
		    <div class="footer-bottom <?php echo esc_attr( $ideabuz_bg_class );?>">
		        <div class="container">
		            <div class="row">
		                <div class="col-12">
		                    <div class="copyright-text text-center">
		                        <span>
		                            <?php
		                                $ideabuz_footer_text_default = sprintf(
		                                    __( '<a href="%s">%s</a> &copy; Copyright %s.All rights reserved.','ideabuz' ),
		                                    esc_url( home_url('/') ),
		                                    'Ideabuz',
		                                    date( 'Y' )
		                                );
		                                $ideabuz_footer_text = ideabuz_opt( "ideabuz_copyright" );
		                                if( !empty( $ideabuz_footer_text ) ){
		                                    echo wp_kses_post( $ideabuz_footer_text );
		                                }else{
		                                    echo wp_kses_post( $ideabuz_footer_text_default );
		                                }
		                            ?>
		                        </span>
		                    </div>
		                </div>
		            </div>
		        </div>
		    </div>
			<?php
		}
	}
	
	// footer Bottom
	
	if( !function_exists( 'ideabuz_footer_widget_cb' ) ){
		function ideabuz_footer_widget_cb(){
		        $ideabuz_footer_widget_enable = ideabuz_opt( 'ideabuz_footerwidget_enable' );
		        $ideabuz_footer_widget_col = ideabuz_opt( 'ideabuz_footercol_switch' );
		        $ideabuz_footer_column_style = ideabuz_opt( 'ideabuz_footercol_style' );
		        $ideabuz_footer_widget_col_val = "";
		        $ideabuz_sidebar_one = '';
		        $ideabuz_sidebar_two = '';
		        $ideabuz_sidebar_three = '';
		        $ideabuz_sidebar_four = '';
		        if( $ideabuz_footer_widget_col == '1' ) {
		            if( $ideabuz_footer_column_style == 'one' ){
		                $ideabuz_footer_widget_col_val = '6';
		            }else{
		                $ideabuz_footer_widget_col_val = '6';
		            }
		        }elseif( $ideabuz_footer_widget_col == '2' ) {
		            $ideabuz_footer_widget_col_val = '4';
		        }else{
		            if( $ideabuz_footer_column_style == 'one' ){
		                $ideabuz_footer_widget_col_val = '3';
		            }else{
		                $ideabuz_sidebar_one = '3';
		                $ideabuz_sidebar_two = '3';
		                $ideabuz_sidebar_three = '2';
		                $ideabuz_sidebar_four = '4';
		            }
		        }
		        
		        if( $ideabuz_footer_widget_enable == '1' ):
		            $ideabuz_footer_border = ideabuz_opt( "ideabuz_footer_border_bottom" );
		            if( class_exists( 'ReduxFramework' ) ){
		                if( $ideabuz_footer_border ){
		                    $ideabuz_border_class = "border-bottom";
		                }else{
		                    $ideabuz_border_class = "";
		                }
		            }else{
		                $ideabuz_border_class = "border-bottom";
		            }
		    ?>
		    <!-- Footer Top Begin -->
		    <div class="footer-top pt-60">
		        <div class="container <?php echo esc_attr( $ideabuz_border_class );?>">
		            <div class="row">
		                <?php
		                    if( $ideabuz_footer_widget_col == '1' || $ideabuz_footer_widget_col == '2' || $ideabuz_footer_widget_col == '3' ) :
		                        if( is_active_sidebar( 'footer_sidebar_one' ) ) :
		                ?>
		                <div class="col-lg-<?php echo esc_attr( $ideabuz_footer_widget_col_val.$ideabuz_sidebar_one ); ?>  col-sm-6">
		                    <?php
		                        dynamic_sidebar( 'footer_sidebar_one' );
		                    ?>
		                </div>
		                <?php
		                        endif;
		                    endif;
		
		                    if( $ideabuz_footer_widget_col == '1' || $ideabuz_footer_widget_col == '2' || $ideabuz_footer_widget_col == '3' ) :
		                        if( is_active_sidebar( 'footer_sidebar_two' ) ) :
		                ?>
		                <div class="col-lg-<?php echo esc_attr( $ideabuz_footer_widget_col_val.$ideabuz_sidebar_two ); ?> col-sm-6">
		                    <?php
		                        dynamic_sidebar( 'footer_sidebar_two' );
		                    ?>
		                </div>
		                <?php
		                        endif;
		                    endif;
		
		                    if( $ideabuz_footer_widget_col != '1' ) :
		                        if( is_active_sidebar( 'footer_sidebar_three' ) ) :
		                ?>
		                <div class="col-lg-<?php echo esc_attr( $ideabuz_footer_widget_col_val.$ideabuz_sidebar_three ); ?> col-sm-6">
		                    <?php
		                        dynamic_sidebar( 'footer_sidebar_three' );
		                    ?>
		                </div>
		                <?php
		                        endif;
		                    endif;
		
		                    if( $ideabuz_footer_widget_col == '3' ) :
		                        if( is_active_sidebar( 'footer_sidebar_four' ) ):
		                ?>
		                <div class="col-lg-<?php echo esc_attr( $ideabuz_footer_widget_col_val.$ideabuz_sidebar_four ); ?> col-sm-6">
		                    <?php
		                        dynamic_sidebar( 'footer_sidebar_four' );
		                    ?>
		                </div>
		                <?php
		                    endif;
		                endif;
		                ?>
		            </div>
		        </div>
		    </div>
		    <!-- Footer Top End -->
		    <?php endif;
		}
	}