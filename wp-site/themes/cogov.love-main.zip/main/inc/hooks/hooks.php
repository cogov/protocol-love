<?php
	// Block direct access
	if( !defined( 'ABSPATH' ) ){
		exit( );
	}
	/**
	* @Packge 	   : ideabuz
	* @Version     : 1.0
	* @Author 	   : ThemeLooks
	* @Author URI  : https://www.themelooks.com/
	*
	*/  
	/**
	*
	* @ Ideabuz Preloader
	*
	*/
	add_action( 'ideabuz_preloader','ideabuz_preloader_cb' );
	
	/**
	*
	* @ Ideabuz Header
	*
	*/
	add_action( 'ideabuz_header','ideabuz_header_cb' );
	
	/**
	*
	* @ Ideabuz Blog Post Thumb
	*
	*/
	add_action( 'ideabuz_blog_posts_thumb','ideabuz_blog_posts_thumb_cb' );
	
	/**
	*
	* @ Blog, Single Post, Archive, Page Wrapper Start Hook 
	*
	*/
	add_action( 'ideabuz_blog_section_wrapper_start','ideabuz_blog_section_wrapper_start_cb' );
	
	/**
	*
	* @ Blog, Single Post, Archive, Page Wrapper End Hook 
	*
	*/
	add_action( 'ideabuz_blog_section_wrapper_end','ideabuz_blog_section_wrapper_end_cb' );
	
	/**
	*
	* @ Blog Column Divider Start Wrapper
	*
	*/
	add_action( 'ideabuz_blog_column_divider_start_wrapper','ideabuz_blog_column_divider_start_wrapper_cb' );
	
	
	/**
	*
	* @ Blog Details Column Divider Start Wrapper
	*
	*/
	add_action( 'ideabuz_blog_details_column_divider_start_wrapper','ideabuz_blog_details_column_divider_start_wrapper_cb' );
	
	/**
	*
	* @ Page Column Divider Start Wrapper
	*
	*/
	add_action( 'ideabuz_page_column_divider_start_wrapper','ideabuz_page_column_divider_start_wrapper_cb' );
	
	/**
	*
	* @ Service Details Column Divider Start Wrapper
	*
	*/
	add_action( 'ideabuz_service_details_column_divider_start_wrapper','ideabuz_service_details_column_divider_start_wrapper_cb' );
	
	/**
	*
	* @ Blog Sidebar
	*
	*/
	add_action( 'ideabuz_blog_sidebar_wrapper','ideabuz_blog_sidebar_wrapper_cb' );
	
	/**
	*
	* @ Blog Sidebar For Single Page
	*
	*/
	add_action( 'ideabuz_blog_single_sidebar_wrapper','ideabuz_blog_single_sidebar_wrapper_cb' );
	
	/**
	*
	* @ Page Sidebar
	*
	*/
	add_action( 'ideabuz_page_sidebar_wrapper','ideabuz_page_sidebar_wrapper_cb' );
	
	/**
	*
	* @ Service Details Sidebar
	*
	*/
	add_action( 'ideabuz_service_details_sidebar_wrapper','ideabuz_service_details_sidebar_wrapper_cb' );
	
	
	/**
	*
	* @ Blog Post Column
	*
	*/
	add_action( 'ideabuz_blog_post_column','ideabuz_blog_post_column_cb' );
	
	/**
	*
	* @ Double Div End Wrapper
	*
	*/
	add_action( 'ideabuz_double_div_end_wrapper','ideabuz_double_div_end_wrapper_cb' );
	
	/**
	*
	* @ Single Div End Wrapper
	*
	*/
	add_action( 'ideabuz_single_div_end_wrapper','ideabuz_single_div_end_wrapper_cb' );
	
	/**
	*
	* @ Ideabuz Blog Author Enable And Disable
	*
	*/
	add_action( 'ideabuz_blog_author_enable_disable','ideabuz_blog_author_enable_disable_cb' );
	
	
	/**
	*
	* @ Ideabuz Blog Comment Enable And Disable
	*
	*/
	add_action( 'ideabuz_blog_comment_enable_disable','ideabuz_blog_comment_enable_disable_cb' );
	
	/**
	*
	* @ Ideabuz Blog Post Excerpt Cb
	*
	*/
	add_action( 'ideabuz_blog_post_excerpt','ideabuz_blog_post_excerpt_cb' );
	
	
	/**
	*
	* @ Ideabuz Blog Read More Button
	*
	*/
	add_action( 'ideabuz_blog_read_more_button','ideabuz_blog_read_more_button_cb' );
	
	/**
	*
	* @ Ideabuz Blog Post Pagination
	*
	*/
	add_action( 'ideabuz_blog_post_pagination','ideabuz_blog_post_pagination_cb' );
	
	
	/**
	*
	* @ Ideabuz Singe Post Navigation
	*
	*/
	add_action( 'ideabuz_single_post_navigation','ideabuz_single_post_navigation_cb' );
	
	/**
	*
	* @ Ideabuz Blog Post Comment
	*
	*/
	add_action( 'ideabuz_single_post_comments_show_wrap','ideabuz_single_post_comments_show_wrap_cb' );
	
	/**
	*
	* @ Ideabuz Back To Top
	*
	*/
	add_action( 'ideabuz_back_to_top','ideabuz_back_to_top_cb' );
	
	/**
	*
	* @ Ideabuz Footer Bottom 
	*
	*/
	add_action( 'ideabuz_footer_bottom','ideabuz_footer_bottom_cb' );
	
	/**
	*
	* @ Ideabuz Footer Widget 
	*
	*/
	add_action( 'ideabuz_footer_widget','ideabuz_footer_widget_cb' );
	
	/**
	*
	* @ Ideabuz Page Wrapper Start
	*
	*/
	add_action( 'ideabuz_page_wrapper_start','ideabuz_page_wrapper_start_cb' );
	/**
	*
	* @ Ideabuz Page Wrapper End
	*
	*/
	add_action( 'ideabuz_page_wrapper_end','ideabuz_page_wrapper_end_cb' );