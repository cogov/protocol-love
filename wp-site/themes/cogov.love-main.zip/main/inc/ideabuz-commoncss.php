<?php
    // Block direct access
    if( !defined( 'ABSPATH' ) ){
        exit( );
    }
    /**
    * @Packge     : ideabuz
    * @Version    : 1.0
    * @Author     : ThemeLooks
    * @Author URI : https://www.themelooks.com/
    *
    */
    // enqueue css
    function ideabuz_common_custom_css(){
        wp_enqueue_style( 'ideabuz-color-schemes', esc_url( get_template_directory_uri() ).'/assets/css/color.schemes.css' );
    	$ideabuz_theme_color                = ideabuz_opt( 'ideabuz_unlimited_color' );
    	$ideabuz_css_editor                = ideabuz_opt( 'ideabuz_css_editor' );
    	$ideabuz_proloader_border_color     = ideabuz_opt( 'ideabuz_preloader_border_color' );
    	$ideabuz_offcanvas_background       = ideabuz_opt( 'ideabuz_offcanvas_background_color' );
    	$ideabuz_backtotop_icon_color       = ideabuz_opt( 'ideabuz_backtotop_icon_color' );
    	$ideabuz_footer_border_bottom       = ideabuz_opt( 'ideabuz_footer_border_bottom_color' );
    	$ideabuz_blog_hover_shape_from      = ideabuz_opt( 'ideabuz_blog_post_background_when_hover','from' );
    	$ideabuz_blog_hover_shape_to        = ideabuz_opt( 'ideabuz_blog_post_background_when_hover','to' );
    	$ideabuz_404_button_border_from     = ideabuz_opt( 'ideabuz_404_search_btn_border_color','from' );
    	$ideabuz_404_button_border_to       = ideabuz_opt( 'ideabuz_404_search_btn_border_color','to' );
    	$ideabuz_coming_soon_button_border_from     = ideabuz_opt( 'ideabuz_coming_soon_search_btn_border_color','from' );
    	$ideabuz_coming_soon_button_border_to       = ideabuz_opt( 'ideabuz_coming_soon_search_btn_border_color','to' );
    	$ideabuz_coming_soon_search_button_bg       = ideabuz_opt( 'ideabuz_coming_soon_search_btn_bg_color' );
    	$customcss = "";

    	// page header media settings
        if( get_header_image() ){
            $ideabuz_header_bg =  get_header_image();
        }else{
    	if( ideabuz_meta( 'global_style' ) == 'single' && is_page() ){
            // Page Settings
            if( !empty( ideabuz_meta( 'page_header_bg' ) ) ){
                $ideabuz_header_bg = ideabuz_meta( 'page_header_bg' );
            }
    		$pagehederbgcolor 		= ideabuz_meta( 'page_header_bg_color' );

            if( ideabuz_meta( 'page_header_bg_repeat' ) == 'norepeat' ){
                $pagehederbgrepeat = 'no-repeat';
            }elseif( ideabuz_meta( 'page_header_bg_repeat' ) == 'repeatall' ){
                $pagehederbgrepeat = 'repeat-all';
            }elseif( ideabuz_meta( 'page_header_bg_repeat' ) == 'repeathor' ){
                $pagehederbgrepeat = 'repeat-x';
            }elseif( ideabuz_meta( 'page_header_bg_repeat' ) == 'repeatver' ){
                $pagehederbgrepeat = 'repeat-y';
            }elseif( ideabuz_meta( 'page_header_bg_repeat' ) == 'inherit' ){
                $pagehederbgrepeat = 'inherit';
            }else{
                $pagehederbgrepeat = '';
            }

            if( ideabuz_meta( 'page_header_bg_size' ) == 'inherit' ){
                $pagehederbgsize = 'inherit';
            }elseif( ideabuz_meta( 'page_header_bg_size' ) == 'cover' ){
                $pagehederbgsize = 'cover';
            }elseif( ideabuz_meta( 'page_header_bg_size' ) == 'contain' ){
                $pagehederbgsize = 'contain';
            }else{
                $pagehederbgsize = '';
            }

            if( ideabuz_meta( 'page_header_bg_attachment' ) == 'fixed' ){
                $pagehederbgattachment = 'fixed';
            }elseif( ideabuz_meta( 'page_header_bg_attachment' ) == 'scroll' ){
                $pagehederbgattachment = 'scroll';
            }elseif( ideabuz_meta( 'page_header_bg_attachment' ) == 'inherit' ){
                $pagehederbgattachment = 'inherit';
            }else{
                $pagehederbgattachment = '';
            }

    		$pagehederbgposition 	= ideabuz_meta( 'page_header_bg_position' );

            if( ideabuz_meta( 'page_header_bg_position' ) == 'lefttop' ){
                $pagehederbgposition = 'left top';
            }elseif( ideabuz_meta( 'page_header_bg_position' ) == 'leftcenter' ){
                $pagehederbgposition = 'left center';
            }elseif( ideabuz_meta( 'page_header_bg_position' ) == 'leftbottom' ){
                $pagehederbgposition = 'left bottom';
            }elseif( ideabuz_meta( 'page_header_bg_position' ) == 'centertop' ){
                $pagehederbgposition = 'center top';
            }elseif( ideabuz_meta( 'page_header_bg_position' ) == 'centercenter' ){
                $pagehederbgposition = 'center center';
            }elseif( ideabuz_meta( 'page_header_bg_position' ) == 'centerbottom' ){
                $pagehederbgposition = 'center bottom';
            }elseif( ideabuz_meta( 'page_header_bg_position' ) == 'righttop' ){
                $pagehederbgposition = 'right top';
            }elseif( ideabuz_meta( 'page_header_bg_position' ) == 'rightcenter' ){
                $pagehederbgposition = 'right center';
            }elseif( ideabuz_meta( 'page_header_bg_position' ) == 'rightbottom' ){
                $pagehederbgposition = 'right bottom';
            }else{
                $pagehederbgposition = '';
            }

    		$pagehedertextcolor 	= ideabuz_meta( 'page_header_text_color' );
    		$pagehederbreadcolor 	= ideabuz_meta( 'breadcrumb_link_color' );
    		$pagehederbreadcolorhov = ideabuz_meta( 'breadcrumb_link_hover_color' );
    		$pagehederbreadcoloract = ideabuz_meta( 'breadcrumb_active_color' );
    		$pagehederbreadcolordiv = ideabuz_meta( 'breadcrumb_divider_color' );
    	}else{
            // Global Settings
            $ideabuz_header_bg      = ideabuz_opt( 'ideabuz_header_bg','background-image' );
    		$pagehederbgcolor 		= ideabuz_opt( 'ideabuz_header_bg','background-color' );
            $pagehederbgrepeat 		= ideabuz_opt( 'page_header_bg_repeat','background-repeat' );
    		$pagehederbgsize 		= ideabuz_opt( 'page_header_bg_size','background-size' );
    		$pagehederbgattachment 	= ideabuz_opt( 'page_header_bg_attachment','background-attachment' );
    		$pagehederbgposition 	= ideabuz_opt( 'page_header_bg_position','background-position' );
    		$pagehedertextcolor 	= ideabuz_opt( 'ideabuz_header_text_color' );
    		$pagehederbreadcolor 	= ideabuz_opt( 'ideabuz_link_color' );
    		$pagehederbreadcolorhov	= ideabuz_opt( 'ideabuz_link_hover_color' );
    		$pagehederbreadcoloract	= ideabuz_opt( 'ideabuz_active_color' );
    		$pagehederbreadcolordiv	= ideabuz_opt( 'ideabuz_divider_color' );
        }
    	}

		if( !empty( $ideabuz_header_bg ) ){
    		$customcss .= ".page-title-bg{
	        	background-image:url('{$ideabuz_header_bg}');
        	}";
    	}
		if( !empty( $pagehederbgcolor ) ){
    		$customcss .= ".page-title-bg{
	        	background-color:{$pagehederbgcolor};
        	}";
    	}
		if( !empty( $pagehederbgrepeat ) ){
    		$customcss .= ".page-title-bg{
	        	background-repeat:{$pagehederbgrepeat};
        	}";
    	}
		if( !empty( $pagehederbgsize ) ){
    		$customcss .= ".page-title-bg{
	        	background-size:{$pagehederbgsize};
        	}";
    	}
		if( !empty( $pagehederbgattachment ) ){
    		$customcss .= ".page-title-bg{
	        	background-attachment:{$pagehederbgattachment};
        	}";
    	}
		if( !empty( $pagehederbgposition ) ){
    		$customcss .= ".page-title-bg{
	        	background-position:{$pagehederbgposition};
        	}";
    	}
		if( !empty( $pagehedertextcolor ) ){
    		$customcss .= ".page-title-bg .page-title h2{
	        	color:{$pagehedertextcolor};
        	}";
    	}
		if( !empty( $pagehederbreadcolor ) ){
    		$customcss .= ".page-title  .list-inline #breadcrumb a{
				color:{$pagehederbreadcolor};
			}";
    	}
		if( !empty( $pagehederbreadcolorhov ) ){
    		$customcss .= ".page-title  .list-inline #breadcrumb a:hover{
				color:{$pagehederbreadcolorhov};
			}";
    	}
		if( !empty( $pagehederbreadcoloract ) ){
    		$customcss .= ".page-title  .list-inline li.active{
				color:{$pagehederbreadcoloract};
			}";
    	}
		if( !empty( $pagehederbreadcolordiv ) ){
    		$customcss .= ".page-title li:not(:last-child):after{
				color:{$pagehederbreadcolordiv};
			}";
    	}
		if( !empty( $ideabuz_proloader_border_color ) ){
    		$customcss .= ".preloader .loader:before{
				border:1px solid {$ideabuz_proloader_border_color};
			}";
    	}
		if( !empty( $ideabuz_offcanvas_background ) ){
    		$customcss .= ".offcanvas-wrapper{
				background-color:{$ideabuz_offcanvas_background}!important;
			}";
    	}
		if( !empty( $ideabuz_backtotop_icon_color ) ){
    		$customcss .= ".back-to-top .top-arrow{
				border-bottom:2px solid {$ideabuz_backtotop_icon_color};
				border-left:2px solid {$ideabuz_backtotop_icon_color};
			}";
    		$customcss .= ".back-to-top .top-line{
				background-color:{$ideabuz_backtotop_icon_color};
			}";
    	}
        if( !empty( $ideabuz_footer_border_bottom ) ){
    		$customcss .= ".footer-top .border-bottom{
				border-bottom:1px solid {$ideabuz_footer_border_bottom} !important;
			}";
    	}
        if( !empty( $ideabuz_blog_hover_shape_from ) || !empty( $ideabuz_blog_hover_shape_to ) ){
    		$customcss .= ".single-blog-item .bg-overlay:after{
				background:linear-gradient(45deg, {$ideabuz_blog_hover_shape_from} 0%, {$ideabuz_blog_hover_shape_to} 100%) !important;
			}";
    	}
        if( !empty( $ideabuz_404_button_border_from ) || !empty( $ideabuz_404_button_border_to ) ){
    		$customcss .= ".not-found-form form button.btn:hover:before,
            .not-found-form form button.btn:before,
            .not-found-form form button.btn:hover:after,
            .not-found-form form button.btn:after,
            .not-found-form form button:hover span:before,
            .not-found-form form button span:before,
            .not-found-form form button:hover span:after,
            .not-found-form form button span:after{
				background:linear-gradient(45deg, {$ideabuz_404_button_border_from} 0%, {$ideabuz_404_button_border_to} 100%) !important;
			}";
    	}
        if( !empty( $ideabuz_coming_soon_search_button_bg ) ){
    		$customcss .= ".coming-soon-content .coming-soon-form form button.btn{
				background-color:{$ideabuz_coming_soon_search_button_bg} !important;
			}";
    	}
        if( !empty( $ideabuz_coming_soon_button_border_from ) || !empty( $ideabuz_coming_soon_button_border_to ) ){
    		$customcss .= ".coming-soon-content .coming-soon-form form button.btn:hover:before,
            .coming-soon-content .coming-soon-form form button.btn:before,
            .coming-soon-content .coming-soon-form form button.btn:hover:after,
            .coming-soon-content .coming-soon-form form button.btn:after,
            .coming-soon-content .coming-soon-form form button:hover span:before,
            .coming-soon-content .coming-soon-form form button span:before,
            .coming-soon-content .coming-soon-form form button:hover span:after,
            .coming-soon-content .coming-soon-form form button span:after{
				background:linear-gradient(45deg, {$ideabuz_coming_soon_button_border_from} 0%, {$ideabuz_coming_soon_button_border_to} 100%) !important;
			}";
    	}

        // Page Menu Color Setting
        $ideabuz_page_logo_color                            = ideabuz_meta( 'page_logo_title_color' );
        $ideabuz_page_logo_color_hover                      = ideabuz_meta( 'page_logo_title_color_hover' );
        $ideabuz_header_menu_color                          = ideabuz_meta( 'header_menu_color' );
        $ideabuz_header_menu_active_color                   = ideabuz_meta( 'header_menu_active_color' );
        $ideabuz_header_menu_hover_color                    = ideabuz_meta( 'header_menu_hover_color' );
        $ideabuz_header_sub_menu_background_color           = ideabuz_meta( 'header_sub_menu_background_color' );
        $ideabuz_header_sub_menu_text_color                 = ideabuz_meta( 'header_sub_menu_text_color' );
        $ideabuz_header_sub_menu_hover_text_color           = ideabuz_meta( 'header_sub_menu_hover_text_color' );
        $ideabuz_header_sticky_background                   = ideabuz_meta( 'header_sticky_background' );
        $ideabuz_header_sticky_menu_color                   = ideabuz_meta( 'header_sticky_menu_color' );
        $ideabuz_header_sticky_menu_active_color            = ideabuz_meta( 'header_sticky_menu_active_color' );
        $ideabuz_header_sticky_menu_hover_color             = ideabuz_meta( 'header_sticky_menu_hover_color' );
        $ideabuz_header_sticky_submenu_background           = ideabuz_meta( 'header_sticky_submenu_background' );
        $ideabuz_header_sticky_submenu_textcolor            = ideabuz_meta( 'header_sticky_submenu_textcolor' );
        $ideabuz_header_sticky_submenu_hover_textcolor      = ideabuz_meta( 'header_sticky_submenu_hover_textcolor' );
        $ideabuz_header_menu_active_opacity                 = ideabuz_meta( 'header_menu_active_opacity' );
        $ideabuz_header_menu_hover_opacity                  = ideabuz_meta( 'header_menu_hover_opacity' );
        $ideabuz_header_offcanvas_icon                      = ideabuz_meta( 'header_offcanvas_icon' );
        $ideabuz_header_offcanvas_icon_sticky               = ideabuz_meta( 'header_offcanvas_icon_sticky' );


        if( !empty( $ideabuz_page_logo_color ) ){
            $customcss .= ".header .logo h2 a.text-logo{
				color:{$ideabuz_page_logo_color} !important;
			}";
        }
        if( !empty( $ideabuz_page_logo_color_hover ) ){
            $customcss .= ".header .logo h2 a:hover{
				color:{$ideabuz_page_logo_color_hover} !important;
			}";
        }
        if( !is_search() ){
            if( !empty( $ideabuz_header_menu_color ) ){
                $customcss .= ".header .header-main .main-menu .nav li a{
    				color:{$ideabuz_header_menu_color} !important;
    			}";
            }
        }
        if( !is_search() ){
            if( !empty( $ideabuz_header_menu_active_color ) ){
                $customcss .= ".header .header-main.style--one .main-menu .nav li.current-menu-item > a{
    				color:{$ideabuz_header_menu_active_color} !important;
    			}";
            }
        }
        if( !is_search() ){
            if( !empty( $ideabuz_header_menu_hover_color ) ){
                $customcss .= ".header .header-main .main-menu .nav li a:hover{
    				color:{$ideabuz_header_menu_hover_color} !important;
    			}";
            }
        }
        if( !is_search() ){
            if( !empty( $ideabuz_header_sub_menu_background_color ) ){
                $customcss .= ".header .header-main.style--one .main-menu .nav li ul{
    				background-color:{$ideabuz_header_sub_menu_background_color} !important;
    			}";
            }
        }
        if( !is_search() ){
            if( !empty( $ideabuz_header_sub_menu_text_color ) ){
                $customcss .= ".header .header-main.style--one .main-menu .nav li ul li a{
    				color:{$ideabuz_header_sub_menu_text_color} !important;
    			}";
            }
        }
        if( !is_search() ){
            if( !empty( $ideabuz_header_sub_menu_hover_text_color ) ){
                $customcss .= ".header .header-main.style--one .main-menu .nav li ul li a:hover{
    				color:{$ideabuz_header_sub_menu_hover_text_color} !important;
    			}";
            }
        }
        if( !is_search() ){
            if( !empty( $ideabuz_header_sticky_background ) ){
                $customcss .= ".header .header-main.sticky{
    				background-color:{$ideabuz_header_sticky_background} !important;
    			}";
            }
        }
        if( !is_search() ){
            if( !empty( $ideabuz_header_sticky_menu_color ) ){
                $customcss .= ".header .header-main.sticky .main-menu .nav > li > a{
    				color:{$ideabuz_header_sticky_menu_color} !important;
    			}";
            }
        }
        if( !is_search() ){
            if( !empty( $ideabuz_header_sticky_menu_active_color ) ){
                $customcss .= ".header .header-main.sticky .main-menu .nav li.current-menu-item > a,
                .header .header-main.sticky .main-menu .nav li.current-menu-parent > a,
                .header .header-main.sticky .main-menu .nav li.current-menu-ancestor > a{
    				color:{$ideabuz_header_sticky_menu_active_color} !important;
    			}";
            }
        }
        if( !is_search() ){
            if( !empty( $ideabuz_header_sticky_menu_hover_color ) ){
                $customcss .= ".header .header-main.sticky .main-menu .nav li a:hover{
    				color:{$ideabuz_header_sticky_menu_hover_color} !important;
    			}";
            }
        }
        if( !is_search() ){
            if( !empty( $ideabuz_header_sticky_submenu_background ) ){
                $customcss .= ".header .header-main.sticky .main-menu .nav li ul{
    				background-color:{$ideabuz_header_sticky_submenu_background} !important;
    			}";
            }
        }
        if( !is_search() ){
            if( !empty( $ideabuz_header_sticky_submenu_textcolor ) ){
                $customcss .= ".header .header-main.sticky .main-menu .nav li ul li a{
    				color:{$ideabuz_header_sticky_submenu_textcolor} !important;
    			}";
            }
        }
        if( !is_search() ){
            if( !empty( $ideabuz_header_sticky_submenu_hover_textcolor ) ){
                $customcss .= ".header .header-main.sticky .main-menu .nav li ul li a:hover{
    				color:{$ideabuz_header_sticky_submenu_hover_textcolor} !important;
    			}";
            }
        }
        if( !is_search() ){
            if( !empty( $ideabuz_header_menu_active_opacity ) ){
                $customcss .= ".header .header-main.style--one .main-menu .nav li.current-menu-item > a,
                .header .header-main.style--one .main-menu .nav li.current-menu-parent > a,
                .header .header-main.style--one .main-menu .nav li.current-menu-ancestor > a{
    				opacity:{$ideabuz_header_menu_active_opacity} !important;
    			}";
            }
        }
        if( !is_search() ){
            if( !empty( $ideabuz_header_menu_hover_opacity ) ){
                $customcss .= ".header .header-main .main-menu .nav li a:hover{
    				opacity:{$ideabuz_header_menu_active_opacity} !important;
    			}";
            }
        }
        if( !is_search() ){
            if( !empty( $ideabuz_header_offcanvas_icon ) ){
                $customcss .= ".offcanvas-trigger span{
    				background-color:{$ideabuz_header_offcanvas_icon} !important;
    			}";
            }
        }
        if( !is_search() ){
            if( !empty( $ideabuz_header_offcanvas_icon_sticky ) ){
                $customcss .= ".sticky .offcanvas-trigger span{
    				background-color:{$ideabuz_header_offcanvas_icon_sticky} !important;
    			}";
            }
        }

        // Theme Color

        if( !empty( $ideabuz_theme_color ) ){
            $customcss .= ".c1,
            .btn,
            .list-check li i,
            .theme-input-group button,
            .btn.btn-white span,
            .vdo-btn,
            .section-title h3,
            .page-title li,
            .appointment-modal
            .modal-dialog .modal-content .form-title,
            .header .header-main.style--one .main-menu #menu-button,
            .header .header-main.style--one .main-menu .nav li.current-menu-item > a,
            .header .header-main.style--one .main-menu .nav li.current-menu-parent > a,
            .header .header-main.style--one .main-menu .nav li ul li a:hover,
            .offcanvas-wrapper .offcanvas-content .widget.widget_contact_info .single-info span,
            .single-blog-style--two .blog-content .post-meta li a:hover,
            .blog-details .post-meta li a:hover, .blog-details .post-tags li a:hover,
            .not-found-content p a,
            .coming-soon-content h1,
            #countdown li .single-countdown h4,
            #countdown li.seperator,
            .single-feature:hover .content h3,
            .single-process:hover .content h3,
            .about-nav-tab .nav-tabs .nav-link.active,
            .single-service .icon, .single-service:hover h4,
            .service-details .title,
            .pricing-navtab .nav-tabs .nav-link h4,
            .project-nav li.active,
            .single-team-member .team-info h4{
				color:{$ideabuz_theme_color} !important;
			}";
        }

        // Background Color

        if( !empty( $ideabuz_theme_color ) ){
            $customcss .= ".c1-bg,
            ::selection,
            .bg-overlay:after,
            .btn-inline:hover:after,
            #menu-button.menu-opened span::before,
            #menu-button.menu-opened span::after,
            -thumb.offcanvas-wrapper::-webkit-scrollbar,
            .single-blog-item .blog-hover{
				background-color:{$ideabuz_theme_color} !important;
			}";
        }
        if( !empty( $ideabuz_theme_color ) ){
            $customcss .= ".btn:before,
            .btn:after,
            .btn span:before,
            .btn span:after{
                background:linear-gradient( 45deg, {$ideabuz_theme_color} 0%,{$ideabuz_theme_color} 100% ) !important;
            }";
        }
        // Border Color

        if( !empty( $ideabuz_theme_color ) ){
            $customcss .= ".c1-bo,
            .owl-carousel .owl-nav button:before,
            .pagination li a:hover, .pagination li a.active,
            .pagination li span:hover,
            .pagination li span.current,
            blockquote,
            .widget.widget_tag_cloud
            .tagcloud a:hover,
            .about-nav-tab .nav-tabs .nav-link.active{
				border-color:{$ideabuz_theme_color} !important;
			}";
        }
        if( ideabuz_meta( 'responsive_menu_style' ) == 'single' ){
            // Mobile Responsive
            $menu_button_color                        = ideabuz_meta( 'menu_button_color' );
            $cross_button_color                       = ideabuz_meta( 'cross_button_color' );
            $menu_bg_color                            = ideabuz_meta( 'menu_background_color' );
            $menu_text_color                          = ideabuz_meta( 'menu_text_color' );
            $menu_text_color_on_hover                 = ideabuz_meta( 'menu_text_color_on_hover' );
            $right_side_icon_color                    = ideabuz_meta( 'right_side_icon_color' );
            $submenu_background_color                 = ideabuz_meta( 'submenu_background_color' );
            $submenu_text_color                       = ideabuz_meta( 'submenu_text_color' );
            $submenu_text_color_on_hover              = ideabuz_meta( 'submenu_text_color_on_hover' );
            $sticky_menu_background_color             = ideabuz_meta( 'sticky_menu_background_color' );
            $sticky_menu_button_color                 = ideabuz_meta( 'sticky_menu_button_color' );
            $sticky_menu_cross_button_color           = ideabuz_meta( 'sticky_menu_cross_button_color' );
            $sticky_menu_bg_color                     = ideabuz_meta( 'sticky_menu_background_color_two' );
            $sticky_menu_text_color                   = ideabuz_meta( 'sticky_menu_text_color' );
            $sticky_menu_text_color_on_hover          = ideabuz_meta( 'sticky_menu_text_color_on_hover' );
            $sticky_right_side_icon_color             = ideabuz_meta( 'sticky_right_side_icon_color' );
            $sticky_submenu_background_color          = ideabuz_meta( 'sticky_submenu_background_color' );
            $sticky_submenu_text_color                = ideabuz_meta( 'sticky_submenu_text_color' );
            $sticky_submenu_text_color_on_hover       = ideabuz_meta( 'sticky_submenu_text_color_on_hover' );
        }else{
            // Mobile Responsive
            $menu_button_color                        = ideabuz_opt( 'menu_button_color' );
            $cross_button_color                       = ideabuz_opt( 'cross_button_color' );
            $menu_bg_color                            = ideabuz_opt( 'menu_background_color' );
            $menu_text_color                          = ideabuz_opt( 'menu_text_color' );
            $menu_text_color_on_hover                 = ideabuz_opt( 'menu_text_color_on_hover' );
            $right_side_icon_color                    = ideabuz_opt( 'right_side_icon_color' );
            $submenu_background_color                 = ideabuz_opt( 'submenu_background_color' );
            $submenu_text_color                       = ideabuz_opt( 'submenu_text_color' );
            $submenu_text_color_on_hover              = ideabuz_opt( 'submenu_text_color_on_hover' );
            $sticky_menu_background_color             = ideabuz_opt( 'sticky_menu_background_color' );
            $sticky_menu_button_color                 = ideabuz_opt( 'sticky_menu_button_color' );
            $sticky_menu_cross_button_color           = ideabuz_opt( 'sticky_menu_cross_button_color' );
            $sticky_menu_bg_color                     = ideabuz_opt( 'sticky_menu_background_color_two' );
            $sticky_menu_text_color                   = ideabuz_opt( 'sticky_menu_text_color' );
            $sticky_menu_text_color_on_hover          = ideabuz_opt( 'sticky_menu_text_color_on_hover' );
            $sticky_right_side_icon_color             = ideabuz_opt( 'sticky_right_side_icon_color' );
            $sticky_submenu_background_color          = ideabuz_opt( 'sticky_submenu_background_color' );
            $sticky_submenu_text_color                = ideabuz_opt( 'sticky_submenu_text_color' );
            $sticky_submenu_text_color_on_hover       = ideabuz_opt( 'sticky_submenu_text_color_on_hover' );
        }

        if( !empty( $menu_button_color ) ){
            $customcss .= "
            @media only screen and (max-width: 991px) {
                .header .header-main.style--one .main-menu #menu-button span,
                .header .header-main.style--one .main-menu #menu-button span:before,
                .header .header-main.style--one .main-menu #menu-button span:after{
                    background-color:{$menu_button_color};
                }
            }";
        }
        if( !empty( $cross_button_color ) ){
            $customcss .= "
            @media only screen and (max-width: 991px) {
                .header .header-main.style--one .main-menu #menu-button.menu-opened span:before,
                .header .header-main.style--one .main-menu #menu-button.menu-opened span:after{
                    background-color:{$cross_button_color}!important;
                }
            }";
        }
        if( !empty( $menu_bg_color ) ){
            $customcss .= "
            @media only screen and (max-width: 991px) {
                .header .header-main.style--one .main-menu ul.nav{
                    background-color:{$menu_bg_color}!important;
                }
            }";
        }
        if( !empty( $menu_text_color ) ){
            $customcss .= "
            @media only screen and (max-width: 991px) {
                .header .header-main.style--one .main-menu ul li a{
                    color:{$menu_text_color}!important;
                }
            }";
        }
        if( !empty( $menu_text_color_on_hover ) ){
            $customcss .= "
            @media only screen and (max-width: 991px) {
                .header .header-main.style--one .main-menu ul li a:hover{
                    color:{$menu_text_color_on_hover}!important;
                }
            }";
        }
        if( !empty( $right_side_icon_color ) ){
            $customcss .= "
            @media only screen and (max-width: 991px) {
                .header .header-main.style--one .main-menu .submenu-button:before{
                    color:{$right_side_icon_color}!important;
                }
            }";
        }
        if( !empty( $submenu_background_color ) ){
            $customcss .= "
            @media only screen and (max-width: 991px) {
                .header .header-main.style--one .main-menu .nav li ul li a{
                    background-color:{$submenu_background_color}!important;
                }
            }";
        }
        if( !empty( $submenu_text_color ) ){
            $customcss .= "
            @media only screen and (max-width: 991px) {
                .header .header-main.style--one .main-menu .nav li ul li a{
                    color:{$submenu_text_color}!important;
                }
            }";
        }
        if( !empty( $submenu_text_color_on_hover ) ){
            $customcss .= "
            @media only screen and (max-width: 991px) {
                .header .header-main.style--one .main-menu .nav li ul li a:hover{
                    color:{$submenu_text_color_on_hover}!important;
                }
            }";
        }
        if( !empty( $sticky_menu_background_color ) ){
            $customcss .= "
            @media only screen and (max-width: 991px) {
                .header .header-main.style--one.sticky{
                    background-color:{$sticky_menu_background_color}!important;
                }
            }";
        }
        if( !empty( $sticky_menu_button_color ) ){
            $customcss .= "
            @media only screen and (max-width: 991px) {
                .header .header-main.style--one.sticky .main-menu #menu-button span,
                .header .header-main.style--one.sticky .main-menu #menu-button span:before,
                .header .header-main.style--one.sticky .main-menu #menu-button span:after{
                    background-color:{$sticky_menu_button_color};
                }
            }";
        }
        if( !empty( $sticky_menu_cross_button_color ) ){
            $customcss .= "
            @media only screen and (max-width: 991px) {
                .header .header-main.style--one.sticky .main-menu #menu-button.menu-opened span:before,
                .header .header-main.style--one.sticky .main-menu #menu-button.menu-opened span:after{
                    background-color:{$sticky_menu_cross_button_color}!important;
                }
            }";
        }
        if( !empty( $sticky_menu_bg_color ) ){
            $customcss .= "
            @media only screen and (max-width: 991px) {
                .header .header-main.style--one.sticky .main-menu ul.nav{
                    background-color:{$sticky_menu_bg_color}!important;
                }
            }";
        }
        if( !empty( $sticky_menu_text_color ) ){
            $customcss .= "
            @media only screen and (max-width: 991px) {
                .header .header-main.style--one.sticky .main-menu ul li a{
                    color:{$sticky_menu_text_color}!important;
                }
            }";
        }
        if( !empty( $sticky_menu_text_color_on_hover ) ){
            $customcss .= "
            @media only screen and (max-width: 991px) {
                .header .header-main.style--one.sticky .main-menu ul li a:hover{
                    color:{sticky_$menu_text_color_on_hover}!important;
                }
            }";
        }
        if( !empty( $sticky_right_side_icon_color ) ){
            $customcss .= "
            @media only screen and (max-width: 991px) {
                .header .header-main.style--one.sticky .main-menu .submenu-button:before{
                    color:{$sticky_right_side_icon_color}!important;
                }
            }";
        }
        if( !empty( $sticky_submenu_background_color ) ){
            $customcss .= "
            @media only screen and (max-width: 991px) {
                .header .header-main.style--one.sticky .main-menu .nav li ul li a{
                    background-color:{$sticky_submenu_background_color}!important;
                }
            }";
        }
        if( !empty( $sticky_submenu_text_color ) ){
            $customcss .= "
            @media only screen and (max-width: 991px) {
                .header .header-main.style--one.sticky .main-menu .nav li ul li a{
                    color:{$sticky_submenu_text_color}!important;
                }
            }";
        }
        if( !empty( $sticky_submenu_text_color_on_hover ) ){
            $customcss .= "
            @media only screen and (max-width: 991px) {
                .header .header-main.style--one.sticky .main-menu .nav li ul li a:hover{
                    color:{$sticky_submenu_text_color_on_hover}!important;
                }
            }";
        }

        if( !empty( $ideabuz_css_editor ) ){
            $customcss .= $ideabuz_css_editor;
        }
        wp_add_inline_style( 'ideabuz-color-schemes', $customcss );

    }
    add_action( 'wp_enqueue_scripts', 'ideabuz_common_custom_css', 50 );