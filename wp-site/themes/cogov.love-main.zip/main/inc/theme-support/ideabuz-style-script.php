<?php
	/**
	* ideabuz functions and definitions
	*
	* @link https://developer.wordpress.org/themes/basics/theme-functions/
	*
	* @package ideabuz
	*/

	if ( ! function_exists( 'ideabuz_setup' ) ) :

		function ideabuz_setup() {
			// text domain for translation.
			load_theme_textdomain( 'ideabuz', IDEABUZ_DIR_PATH . '/languages' );

			// support title tage
			add_theme_support( 'title-tag' );

			// support logo
			add_theme_support( 'custom-logo' );
			
			//  support post format
			add_theme_support( 'post-formats', array( 'video','audio', ) );
			
			// support post-thumbnails
			add_theme_support( 'post-thumbnails' );

			// support custom background
			add_theme_support( 'custom-background' );

			// support custom header
			add_theme_support( 'custom-header' );

			// support automatic feed links
			add_theme_support( 'automatic-feed-links' );

			// support widget refersh
			add_theme_support( 'customize-selective-refresh-widgets' );

			// support html5
			add_theme_support( 'html5' );
			
			// Image 
			add_theme_support( 'align-wide' );
			
			// support woocommerce 
			add_theme_support( 'woocommerce' );
			add_theme_support( 'wc-product-gallery-zoom' );
			add_theme_support( 'wc-product-gallery-lightbox' );
			add_theme_support( 'wc-product-gallery-slider' );

			// register nav menu
			register_nav_menus( array(
				'primary-menu'   => esc_html__( 'Primary Menu', 'ideabuz' ),
			) );

			// editor style
			add_editor_style( 'css/editor-style.css' );
		}
		/**
		* Register Google fonts for ideabuz.
		*
		* Create your own ideabuz_fonts_url() function to override in a child theme.
		*
		* @since ideabuz 1.0
		*
		* @return string Google fonts URL for the theme.
		*/
		function ideabuz_fonts_url() {
			$fonts_url = '';
			$fonts     = array();
			$subsets   = 'latin,latin-ext';

			if ( 'off' !== _x( 'on', 'Muli font: on or off', 'ideabuz' ) ) {
				$fonts[] = 'Muli:400,400i,500,700';
			}

			if ( 'off' !== _x( 'on', 'Rubik font: on or off', 'ideabuz' ) ) {
				$fonts[] = 'Rubik:400,400i,500,700';
			}

			if ( $fonts ) {
				$fonts_url = add_query_arg( array(
					'family' => urlencode( implode( '|', $fonts ) ),
					'subset' => urlencode( $subsets ),
				), 'https://fonts.googleapis.com/css' );
			}

			return $fonts_url;
		}
	endif;
	add_action( 'after_setup_theme', 'ideabuz_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function ideabuz_content_width() {
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters( 'ideabuz_content_width', 751 );
}
add_action( 'after_setup_theme', 'ideabuz_content_width', 0 );


/**
* Enqueue scripts and styles.
*/
function ideabuz_scripts() {

	$cssPath = IDEABUZ_CSS_DIR_URI;
	$jsPath  = IDEABUZ_JS_DIR_URI;
	$pluginPath  = IDEABUZ_PLUGINS_DIR_URI;

	wp_enqueue_style( 'ideabuz-fonts', ideabuz_fonts_url(), array(), null );
	
	wp_enqueue_style( 'bootstrap', $cssPath.'bootstrap.min.css',array(), '3.3.7' );
	
	wp_enqueue_style( 'font-awesome-all', $cssPath.'font-awesome.all.min.css',array(), '5.9.0' );
	
	wp_enqueue_style( 'font-awesome', $cssPath.'font-awesome.min.css',array(), '4.7' );
	
	wp_enqueue_style( 'owl-carousel', $pluginPath.'owlcarousel/owl.carousel.min.css',array(), '2.3.4' );
	
	wp_enqueue_style( 'magnific-popup', $pluginPath.'magnific-popup/magnific-popup.min.css',array(), '' );

	wp_enqueue_style( 'ideabuz-style', get_stylesheet_uri() );

    wp_enqueue_style( 'ideabuz-main-style', $cssPath.'style.css' );

	// ideabuz Script

	wp_enqueue_script( 'bootstrap-bundle', $jsPath.'bootstrap.bundle.min.js', array( 'jquery' ), '4.3.1', true );

	wp_enqueue_script( 'jquery-menu', $jsPath.'jquery.menu.min.js', array('jquery'),'', true );
	
	wp_enqueue_script( 'jquery-waypoints', $pluginPath.'waypoints/jquery.waypoints.min.js', array( 'jquery' ),'4.0.1', true );
	
	wp_enqueue_script( 'jquery-counterup', $pluginPath.'waypoints/jquery.counterup.min.js', array( 'jquery' ),'1.0', true );
	
	wp_enqueue_script( 'owl-carousel', $pluginPath.'owlcarousel/owl.carousel.min.js', array( 'jquery' ),'2.3.4', true );
	
	wp_enqueue_script( 'isotope-pkgd', $pluginPath.'isotope/isotope.pkgd.min.js', array( 'jquery' ),'3.0.5', true );
	
	wp_enqueue_script( 'imagesloaded-pkgd', $pluginPath.'isotope/imagesloaded.pkgd.min.js', array( 'jquery' ),'4.1.4', true );
	
	wp_enqueue_script( 'jquery-magnific-popup', $pluginPath.'magnific-popup/jquery.magnific-popup.min.js', array( 'jquery' ),'1.0.1', true );
	
	wp_enqueue_script( 'jquery-countdown', $pluginPath.'countdown/jquery.countdown.min.js', array( 'jquery' ),'1.0.1', true );

	wp_enqueue_script( 'ideabuz-main-script', $jsPath.'main.js', array('jquery'), '1.0', true );


	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'ideabuz_scripts' );