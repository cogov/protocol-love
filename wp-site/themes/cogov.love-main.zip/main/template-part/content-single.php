<?php
   // Block direct access
   if( !defined( 'ABSPATH' ) ){
       exit( );
   }
   /**
    * @Packge     : Ideabuz
    * @Version    : 1.0
    * @Author     : ThemeLooks
    * @Author URI : https://www.themelooks.com/
    *
    */
    echo '<div class="blog-details">';
    
    /**
    * @Blog Post Thumbnail
    *
    * @Hook ideabuz_blog_posts_thumb
    *
    * @Hooked ideabuz_blog_posts_thumb_cb
    */
    do_action( 'ideabuz_blog_posts_thumb' );
            
    echo '<div class="post-meta">';
        echo '<ul class="list-inline">';
            /**
            * @Blog Author 
            *
            * @Hook ideabuz_blog_author_enable_disable
            *
            * @Hooked ideabuz_blog_author_enable_disable_cb
            */
            do_action( 'ideabuz_blog_author_enable_disable' );
            
            if( class_exists( 'ReduxFramework' ) ){
                $ideabuz_single_post_date_enable = ideabuz_opt( 'ideabuz_single_post_time_enable' );
            }else{
                $ideabuz_single_post_date_enable = 'true';
            }
            if( $ideabuz_single_post_date_enable ){
                echo '<li>'.esc_html__( 'On:','ideabuz' ).' <a class="date-color" href="'.esc_url( ideabuz_blog_date_permalink() ).'">'.esc_html( get_the_time( 'd F, Y' ) ).'</a></li>';
            }
            
            if( class_exists( 'ReduxFramework' ) ){
                $ideabuz_single_post_date_enable = ideabuz_opt( 'ideabuz_single_enable_category' );
            }else{
                $ideabuz_single_post_date_enable = true;
            }
            if( $ideabuz_single_post_date_enable ){
                $ideabuz_single_page_category = get_the_category();
                if( is_array( $ideabuz_single_page_category ) && !empty( $ideabuz_single_page_category ) ){
                    if( count( $ideabuz_single_page_category ) < 2 ){
                        $ideabuz_category_text = 'Category: ';
                    }else{
                        $ideabuz_category_text = 'Categories: ';
                    }
                    echo '<li>'.esc_html( $ideabuz_category_text );
                    foreach ( $ideabuz_single_page_category as $key => $single_category ) {
                        echo ' <a href="'.esc_url( get_category_link( $single_category->term_id ) ).'">'.esc_html( $single_category->name ) .'</a>';
                    }
                    echo '</li>';
                }
            }
        echo '</ul>';
    echo '</div>';
        echo '<div class="blog-details-content">';
            wp_kses_post( the_content() );
            // Link Pages
            ideabuz_link_pages();
            
        echo '</div>';
        if( class_exists( 'ReduxFramework' ) && get_the_tags() ){
            $ideabuz_tag_enable = ideabuz_opt( 'ideabuz_single_tag_enable_disable' );
        }elseif( get_the_tags() ){
            $ideabuz_tag_enable = true;
        }else{
            $ideabuz_tag_enable = '';
        }
        // Social Column
        if( $ideabuz_tag_enable ){
            $ideabuz_column_class = 'col-md-6';
        }else{
            $ideabuz_column_class = 'col-md-12';
        }
        if( class_exists( 'ReduxFramework' ) ){
            $ideabuz_social_share = ideabuz_opt( 'ideabuz_single_social' );
        }else{
            $ideabuz_social_share = '';
        }
        
        // Tag Column
        if( $ideabuz_social_share ){
            $ideabuz_tag_column = 'col-md-6';
        }else{
            $ideabuz_tag_column = 'col-md-12';
        }
        if( $ideabuz_tag_enable || $ideabuz_social_share ):
            echo '<div class="row align-items-center mb-30">';
                if( $ideabuz_tag_enable ):
                    echo '<div class="'.esc_attr( $ideabuz_tag_column ).'">';
                        echo '<div class="post-tags mb-30">';
                            echo '<ul class="list-inline">';
                                if( get_the_tags() ){
                                    $ideabuz_tag_count = get_the_tags();
                                    if( count( $ideabuz_tag_count ) < 2 ){
                                        $ideabuz_tag_count_text = 'Tag: ';
                                    }else{
                                        $ideabuz_tag_count_text = 'Tags: ';
                                    }
                                    echo '<li>'.esc_html( $ideabuz_tag_count_text ).'</li>';
                                    echo '<li>';
                                    foreach ( $ideabuz_tag_count as $tag_value ) {
                                        echo ' <a href="'.esc_url( get_tag_link( $tag_value->term_id ) ).'">' . esc_html( $tag_value->name ) . '</a>' ;
                                    }
                                    echo ' </li>';
                                }
                            echo '</ul>';
                        echo '</div>';
                    echo '</div>';
                endif;
                if( $ideabuz_social_share ):
                    echo '<div class="'.esc_attr( $ideabuz_column_class ).'">';
                        echo '<div class="post-share text-lg-right mb-30">';
                            if( function_exists( 'ideabuz_social_sharing_buttons' ) ){
                                ideabuz_social_sharing_buttons();
                            }
                        echo '</div>';
                    echo '</div>';
                endif;
            echo '</div>';
        endif;

        /**
        * @Blog Single Post Navigation
        *
        * @Hook ideabuz_single_post_navigation
        *
        * @Hooked ideabuz_single_post_navigation_cb
        */
        do_action( 'ideabuz_single_post_navigation' );
        
        /**
        * @Blog Single Post Comment
        *
        * @Hook ideabuz_single_post_comments_show_wrap
        *
        * @Hooked ideabuz_single_post_comments_show_wrap_cb
        */
        do_action( 'ideabuz_single_post_comments_show_wrap' );
            
    echo '</div>';