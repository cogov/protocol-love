<?php
    // Block direct access
    if( !defined( 'ABSPATH' ) ){
        exit( );
    }
    /**
    * @Packge     : Ideabuz
    * @Version    : 1.0
    * @Author     : ThemeLooks
    * @Author URI : https://www.themelooks.com/
    *
    */
?>
<!-- Header Begin -->
<header class="header fixed-top">
    <!-- Header Style One Begin -->
    <div class="fixed-top header-main style--one">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-3 col-sm-4 col-8">
                    <!-- Logo Begin -->
                    <div class="logo">
                        <?php
                            $ideabuz_custom_logo_id = get_theme_mod( 'custom_logo' );
                            $ideabuz_logo = wp_get_attachment_image_src( $ideabuz_custom_logo_id , 'full' );
                            if( !empty( $ideabuz_logo[0] ) ){
                                echo ideabuz_img_tag(array(
                                    'url'   =>  esc_url( $ideabuz_logo[0] )
                                ));
                            }elseif( ideabuz_meta( 'global_menu_style' ) == 'single' && is_page() ){
                                echo ideabuz_single_page_logo();
                            }else{
                                echo ideabuz_theme_logo();
                            }
                        ?>
                    </div>
                    <!-- Logo End -->
                </div>

                <div class="col-lg-9 col-sm-8 col-4">
                    <!-- Main Menu Begin -->
                    <div class="main-menu d-flex align-items-center justify-content-end">
                        <?php
                            if( has_nav_menu( 'primary-menu' ) ){
                                wp_nav_menu(array(
                                    'theme_location'    => 'primary-menu',
                                    'container'         => '',
                                    'menu_class'        => 'nav align-items-center',
                                ));
                            }
                        ?>
                        <!-- Offcanvas Holder Trigger -->
                        <?php if( is_active_sidebar( 'ideabuz_offcanvas_sidebar' ) ):?>
                            <span class="offcanvas-trigger text-right d-none d-lg-block">
                                <span></span>
                                <span></span>
                                <span></span>
                            </span>
                        <?php endif;?>
                        <!-- Offcanvas Trigger End -->
                    </div>
                    <!-- Main Menu ENd -->
                </div>
            </div>
        </div>
    </div>
    <!-- Header Style One End -->
</header>
<!-- Header End -->