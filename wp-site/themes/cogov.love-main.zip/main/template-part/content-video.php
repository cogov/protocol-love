<?php
    // Block direct access
    if( !defined( 'ABSPATH' ) ){
      exit( );
    }
    /**
    * @Packge      : ideabuz
    * @Version     : 1.0
    * @Author      : ThemeLooks
    * @Author URI  : https://www.themelooks.com/
    *
    */
 
    /**
    * @Post Column
    *
    * @Hook ideabuz_blog_post_column
    *
    * @Hooked ideabuz_blog_post_column_cb
    */
    do_action( 'ideabuz_blog_post_column' );
    
    // Blog Style
    if( class_exists( 'ReduxFramework' ) ){
        $ideabuz_blog_style = ideabuz_opt( 'ideabuz_blog_style' );
    }else{
        $ideabuz_blog_style = '1';
    }

    if( $ideabuz_blog_style == '1' ):
        get_template_part( 'template-part/blog-style','one' );
    else:
        get_template_part( 'template-part/blog-style','two' );
    endif;
        
    /**
    * @Single Div
    *
    * @Hook ideabuz_single_div_end_wrapper
    *
    * @Hooked ideabuz_single_div_end_wrapper_cb
    */
    do_action( 'ideabuz_single_div_end_wrapper' );