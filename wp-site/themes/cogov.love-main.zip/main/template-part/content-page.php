<?php
// Block direct access
if( !defined( 'ABSPATH' ) ){
	exit( );
}
/**
 * @Packge     : Ideabuz
 * @Version    : 1.0
 * @Author     : ThemeLooks
 * @Author URI : https://www.themelooks.com/
 *
 */

?>
<div id="page-<?php the_ID(); ?>" <?php post_class( 'page-item' ); ?>>
	<?php 

	echo '<div class="page--content">';
		wp_kses_post( the_content() );

		// Link Pages
		ideabuz_link_pages();
		
	echo '</div>';
	// comment template.
	if ( comments_open() || get_comments_number() ) {
		comments_template();
	} 

echo '</div>';