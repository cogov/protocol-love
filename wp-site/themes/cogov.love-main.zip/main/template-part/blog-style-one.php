<?php
	// Do not allow directly accessing this file.
	if ( ! defined( 'ABSPATH' ) ) {
		exit( );
	}
	/**
	* @Packge    : ideabuz
	* @version   : 1.0
	* @Author    : ThemeLooks
	* @Author URI: https://www.themelooks.com/
	*/

	// Date Enable Disable
	if( class_exists( 'ReduxFramework' ) ){
		$ideabuz_date_enable = ideabuz_opt( 'ideabuz_date_enable' );
		if( $ideabuz_date_enable ){
			$ideabuz_date_enable = true;
		}else{
			$ideabuz_date_enable = false;
		}
	}else{
		$ideabuz_date_enable = true;
	}

	// Category Enable Disable
	if( class_exists( 'ReduxFramework' ) ){
		$ideabuz_category_enable = ideabuz_opt( 'ideabuz_category_enable' );
		if( $ideabuz_category_enable ){
			$ideabuz_category_enable = true;
		}else{
			$ideabuz_category_enable = false;
		}
	}else{
		$ideabuz_category_enable = true;
	}
?>
<div id="post-<?php the_ID(); ?>" <?php post_class( 'single-blog-item position-relative' ); ?>>
	<!-- Blog Bg Shape -->
	<?php if( $ideabuz_date_enable  == true ): ?>
	<div class="date-bg-shape position-absolute">
		<?php
			echo ideabuz_img_tag(array(
				'url'	=> esc_url( IDEABUZ_IMG_DIR_URI.'shapes/blog-date-shape.svg' ),
				'class'	=> esc_attr( 'svg' ),
			));
		?>
	</div>
	<?php endif;?>
	<!-- End Blog Bg Shape -->

	<!-- Blog Content Begin -->
	<div class="blog-content">
		<?php
			if( $ideabuz_date_enable == true ){
				echo '<p class="posted-on">'.esc_html( get_the_time( 'd M' ) ).'</p>';
			}
			if( $ideabuz_category_enable == true ){
				$ideabuz_post_category = get_the_category();
				if( !empty( $ideabuz_post_category ) && is_array( $ideabuz_post_category ) ){
					foreach ( $ideabuz_post_category as $key => $category ) {
						if( $key == '0' ){
							echo '<p class="category">'.esc_html( $category->name ).'</p>';
						}
					}
				}
			}

			if( get_the_title() ){
				echo '<h3 class="blog-title">'.wp_kses_post( get_the_title() ).'</h3>';
			}
			/**
			* @Post Column
			*
			* @Hook ideabuz_blog_post_excerpt
			*
			* @Hooked ideabuz_blog_post_excerpt_cb
			*/
			do_action( 'ideabuz_blog_post_excerpt' );
		?>
	</div>
	<!-- Blog Content End -->

	<!-- Blog Hover Begin -->
	<?php
		$ideabuz_backgroundImg = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full' );
	?>
	<div class="blog-hover text-center text-white position-absolute w-100 h-100 d-flex align-items-center justify-content-center bg-overlay bg-img" <?php if( !empty( $ideabuz_backgroundImg ) ){ echo ideabuz_data_bg_attr(  $ideabuz_backgroundImg[0] ); }?> >
		<?php
			echo '<h3 class="blog-title">';
				echo '<a href="'.esc_url( get_the_permalink() ).'">'.wp_kses_post( get_the_title() ).'</a>';
			echo '</h3>';
		?>
	</div>
	<!-- Blog Hover End -->

	<!-- Blog Button Begin -->
	<div class="blog-button position-absolute w-100 d-flex align-items-center justify-content-center bg-img">
		<?php
			echo ideabuz_img_tag(array(
				'url'	=> esc_url( IDEABUZ_IMG_DIR_URI.'shapes/blog-shape.svg'),
				'class'	=> esc_attr( 'svg' ),
			));
			/**
			* @Post Read More Button
			*
			* @Hook ideabuz_blog_read_more_button
			*
			* @Hooked ideabuz_blog_read_more_button_cb
			*/
			do_action( 'ideabuz_blog_read_more_button' );

		?>
	</div>
	<!-- Blog Button End -->
</div>