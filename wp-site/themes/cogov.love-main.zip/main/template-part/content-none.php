<?php
    /**
    * @Packge      : ideabuz
    * @Version    : 1.0
    * @Author      : ThemeLooks
    * @Author URI : https://www.themelooks.com/
    *
    */
    // Block direct access
    if( !defined( 'ABSPATH' ) ){
        exit( );
    }
?>

<div class="col-sm-12">
    <h1 class="nof-title">
        <?php
            esc_html_e( 'Nothing Found', 'ideabuz' );
        ?>
    </h1>

    <?php
        if ( is_home() && current_user_can( 'publish_posts' ) ) :
    ?>

        <p class="nof-desc">
            <?php
                echo sprintf( __( 'Ready to publish your first post? <a href="%1$s">Get started here</a>.', 'ideabuz' ), esc_url( admin_url( 'post-new.php' ) ) );
            ?>
        </p>

    <?php elseif ( is_search() ) : ?>

        <p class="nof-desc">
            <?php
                esc_html_e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'ideabuz' );
            ?>
        </p>
        <div class="row content-none-search">
            <div class="col-sm-12">
                <?php
                    get_search_form();
                ?>
            </div>
        </div>

    <?php else : ?>

        <p  class="nof-desc">
            <?php
                wp_kses_post( _e( 'It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.', 'ideabuz' ) );
            ?>
        </p>
        <?php
            get_search_form();
        ?>

    <?php endif; ?>
</div>