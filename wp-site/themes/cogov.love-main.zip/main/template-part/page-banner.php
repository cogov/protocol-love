<?php
    // Block direct access
    if( !defined( 'ABSPATH' ) ){
        exit( );
    }
    /**
    * @Packge     : ideabuz
    * @Version    : 1.0
    * @Author     : ThemeLooks
    * @Author URI : https://www.themelooks.com/
    *
    */

    $ideabuz_title_breadcrumb_align = "";

    if( ideabuz_meta( 'global_style' ) == 'single' && is_page() ){
        if( ideabuz_meta( 'content_align' ) == 'left' ){
            $ideabuz_title_breadcrumb_align = 'text-left';
        }elseif( ideabuz_meta( 'content_align' ) == 'center'  ){
            $ideabuz_title_breadcrumb_align = 'text-center';
        }else{
            $ideabuz_title_breadcrumb_align = 'text-right';
        }
    }elseif( class_exists( 'ReduxFramework' ) ){
        if( ideabuz_opt( 'ideabuz_header_content_alignment' ) == 'left' ){
            $ideabuz_title_breadcrumb_align = 'text-left';
        }elseif( ideabuz_opt( 'ideabuz_header_content_alignment' ) == 'center'  ){
            $ideabuz_title_breadcrumb_align = 'text-center';
        }else{
            $ideabuz_title_breadcrumb_align = 'text-right';
        }
    }else{
        $ideabuz_title_breadcrumb_align = 'text-center';
    }
    
    if( class_exists( 'ReduxFramework' ) ){
        $ideabuz_header_bg = '';
    }else{
        $ideabuz_header_bg = 'bg-light';
    }

?>

<!-- Page Title Begin -->
<section class="page-title-bg pt-250 pb-100 <?php echo esc_attr( $ideabuz_header_bg );?>">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="page-title <?php echo esc_attr( $ideabuz_title_breadcrumb_align );?>">
                    <?php
                        if( ideabuz_meta( 'global_style' ) == 'single' && is_page() ){
                            if( ideabuz_meta( 'page_header_show_hide' ) == '1' ){
                                echo ideabuz_page_banner_header();
                            }
                        }elseif( class_exists( 'ReduxFramework' ) ){
                            if( ideabuz_opt( 'ideabuz_header_text_show_hide' ) == true ){
                                echo ideabuz_page_banner_header();
                            }
                        }else{
                            echo ideabuz_page_banner_header();
                        }
                    ?>
                    <ul class="list-inline">
                        <?php
                            if( ideabuz_meta( 'global_style' ) == 'single' && is_page() ){
                                if( ideabuz_meta( 'breadcrumb_enable' ) == '1' ){
                                    echo ideabuz_breadcrumb();
                                }
                            }elseif( class_exists( 'ReduxFramework' ) ){
                                if( ideabuz_opt( 'ideabuz_enable_bread' ) == '1' ){
                                    echo ideabuz_breadcrumb();
                                }
                            }else{
                                echo ideabuz_breadcrumb();
                            }
                        ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Page Title End -->