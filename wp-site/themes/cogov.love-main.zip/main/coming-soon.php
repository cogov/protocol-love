<?php
	// Do not allow directly accessing this file.
	if ( ! defined( 'ABSPATH' ) ) {
		exit( );
	}
	/**
	* @Packge    : ideabuz
	* @version   : 1.0
	* @Author    : ThemeLooks
	* @Author URI: https://www.themelooks.com/
	*
	* template name: Coming Soon
	* 
	*/
	get_header();
	
	?>
	<!-- Coming Soon Begin -->
    <section class="min-vh-100 pt-5 pb-5 pb-lg-0 pt-lg-0 vw-100 d-flex align-items-center bg-coming-soon ovx-hidden">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <!-- Coming Soon Content Begin -->
                    <div class="coming-soon-content text-center">
                        <!-- Logo Begin -->
						<div class="logo">
							<?php
								echo ideabuz_coming_soon_logo();
							?>
						</div>
                        
                        <!-- Logo End -->
						<?php
							if( !empty( ideabuz_opt('ideabuz_coming_soon_title') ) ){
								echo '<h1>'.esc_html( ideabuz_opt('ideabuz_coming_soon_title') ).'</h1>';
							}
						?>
                        <!-- Countdown Begin -->
						<div class="countdown" data-countdown="<?php if( !empty( ideabuz_opt( 'ideabuz_coming_time' ) ) ){ echo esc_attr( ideabuz_opt( 'ideabuz_coming_time' ) );} ?>">
						
                        <ul class="d-flex align-items-center justify-content-around list-inline" id="countdown">
                            <li>
                                <div class="single-countdown">
                                    <h4 class="days_text"><?php echo esc_html__( 'Days','ideabuz' );?></h4>
                                    <h2 class="days"><?php echo esc_html__( '00','ideabuz' );?></h2>
                                </div>
                            </li>
                            <li class="seperator"><?php echo esc_html__( ':','ideabuz' );?></li>
                            <li>
                                <div class="single-countdown">
                                    <h4 class="hours_text"><?php echo esc_html__( 'Hours','ideabuz' );?></h4>
                                    <h2 class="hours"><?php echo esc_html__( '00','ideabuz' );?></h2>
                                </div>
                            </li>
                            <li class="seperator"><?php echo esc_html__( ':','ideabuz' );?></li>
                            <li>
                                <div class="single-countdown">
                                    <h4 class="minutes_text"><?php echo esc_html__( 'Minutes','ideabuz' );?></h4>
                                    <h2 class="minutes"><?php echo esc_html__( '00','ideabuz' );?></h2>
                                </div>
                            </li>
                            <li class="seperator"><?php echo esc_html__( ':','ideabuz' );?></li>
                            <li>
                                <div class="single-countdown">
                                    <h4 class="seconds_text"><?php echo esc_html__( 'Seconds','ideabuz' );?></h4>
                                    <h2 class="seconds"><?php echo esc_html__( '00','ideabuz' );?></h2>
                                </div>
                            </li>
                        </ul>
						</div>
                        <!-- Countdown End -->
						<?php
						 	if( !empty( ideabuz_opt( 'ideabuz_coming_soon_simple_title' ) ) ){
								echo '<h3>'.ideabuz_opt( 'ideabuz_coming_soon_simple_title' ).'</h3>';
							}
							
							get_search_form();
						?>
						<ul class="social_icon_list list-inline mt-40">
	                        <?php
							 	if( function_exists( 'ideabuz_social_icon' ) ){
									ideabuz_social_icon();
								}
							?>
						</ul>
                    </div>
                    <!-- Coming Soon Content End -->
                        
                </div>
            </div>
        </div>
    </section>
    <!-- End Coming Soon -->
	<?php wp_footer();?>
</body>
</html>