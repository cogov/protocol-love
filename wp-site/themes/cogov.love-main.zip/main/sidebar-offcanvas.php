<?php
	// Block direct access
	if( !defined( 'ABSPATH' ) ){
		exit( );
	}
	/**
	* @Packge 	   : ideabuz
	* @Version     : 1.0
	* @Author 	   : ThemeLooks
	* @Author URI  : https://www.themelooks.com/
	*
	*/

	if( !is_active_sidebar( 'ideabuz_offcanvas_sidebar' ) ){
		return;
	}
?>
<!-- Offcanvas Begin -->
<div class="offcanvas-overlay fixed-top w-100 h-100"></div>
<div class="offcanvas-wrapper bg-white fixed-top h-100">
	<!-- Offcanvas Close Button Begin -->
	<div class="offcanvas-close position-absolute">
		<?php
			echo ideabuz_img_tag(array(
				'url'	=> esc_url( IDEABUZ_IMG_DIR_URI.'icons/close.svg' ),
				'class'	=> esc_attr( 'svg' ),
			));
		?>
	</div>
	<!-- Offcanvas Close Button End -->

	<!-- Offcanvas Content Begin -->
	<div class="offcanvas-content">
		<?php
			dynamic_sidebar( 'ideabuz_offcanvas_sidebar' );
		?>
	</div>
	<!-- Offcanvas Content End -->
</div>
<!-- Offcanvas End -->